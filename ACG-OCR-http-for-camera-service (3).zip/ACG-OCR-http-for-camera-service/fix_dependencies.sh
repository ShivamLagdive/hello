#!/bin/bash
# Script to fix all missing system dependencies for ACG-OCR project

echo "🔧 Installing system dependencies for ACG-OCR..."
echo ""
echo "This script will install:"
echo "  - libgomp1 (for PaddleOCR/PaddlePaddle)"
echo "  - libzbar0 (for pyzbar barcode scanning)"
echo "  - python3-opencv (OpenCV system libraries)"
echo ""
echo "You may be prompted for your sudo password."
echo ""

# Update package list
sudo apt-get update

# Install libgomp1 for PaddleOCR
echo "📦 Installing libgomp1..."
sudo apt-get install -y libgomp1

# Install libzbar0 for pyzbar
echo "📦 Installing libzbar0..."
sudo apt-get install -y libzbar0

# Install python3-opencv (system OpenCV libraries)
echo "📦 Installing python3-opencv..."
sudo apt-get install -y python3-opencv || echo "⚠️  python3-opencv installation skipped (may already be installed)"

echo ""
echo "✅ All dependencies installed!"
echo ""
echo "Next steps:"
echo "  1. Activate virtual environment:"
echo "     source venv/bin/activate"
echo ""
echo "  2. Install Python dependencies:"
echo "     pip install -r requirements.txt"
echo ""
echo "  3. Run the application:"
echo "     python run.py"
echo ""
echo "  4. Access in browser:"
echo "     http://localhost:5000/pharma  (Pharma HMI)"
echo "     http://localhost:5000/ocr     (OCR Dashboard)"

