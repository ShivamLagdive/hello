#!/usr/bin/env python3
"""
Camera Service - Standalone service for CSI camera using Picamera2
Runs on Python 3.13 (system Python) to support Picamera2

OPTIMIZED VERSION:
- No camera reconfiguration on capture (saves ~300-500ms)
- Uses cv2.cvtColor() for fast BGR→RGB conversion
- Uses cv2.imencode() for fast JPEG encoding
- Autofocus enabled (for Camera Module 3 or compatible)

Endpoints:
    GET /stream.mjpg - MJPEG live stream
    POST /capture - Capture still image and return path
    GET /frame - Get single frame as JPEG bytes
    POST /autofocus - Trigger single autofocus
"""
from flask import Flask, Response, jsonify, request
from picamera2 import Picamera2
import cv2
import numpy as np
import time
import logging
import signal
import sys
from pathlib import Path
from threading import Lock

# Try to import libcamera controls for autofocus
try:
    from libcamera import controls
    LIBCAMERA_AVAILABLE = True
except ImportError:
    LIBCAMERA_AVAILABLE = False
    controls = None

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Camera instance
camera: Picamera2 = None
camera_lock = Lock()
_streaming = False

# Default capture path
CAPTURE_PATH = Path('/tmp/capture.jpg')

# JPEG encoding parameters (reusable)
STREAM_JPEG_QUALITY = 85
CAPTURE_JPEG_QUALITY = 95


def init_camera():
    """Initialize Picamera2 with preview configuration and autofocus"""
    global camera
    try:
        camera = Picamera2()
        
        # Configure camera for preview/streaming
        # Captures also use this config (no reconfiguration needed)
        preview_config = camera.create_preview_configuration(
            main={"size": (960, 540), "format": "RGB888"},
            controls={"FrameRate": 10}
        )
        
        camera.configure(preview_config)
        camera.start()
        
        # Enable autofocus if camera supports it (Camera Module 3, etc.)
        autofocus_enabled = enable_autofocus()
        
        if autofocus_enabled:
            logger.info("✅ Camera initialized with CONTINUOUS AUTOFOCUS")
        else:
            logger.info("✅ Camera initialized (autofocus not available or not supported)")
        
        return True
    except Exception as e:
        logger.error(f"❌ Camera initialization failed: {e}", exc_info=True)
        return False


def enable_autofocus() -> bool:
    """
    Enable continuous autofocus if camera supports it.
    
    Autofocus modes (Camera Module 3):
    - AfModeManual (0): Manual focus
    - AfModeAuto (1): Single autofocus (trigger once)
    - AfModeContinuous (2): Continuous autofocus
    
    Returns:
        True if autofocus was enabled, False otherwise
    """
    global camera
    
    if camera is None:
        return False
    
    try:
        # Check if libcamera controls are available
        if not LIBCAMERA_AVAILABLE:
            logger.warning("libcamera controls not available - autofocus disabled")
            return False
        
        # Check if camera supports autofocus
        camera_controls = camera.camera_controls
        
        if 'AfMode' not in camera_controls:
            logger.info("Camera does not support autofocus (AfMode not available)")
            return False
        
        # Enable continuous autofocus
        # AfMode: 0=Manual, 1=Auto (single), 2=Continuous
        camera.set_controls({
            "AfMode": controls.AfModeEnum.Continuous,
            "AfSpeed": controls.AfSpeedEnum.Fast,  # Fast autofocus speed
        })
        
        # Optionally set autofocus range (Normal, Macro, Full)
        if 'AfRange' in camera_controls:
            camera.set_controls({
                "AfRange": controls.AfRangeEnum.Normal
            })
        
        logger.info("✅ Continuous autofocus enabled (AfMode=Continuous, AfSpeed=Fast)")
        return True
        
    except AttributeError as e:
        # libcamera controls enum not available (older version)
        logger.warning(f"Autofocus controls not available: {e}")
        try:
            # Try numeric values as fallback
            camera.set_controls({"AfMode": 2})  # 2 = Continuous
            logger.info("✅ Continuous autofocus enabled (numeric mode)")
            return True
        except Exception as e2:
            logger.warning(f"Failed to enable autofocus with numeric mode: {e2}")
            return False
    except Exception as e:
        logger.warning(f"Could not enable autofocus: {e}")
        return False


def trigger_autofocus() -> bool:
    """
    Trigger a single autofocus operation.
    Useful when using manual or auto mode, or to refocus in continuous mode.
    
    Returns:
        True if autofocus was triggered, False otherwise
    """
    global camera
    
    if camera is None:
        return False
    
    try:
        if not LIBCAMERA_AVAILABLE:
            return False
        
        camera_controls = camera.camera_controls
        
        if 'AfMode' not in camera_controls:
            return False
        
        # Set to auto mode and trigger
        camera.set_controls({"AfMode": controls.AfModeEnum.Auto})
        
        # Trigger autofocus
        if 'AfTrigger' in camera_controls:
            camera.set_controls({"AfTrigger": controls.AfTriggerEnum.Start})
        
        # Wait for autofocus to complete (max 2 seconds)
        start_time = time.time()
        while time.time() - start_time < 2.0:
            metadata = camera.capture_metadata()
            af_state = metadata.get('AfState', None)
            
            # AfState: 0=Idle, 1=Scanning, 2=Focused, 3=Failed
            if af_state == 2:  # Focused
                logger.info("✅ Autofocus completed successfully")
                return True
            elif af_state == 3:  # Failed
                logger.warning("⚠️ Autofocus failed")
                return False
            
            time.sleep(0.1)
        
        logger.warning("⚠️ Autofocus timeout")
        return False
        
    except Exception as e:
        logger.warning(f"Error triggering autofocus: {e}")
        return False


def cleanup_camera():
    """Cleanup camera resources"""
    global camera, _streaming
    try:
        _streaming = False
        if camera:
            camera.stop()
            camera.close()
            camera = None
        logger.info("Camera resources released")
    except Exception as e:
        logger.error(f"Error during camera cleanup: {e}")


def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info(f"Received signal {signum}, shutting down...")
    cleanup_camera()
    sys.exit(0)


# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


def encode_frame_jpeg(frame: np.ndarray, quality: int = 85) -> bytes:
    """
    Encode frame to JPEG bytes using cv2 (faster than PIL).
    
    Picamera2 returns BGR format (despite RGB888 config).
    cv2.imencode expects BGR input and produces correct RGB JPEG.
    No color conversion needed - direct encoding is fastest.
    """
    if frame is None:
        return None
    
    # Handle BGRA (4 channels) - drop alpha
    if len(frame.shape) == 3 and frame.shape[2] == 4:
        frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    
    encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    success, buffer = cv2.imencode('.jpg', frame, encode_params)
    if success:
        return buffer.tobytes()
    return None


def generate_frames():
    """Generator function for MJPEG streaming - OPTIMIZED"""
    global _streaming
    _streaming = True
    
    try:
        while _streaming:
            with camera_lock:
                if camera is None:
                    break
                
                # Capture frame from preview stream (no reconfiguration needed)
                # Picamera2 returns BGR format, which cv2.imencode expects
                frame = camera.capture_array()
                
                # Encode as JPEG using cv2 (much faster than PIL)
                # cv2 handles BGR→RGB conversion internally for JPEG
                frame_bytes = encode_frame_jpeg(frame, STREAM_JPEG_QUALITY)
                
                if frame_bytes:
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            
            # Rate limiting - 10 FPS
            time.sleep(0.1)
            
    except Exception as e:
        logger.error(f"Error in frame generation: {e}", exc_info=True)
    finally:
        _streaming = False


@app.route('/stream.mjpg')
def stream():
    """MJPEG stream endpoint"""
    if camera is None:
        return jsonify({'error': 'Camera not initialized'}), 503
    
    return Response(
        generate_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


@app.route('/capture', methods=['POST'])
def capture():
    """
    Capture still image endpoint - OPTIMIZED
    
    No camera reconfiguration - captures directly from preview stream.
    This saves ~300-500ms per capture by avoiding stop/configure/start cycle.
    """
    global camera
    
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            # Capture directly from preview stream - NO reconfiguration needed!
            # This is much faster than stopping/reconfiguring/starting the camera
            frame = camera.capture_array()
            
            # Handle BGRA (4 channels) - drop alpha
            if len(frame.shape) == 3 and frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # Save as JPEG using cv2 (faster than PIL)
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, CAPTURE_JPEG_QUALITY]
            success = cv2.imwrite(str(CAPTURE_PATH), frame, encode_params)
            
            if not success:
                raise Exception("Failed to save captured image")
            
            logger.info(f"✅ Image captured: {CAPTURE_PATH}")
            
            return jsonify({
                'success': True,
                'path': str(CAPTURE_PATH)
            })
            
    except Exception as e:
        logger.error(f"Error capturing image: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/frame', methods=['GET'])
def get_frame():
    """
    Get single frame as JPEG bytes - OPTIMIZED for streaming
    
    Returns JPEG bytes directly (no file I/O).
    Much faster than /capture for high-frequency frame requests.
    """
    global camera
    
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            # Capture directly from preview stream
            frame = camera.capture_array()
            
            # Handle BGRA (4 channels) - drop alpha
            if len(frame.shape) == 3 and frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # Encode as JPEG bytes (no file write)
            frame_bytes = encode_frame_jpeg(frame, STREAM_JPEG_QUALITY)
            
            if frame_bytes is None:
                return jsonify({
                    'success': False,
                    'error': 'Failed to encode frame'
                }), 500
            
            # Return raw JPEG bytes
            return Response(frame_bytes, mimetype='image/jpeg')
            
    except Exception as e:
        logger.error(f"Error getting frame: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/autofocus', methods=['POST'])
def autofocus():
    """
    Trigger single autofocus operation.
    
    Useful for:
    - Refocusing when scene changes
    - Manual focus adjustment
    
    Returns JSON with success status.
    """
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            success = trigger_autofocus()
            
            if success:
                return jsonify({
                    'success': True,
                    'message': 'Autofocus completed'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': 'Autofocus failed or not supported'
                }), 400
                
    except Exception as e:
        logger.error(f"Error in autofocus endpoint: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/focus', methods=['POST'])
def set_focus():
    """
    Set manual focus distance (for cameras that support it).
    
    Request body (JSON):
        - lens_position: float (0.0 to ~10.0, where 0 = infinity, higher = closer)
    
    Returns JSON with success status.
    """
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        data = request.get_json() or {}
        lens_position = data.get('lens_position')
        
        if lens_position is None:
            return jsonify({
                'success': False,
                'error': 'lens_position is required'
            }), 400
        
        lens_position = float(lens_position)
        
        with camera_lock:
            # Set to manual focus mode
            if LIBCAMERA_AVAILABLE:
                camera.set_controls({
                    "AfMode": controls.AfModeEnum.Manual,
                    "LensPosition": lens_position
                })
            else:
                camera.set_controls({
                    "AfMode": 0,  # Manual
                    "LensPosition": lens_position
                })
            
            logger.info(f"✅ Manual focus set to position: {lens_position}")
            
            return jsonify({
                'success': True,
                'lens_position': lens_position
            })
                
    except Exception as e:
        logger.error(f"Error setting focus: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint with autofocus status"""
    af_available = False
    af_mode = None
    
    if camera is not None:
        try:
            camera_controls = camera.camera_controls
            af_available = 'AfMode' in camera_controls
            
            if af_available:
                metadata = camera.capture_metadata()
                af_mode = metadata.get('AfMode', 'unknown')
        except Exception:
            pass
    
    return jsonify({
        'status': 'ok',
        'camera_initialized': camera is not None,
        'streaming': _streaming,
        'autofocus_available': af_available,
        'autofocus_mode': af_mode
    })


@app.route('/', methods=['GET'])
def index():
    """Root endpoint"""
    return jsonify({
        'service': 'Camera Service',
        'endpoints': {
            'GET /stream.mjpg': 'MJPEG live stream',
            'POST /capture': 'Capture still image',
            'GET /frame': 'Get single frame as JPEG',
            'POST /autofocus': 'Trigger single autofocus',
            'POST /focus': 'Set manual focus (lens_position)',
            'GET /health': 'Health check with autofocus status'
        }
    })


if __name__ == '__main__':
    print("\n" + "="*70)
    print("📷 Camera Service - Picamera2")
    print("="*70 + "\n")
    
    # Initialize camera
    if not init_camera():
        print("⚠️  Camera initialization failed - service will start but camera features won't work")
        print("   Check logs above for details\n")
    
    print("🚀 Camera Service Starting...")
    print("📍 Endpoints:")
    print("   • MJPEG Stream:   http://127.0.0.1:8000/stream.mjpg")
    print("   • Capture:        http://127.0.0.1:8000/capture")
    print("   • Single Frame:   http://127.0.0.1:8000/frame")
    print("   • Autofocus:      http://127.0.0.1:8000/autofocus (POST)")
    print("   • Manual Focus:   http://127.0.0.1:8000/focus (POST)")
    print("   • Health Check:   http://127.0.0.1:8000/health")
    print("\n" + "="*70 + "\n")
    
    try:
        app.run(host='127.0.0.1', port=8000, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n⚠️ Shutting down...")
    finally:
        cleanup_camera()
        print("✅ Shutdown complete")
