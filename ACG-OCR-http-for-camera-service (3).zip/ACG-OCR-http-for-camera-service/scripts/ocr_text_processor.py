"""
Enhanced OCR Text Processing Module with Rotation Detection
Adds multiple rotation variants to catch upside-down and rotated text
Plus document preprocessing for forms and structured documents
"""

import cv2
import numpy as np
from paddleocr import PaddleOCR
from difflib import SequenceMatcher
from collections import defaultdict
import logging
import json
from pathlib import Path
from spellchecker import SpellChecker
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Suppress PaddleOCR logging
logging.getLogger("ppocr").setLevel(logging.ERROR)


class DocumentPreprocessor:
    """Advanced preprocessing for document images"""
    
    def __init__(self, config=None):
        self.config = config or {}
    
    def preprocess_document(self, image_path):
        """
        Apply comprehensive document preprocessing
        Returns list of preprocessed image variants
        """
        img = cv2.imread(image_path)
        if img is None:
            logger.error("Failed to load image")
            return [(image_path, "original", 1.0)]
        
        variants = []
        
        # 1. Original
        variants.append((image_path, "original", 1.0))
        
        # 2. Perspective corrected
        try:
            corrected = self._correct_perspective(img)
            if corrected is not None:
                path = "temp_perspective_corrected.jpg"
                cv2.imwrite(path, corrected)
                variants.append((path, "perspective_corrected", 1.05))
                logger.info("   ✓ Applied perspective correction")
        except Exception as e:
            logger.debug(f"Perspective correction failed: {e}")
        
        # 3. Shadow removal
        try:
            shadow_removed = self._remove_shadows(img)
            path = "temp_shadow_removed.jpg"
            cv2.imwrite(path, shadow_removed)
            variants.append((path, "shadow_removed", 1.0))
            logger.info("   ✓ Applied shadow removal")
        except Exception as e:
            logger.debug(f"Shadow removal failed: {e}")
        
        # 4. Adaptive thresholding (for text extraction)
        try:
            binary = self._adaptive_threshold(img)
            path = "temp_binary.jpg"
            cv2.imwrite(path, binary)
            variants.append((path, "binary", 0.95))
            logger.info("   ✓ Applied adaptive thresholding")
        except Exception as e:
            logger.debug(f"Thresholding failed: {e}")
        
        # 5. Denoised + Enhanced
        try:
            enhanced = self._denoise_and_enhance(img)
            path = "temp_enhanced_doc.jpg"
            cv2.imwrite(path, enhanced)
            variants.append((path, "enhanced_doc", 1.0))
            logger.info("   ✓ Applied denoising and enhancement")
        except Exception as e:
            logger.debug(f"Enhancement failed: {e}")
        
        # 6. High contrast
        try:
            high_contrast = self._increase_contrast(img)
            path = "temp_high_contrast_doc.jpg"
            cv2.imwrite(path, high_contrast)
            variants.append((path, "high_contrast", 0.98))
            logger.info("   ✓ Applied contrast enhancement")
        except Exception as e:
            logger.debug(f"Contrast enhancement failed: {e}")
        
        return variants
        # 7. Remove highlighting
        try:
            no_highlight = self._remove_highlights(img)
            path = "temp_no_highlight.jpg"
            cv2.imwrite(path, no_highlight)
            variants.append((path, "no_highlight", 1.05))
            logger.info("   ✓ Applied highlight removal")
        except Exception as e:
            logger.debug(f"Highlight removal failed: {e}")

    def process_image(self, image_path, save_outputs=True):
        """
        Complete image processing pipeline
        
        Args:
            image_path: Path to input image
            save_outputs: Whether to save results to disk
            
        Returns:
            dict: Complete processing results
        """
        # ✅ FIX: Convert to absolute path immediately
        image_path = str(Path(image_path).resolve())
        
        if not os.path.exists(image_path):
            error_msg = f"File not found: {image_path}"
            logger.error(f"❌ {error_msg}")
            return {"success": False, "error": error_msg}
        
        logger.info(f"🤖 Processing: {image_path}\n")
    
    def _correct_perspective(self, img):
        """Detect and correct perspective distortion"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Edge detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        
        # Find contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Find largest contour (likely the document)
        if not contours:
            return None
        
        largest_contour = max(contours, key=cv2.contourArea)
        
        # Get bounding rectangle
        perimeter = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * perimeter, True)
        
        # If we found a quadrilateral
        if len(approx) == 4:
            # Order points: top-left, top-right, bottom-right, bottom-left
            pts = approx.reshape(4, 2)
            rect = self._order_points(pts)
            
            # Get destination points
            (tl, tr, br, bl) = rect
            
            widthA = np.linalg.norm(br - bl)
            widthB = np.linalg.norm(tr - tl)
            maxWidth = max(int(widthA), int(widthB))
            
            heightA = np.linalg.norm(tr - br)
            heightB = np.linalg.norm(tl - bl)
            maxHeight = max(int(heightA), int(heightB))
            
            dst = np.array([
                [0, 0],
                [maxWidth - 1, 0],
                [maxWidth - 1, maxHeight - 1],
                [0, maxHeight - 1]], dtype="float32")
            
            # Compute perspective transform
            M = cv2.getPerspectiveTransform(rect, dst)
            warped = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
            
            return warped
        
        return None
    
    def _order_points(self, pts):
        """Order points in clockwise order starting from top-left"""
        rect = np.zeros((4, 2), dtype="float32")
        
        # Top-left will have smallest sum
        # Bottom-right will have largest sum
        s = pts.sum(axis=1)
        rect[0] = pts[np.argmin(s)]
        rect[2] = pts[np.argmax(s)]
        
        # Top-right will have smallest difference
        # Bottom-left will have largest difference
        diff = np.diff(pts, axis=1)
        rect[1] = pts[np.argmin(diff)]
        rect[3] = pts[np.argmax(diff)]
        
        return rect
    
    def _remove_shadows(self, img):
        """Remove shadows using dilate and blur technique"""
        rgb_planes = cv2.split(img)
        
        result_planes = []
        for plane in rgb_planes:
            dilated_img = cv2.dilate(plane, np.ones((7, 7), np.uint8))
            bg_img = cv2.medianBlur(dilated_img, 21)
            diff_img = 255 - cv2.absdiff(plane, bg_img)
            norm_img = cv2.normalize(diff_img, None, alpha=0, beta=255, 
                                    norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)
            result_planes.append(norm_img)
        
        result = cv2.merge(result_planes)
        return result
    
    def _adaptive_threshold(self, img):
        """Apply adaptive thresholding for text extraction"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply bilateral filter to reduce noise while keeping edges
        filtered = cv2.bilateralFilter(gray, 9, 75, 75)
        
        # Adaptive threshold
        binary = cv2.adaptiveThreshold(
            filtered, 255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 
            11, 2
        )
        
        # Invert if needed (text should be black on white)
        if np.mean(binary) < 127:
            binary = cv2.bitwise_not(binary)
        
        return cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
    
    def _denoise_and_enhance(self, img):
        """Denoise and enhance document"""
        # Denoise
        denoised = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
        
        # Convert to LAB color space
        lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        # Apply CLAHE to L channel
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        
        # Merge and convert back
        enhanced = cv2.merge([l, a, b])
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
        
        return enhanced
    
    def _increase_contrast(self, img):
        """Increase contrast using CLAHE"""
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        # Apply aggressive CLAHE
        clahe = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        
        # Merge and convert
        result = cv2.merge([l, a, b])
        result = cv2.cvtColor(result, cv2.COLOR_LAB2BGR)
        
        # Additional sharpening
        kernel = np.array([[-1, -1, -1],
                          [-1,  9, -1],
                          [-1, -1, -1]])
        result = cv2.filter2D(result, -1, kernel)
        
        return result
    
    """
    COMPLETE FIX: Add these methods to your DocumentPreprocessor class
    Place them BEFORE the class ends (before the closing of the class definition)
    """

    def _remove_highlights(self, img):
        """
        Remove yellow/orange/red highlighting while preserving text
        CRITICAL for legal documents with marker highlights
        """
        try:
            # Convert to HSV for color-based masking
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            
            # Define ALL highlight color ranges
            highlight_ranges = [
                # Yellow (most common)
                (np.array([15, 30, 30]), np.array([35, 255, 255])),
                # Orange
                (np.array([10, 50, 50]), np.array([20, 255, 255])),
                # Red
                (np.array([0, 50, 50]), np.array([10, 255, 255])),
                # Light Red (upper range)
                (np.array([170, 50, 50]), np.array([180, 255, 255])),
                # Light Blue/Cyan (sometimes used)
                (np.array([85, 30, 30]), np.array([105, 255, 255]))
            ]
            
            # Combine all highlight masks
            combined_mask = np.zeros(img.shape[:2], dtype=np.uint8)
            for lower, upper in highlight_ranges:
                mask = cv2.inRange(hsv, lower, upper)
                combined_mask = cv2.bitwise_or(combined_mask, mask)
            
            # Dilate mask to catch borders
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
            combined_mask = cv2.dilate(combined_mask, kernel, iterations=2)
            
            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Create result: white background where highlighted
            result = gray.copy()
            result[combined_mask > 0] = 255
            
            # Denoise
            result = cv2.fastNlMeansDenoising(result, None, 10, 7, 21)
            
            # Enhance contrast
            clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
            result = clahe.apply(result)
            
            # Sharpen text
            kernel_sharpen = np.array([[-1, -1, -1],
                                    [-1,  9, -1],
                                    [-1, -1, -1]])
            result = cv2.filter2D(result, -1, kernel_sharpen)
            
            # Binary threshold for clean text
            _, result = cv2.threshold(result, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Convert back to BGR for consistency
            return cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.error(f"Highlight removal failed: {e}")
            return img

    def _extract_text_from_colored_boxes(self, img):
        """
        NEW METHOD: Specialized extraction for text inside colored boxes
        Uses LAB color space for better text isolation
        """
        try:
            # Convert to LAB color space
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            l_channel, a_channel, b_channel = cv2.split(lab)
            
            # Focus on L channel (lightness) - text shows up here
            # Invert L channel so text becomes bright
            l_inv = 255 - l_channel
            
            # Aggressive binary threshold
            # This separates text from ANY colored background
            _, text_mask = cv2.threshold(l_inv, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Morphological operations to connect broken characters
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 1))
            text_mask = cv2.morphologyEx(text_mask, cv2.MORPH_CLOSE, kernel)
            
            # Invert back (black text on white)
            result = 255 - text_mask
            
            # Final enhancement
            clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
            result = clahe.apply(result)
            
            return cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.error(f"Colored box extraction failed: {e}")
            return img
    """
    QUICK FIX: Add this method to your DocumentPreprocessor class
    This replaces the existing _remove_highlights() method with a more aggressive version
    """

    def _remove_highlights(self, img):
        """
        ENHANCED: Remove ALL colored highlights (yellow/red/orange/blue)
        while preserving black text - CRITICAL for legal documents
        """
        try:
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            
            # Define ALL highlight color ranges
            highlight_ranges = [
                # Yellow (most common)
                (np.array([15, 30, 30]), np.array([35, 255, 255])),
                # Orange
                (np.array([10, 50, 50]), np.array([20, 255, 255])),
                # Red
                (np.array([0, 50, 50]), np.array([10, 255, 255])),
                # Light Red (upper range)
                (np.array([170, 50, 50]), np.array([180, 255, 255])),
                # Light Blue (cyan highlights)
                (np.array([85, 30, 30]), np.array([105, 255, 255])),
                # Green (less common but exists)
                (np.array([40, 30, 30]), np.array([80, 255, 255]))
            ]
            
            # Combine all highlight masks
            combined_mask = np.zeros(img.shape[:2], dtype=np.uint8)
            for lower, upper in highlight_ranges:
                mask = cv2.inRange(hsv, lower, upper)
                combined_mask = cv2.bitwise_or(combined_mask, mask)
            
            # Aggressive dilation to catch borders
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
            combined_mask = cv2.dilate(combined_mask, kernel, iterations=2)
            
            # Convert to grayscale (preserves text better than LAB)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Create result: white background where highlighted
            result = gray.copy()
            result[combined_mask > 0] = 255
            
            # Denoise remaining text
            result = cv2.fastNlMeansDenoising(result, None, 10, 7, 21)
            
            # Enhance contrast aggressively
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            result = clahe.apply(result)
            
            # Sharpen text
            kernel_sharpen = np.array([[-1, -1, -1],
                                    [-1,  9, -1],
                                    [-1, -1, -1]])
            result = cv2.filter2D(result, -1, kernel_sharpen)
            
            # Binary threshold to get pure black text on white
            _, result = cv2.threshold(result, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Convert back to BGR for consistency
            return cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.error(f"Highlight removal failed: {e}")
            return img


    # Also add this NEW method to DocumentPreprocessor:
    def _extract_text_from_colored_boxes(self, img):
        """
        NEW METHOD: Specialized extraction for text inside colored boxes
        Uses color quantization + text isolation
        """
        try:
            # Step 1: Convert to LAB color space
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            l_channel, a_channel, b_channel = cv2.split(lab)
            
            # Step 2: Focus on L channel (lightness) - text shows up here
            # Invert L channel so text becomes bright
            l_inv = 255 - l_channel
            
            # Step 3: Aggressive binary threshold
            # This separates text from ANY colored background
            _, text_mask = cv2.threshold(l_inv, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Step 4: Morphological operations to connect broken characters
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 1))
            text_mask = cv2.morphologyEx(text_mask, cv2.MORPH_CLOSE, kernel)
            
            # Step 5: Invert back (black text on white)
            result = 255 - text_mask
            
            # Step 6: Final enhancement
            clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
            result = clahe.apply(result)
            
            return cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.error(f"Colored box extraction failed: {e}")
            return img

class TextRegionSorter:
    """Sort text regions in reading order (left-to-right, top-to-bottom)"""
    
    @staticmethod
    def sort_regions(detections):
        """
        Sort text detections in natural reading order
        Groups by rows, then sorts left-to-right within each row
        """
        if not detections:
            return []
        
        # Sort by Y coordinate first (top to bottom)
        sorted_by_y = sorted(detections, key=lambda d: d['center'][1])
        
        # Group into rows (regions with similar Y coordinates)
        rows = []
        current_row = [sorted_by_y[0]]
        row_threshold = 20  # pixels - adjust based on font size
        
        for det in sorted_by_y[1:]:
            # Check if this detection is in the same row
            avg_y = np.mean([d['center'][1] for d in current_row])
            if abs(det['center'][1] - avg_y) < row_threshold:
                current_row.append(det)
            else:
                # Start new row
                rows.append(current_row)
                current_row = [det]
        
        # Don't forget last row
        if current_row:
            rows.append(current_row)
        
        # Sort each row by X coordinate (left to right)
        sorted_detections = []
        for row in rows:
            sorted_row = sorted(row, key=lambda d: d['center'][0])
            sorted_detections.extend(sorted_row)
        
        return sorted_detections


class DocumentStructureAnalyzer:
    """Analyze document structure (tables, forms, headers)"""
    
    @staticmethod
    def detect_table_structure(img):
        """Detect if image contains table/form structure"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Detect horizontal and vertical lines
        horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 1))
        vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 40))
        
        # Detect horizontal lines
        horizontal = cv2.morphologyEx(gray, cv2.MORPH_OPEN, horizontal_kernel, iterations=2)
        h_lines = cv2.threshold(horizontal, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        
        # Detect vertical lines
        vertical = cv2.morphologyEx(gray, cv2.MORPH_OPEN, vertical_kernel, iterations=2)
        v_lines = cv2.threshold(vertical, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        
        # Count lines
        h_line_count = len(cv2.findContours(h_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0])
        v_line_count = len(cv2.findContours(v_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0])
        
        # If we have both horizontal and vertical lines, it's likely a table/form
        has_table = h_line_count > 3 and v_line_count > 2
        
        return {
            'has_table_structure': has_table,
            'horizontal_lines': h_line_count,
            'vertical_lines': v_line_count
        }
    
    @staticmethod
    def group_by_proximity(detections, threshold=30):
        """Group text regions by spatial proximity"""
        if not detections:
            return []
        
        groups = []
        used = set()
        
        for i, det in enumerate(detections):
            if i in used:
                continue
            
            group = [det]
            used.add(i)
            
            for j, other in enumerate(detections):
                if j in used or j <= i:
                    continue
                
                # Calculate distance
                dx = abs(det['center'][0] - other['center'][0])
                dy = abs(det['center'][1] - other['center'][1])
                distance = np.sqrt(dx**2 + dy**2)
                
                if distance < threshold:
                    group.append(other)
                    used.add(j)
            
            groups.append(group)
        
        return groups


class ImageClassifier:
    """Classify images as document or product type"""
    
    def __init__(self, config):
        self.config = config
    
    def classify(self, image_path):
        """Classify image type using rule-based features"""
        try:
            img = cv2.imread(image_path)
            if img is None:
                logger.error(f"❌ Failed to read image for classification")
                return "product", {}
            
            h, w = img.shape[:2]
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Extract features
            features = {
                'aspect_ratio': float(w / h),
                'saturation_mean': float(cv2.cvtColor(img, cv2.COLOR_BGR2HSV)[:,:,1].mean()),
                'brightness_mean': float(gray.mean()),
                'edge_density': float(np.count_nonzero(cv2.Canny(gray, 50, 150)) / gray.size)
            }
            
            # Classification logic
            cfg = self.config.get('image_classifier')
            score = 0
            
            if features['aspect_ratio'] < cfg['aspect_ratio_threshold']:
                score += 2
            if features['edge_density'] < cfg['edge_density_low']:
                score += 2
            if features['saturation_mean'] < cfg['saturation_low']:
                score += 2
            if features['brightness_mean'] > cfg['brightness_high']:
                score += 1
            
            img_type = "document" if score >= cfg['document_score_threshold'] else "product"
            
            logger.info(f"📊 Image Type: {img_type.upper()} (score: {score})")
            return img_type, features
            
        except Exception as e:
            logger.error(f"❌ Classification error: {e}")
            return "product", {}


# class OCREngine:
#     """Multi-language OCR engine wrapper"""
    
#     def __init__(self, config):
#         self.config = config
#         self.engines = {}
#         self.current_lang = config.get('ocr_engine', 'lang')
    
#     def get_engine(self, lang='en'):
#         """Get or create OCR engine for specific language"""
#         if lang not in self.engines:
#             cfg = self.config.get('ocr_engine').copy()
#             cfg['lang'] = lang
#             self.engines[lang] = PaddleOCR(**cfg)
#             logger.info(f"✅ Initialized OCR engine for language: {lang}")
#         return self.engines[lang]
    
#     def perform_ocr(self, image, lang=None, max_retries=2):
#         """
#         Perform OCR on an image with error handling and retry logic.
#         `image` can be:
#         - file path (str)
#         - OpenCV image (numpy array, BGR)
        
#         Args:
#             image: Image path or numpy array
#             lang: Language code (default: current language)
#             max_retries: Maximum retry attempts on RuntimeError
        
#         Returns:
#             OCR result or None on failure
#         """
#         if lang is None:
#             lang = self.current_lang

#         # Validate image if it's a numpy array
#         if isinstance(image, np.ndarray):
#             # Ensure image is valid
#             if image.size == 0:
#                 logger.error("❌ Empty image array provided")
#                 return None
            
#             # Ensure correct dtype and shape
#             if image.dtype != np.uint8:
#                 logger.warning(f"⚠️ Converting image from {image.dtype} to uint8")
#                 if image.dtype == np.float32 or image.dtype == np.float64:
#                     image = (image * 255).astype(np.uint8)
#                 else:
#                     image = image.astype(np.uint8)
            
#             # Ensure 3-channel BGR format
#             if len(image.shape) == 2:
#                 image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
#             elif len(image.shape) == 3 and image.shape[2] == 4:
#                 image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
#             elif len(image.shape) == 3 and image.shape[2] != 3:
#                 logger.error(f"❌ Invalid image shape: {image.shape}")
#                 return None

#         use_cls = bool(self.config.get('ocr_engine', 'use_angle_cls', default=False))

#         # Retry logic for RuntimeError (PaddleOCR backend issues)
#         for attempt in range(max_retries + 1):
#             try:
#                 engine = self.get_engine(lang)
#                 result = engine.ocr(image, cls=use_cls)
#                 return result
                
#             except RuntimeError as e:
#                 error_msg = str(e).lower()
#                 if "could not execute a primitive" in error_msg or "primitive" in error_msg:
#                     logger.warning(f"⚠️ PaddleOCR RuntimeError (attempt {attempt + 1}/{max_retries + 1}): {e}")
                    
#                     if attempt < max_retries:
#                         # Try recreating the engine
#                         logger.warning(f"🔄 Recreating OCR engine for language: {lang}")
#                         if lang in self.engines:
#                             del self.engines[lang]
#                         # Force garbage collection
#                         import gc
#                         gc.collect()
#                         continue
#                     else:
#                         logger.error(f"❌ Failed after {max_retries + 1} attempts: {e}")
#                         return None
#                 else:
#                     # Other RuntimeError, don't retry
#                     logger.error(f"❌ PaddleOCR RuntimeError: {e}")
#                     raise
                    
#             except Exception as e:
#                 logger.error(f"❌ OCR error: {e}")
#                 raise
    
#     def cleanup(self):
#         """Cleanup and release all OCR engine resources
        
#         This method releases PaddleOCR instances to prevent crashes during shutdown.
#         PaddleOCR doesn't have an explicit cleanup method, so we delete references
#         and force garbage collection to release resources before Python's normal
#         cleanup runs (which can trigger PaddlePaddle's destructors and cause SIGABRT).
#         """
#         try:
#             logger.info("🧹 Cleaning up OCR engines...")
#             # Delete all PaddleOCR instances - this prevents PaddlePaddle's
#             # cleanup from running during Python's normal shutdown process
#             for lang in list(self.engines.keys()):
#                 try:
#                     del self.engines[lang]
#                     logger.debug(f"Removed OCR engine reference for language: {lang}")
#                 except Exception as e:
#                     logger.warning(f"Error removing OCR engine for {lang}: {e}")
            
#             # Clear the dictionary
#             self.engines.clear()
            
#             # Force garbage collection to release PaddlePaddle resources immediately
#             # This should release resources before Python's normal cleanup
#             import gc
#             gc.collect()
            
#             logger.info("✅ OCR engines cleaned up")
#         except Exception as e:
#             logger.error(f"Error during OCR engine cleanup: {e}")



# ===========================================================================================
# Testing code

import threading
import gc
import traceback

class OCREngine:
    """Production-hardened multi-language OCR engine wrapper"""

    def __init__(self, config):
        self.config = config
        self.engines = {}
        self.engine_usage_count = {}  # Track usage count per language
        self.current_lang = config.get('ocr_engine', 'lang')
        
        # Proactive engine refresh: create new engine after N successful uses
        # This prevents the engine from going into a bad state
        # Set to 2 so we refresh before the 3rd use (where failures typically occur)
        self.MAX_USES_PER_ENGINE = 2
        
        # Use RLock (reentrant lock) instead of Lock to prevent deadlock
        # This allows the same thread to acquire the lock multiple times
        # Critical: perform_ocr() holds the lock and calls get_engine() which also needs the lock
        self._ocr_lock = threading.RLock()
        
        # Hard limit CPU threads (critical for WSL / Pi stability)
        os.environ.setdefault("OMP_NUM_THREADS", "1")
        os.environ.setdefault("MKL_NUM_THREADS", "1")
        os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

    # ------------------------------------------------------------------
    # Engine lifecycle
    # ------------------------------------------------------------------
    def get_engine(self, lang='en', force_refresh=False):
        """
        Get or create OCR engine for a specific language.
        
        Args:
            lang: Language code
            force_refresh: If True, create a new engine even if one exists
        
        Returns:
            PaddleOCR engine instance
        """
        # Fast path: check if engine exists and doesn't need refresh (most common case)
        usage_count = self.engine_usage_count.get(lang, 0)
        if lang in self.engines and not force_refresh and usage_count < self.MAX_USES_PER_ENGINE:
            return self.engines[lang]
        
        # Thread-safe engine creation/refresh
        with self._ocr_lock:
            # Check if we need to refresh the engine proactively
            usage_count = self.engine_usage_count.get(lang, 0)
            if force_refresh or (lang in self.engines and usage_count >= self.MAX_USES_PER_ENGINE):
                logger.info(f"🔄 Proactively refreshing OCR engine | lang={lang} | uses={usage_count}")
                self._destroy_engine(lang)
                self.engine_usage_count[lang] = 0
            
            # Create engine if it doesn't exist
            if lang not in self.engines:
                cfg = self.config.get('ocr_engine').copy()
                cfg['lang'] = lang

                logger.info(f"🚀 Creating PaddleOCR engine | lang={lang}")
                self.engines[lang] = PaddleOCR(**cfg)
                self.engine_usage_count[lang] = 0

        return self.engines[lang]

    def _destroy_engine(self, lang):
        """Safely destroy OCR engine and free memory
        
        Note: This should be called from within a lock context (RLock handles reentrancy)
        """
        if lang in self.engines:
            try:
                logger.info(f"🔥 Destroying OCR engine | lang={lang}")
                del self.engines[lang]
                if lang in self.engine_usage_count:
                    del self.engine_usage_count[lang]
            except Exception as e:
                logger.warning(f"Engine destroy error ({lang}): {e}")

            gc.collect()

    # ------------------------------------------------------------------
    # OCR execution
    # ------------------------------------------------------------------
    def perform_ocr(self, image, lang=None, max_retries=2):
        """
        Perform OCR on an image with error handling and retry logic.
        `image` can be:
        - file path (str)
        - OpenCV image (numpy array, BGR)
        
        Args:
            image: Image path or numpy array
            lang: Language code (default: current language)
            max_retries: Maximum retry attempts on RuntimeError
        
        Returns:
            OCR result or None on failure
        """
        if lang is None:
            lang = self.current_lang

        # Validate image if it's a numpy array
        if isinstance(image, np.ndarray):
            # Ensure image is valid
            if image.size == 0:
                logger.error("❌ Empty image array provided")
                return None
            
            # Ensure correct dtype and shape
            if image.dtype != np.uint8:
                logger.warning(f"⚠️ Converting image from {image.dtype} to uint8")
                if image.dtype == np.float32 or image.dtype == np.float64:
                    image = (image * 255).astype(np.uint8)
                else:
                    image = image.astype(np.uint8)
            
            # Ensure 3-channel BGR format
            if len(image.shape) == 2:
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            elif len(image.shape) == 3 and image.shape[2] == 4:
                image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
            elif len(image.shape) == 3 and image.shape[2] != 3:
                logger.error(f"❌ Invalid image shape: {image.shape}")
                return None
            
            # Ensure contiguous memory for better performance
            image = np.ascontiguousarray(image)
            
            # Downscale large images for Raspberry Pi
            MAX_WIDTH = 1024
            if image.shape[1] > MAX_WIDTH:
                scale = MAX_WIDTH / image.shape[1]
                image = cv2.resize(image, None, fx=scale, fy=scale)

        use_cls = bool(self.config.get('ocr_engine', 'use_angle_cls', default=False))

        # CRITICAL: Serialize all OCR operations with a lock
        # This prevents concurrent access to PaddleOCR which is not thread-safe
        with self._ocr_lock:
            # Check if we need to proactively refresh the engine before use
            usage_count = self.engine_usage_count.get(lang, 0)
            if usage_count >= self.MAX_USES_PER_ENGINE:
                logger.info(f"🔄 Proactive engine refresh before use | lang={lang} | uses={usage_count}")
                if lang in self.engines:
                    try:
                        del self.engines[lang]
                    except Exception:
                        pass
                self.engine_usage_count[lang] = 0
                gc.collect()
            
            for attempt in range(max_retries + 1):
                try:
                    engine = self.get_engine(lang)
                    result = engine.ocr(image, cls=use_cls)
                    
                    # Increment usage count on successful OCR
                    self.engine_usage_count[lang] = self.engine_usage_count.get(lang, 0) + 1
                    logger.debug(f"✅ OCR successful | lang={lang} | usage_count={self.engine_usage_count[lang]}")
                    
                    return result

                except RuntimeError as e:
                    msg = str(e).lower()
                    backend_failure = any(
                        k in msg for k in (
                            "primitive",
                            "mkldnn",
                            "onednn",
                            "openmp",
                            "blas",
                            "illegal instruction",
                        )
                    )

                    logger.error("Paddle RuntimeError:\n" + traceback.format_exc())

                    if backend_failure and attempt < max_retries:
                        logger.warning("🔁 Backend failure → destroying and recreating engine")
                        # Destroy the bad engine
                        if lang in self.engines:
                            try:
                                del self.engines[lang]
                            except Exception:
                                pass
                        if lang in self.engine_usage_count:
                            self.engine_usage_count[lang] = 0
                        gc.collect()
                        continue

                    if backend_failure:
                        logger.error("❌ Backend failure after retries")
                        # Reset usage count on failure
                        if lang in self.engine_usage_count:
                            self.engine_usage_count[lang] = 0
                        return None

                    raise

                except Exception:
                    logger.error("❌ Unexpected OCR error:\n" + traceback.format_exc())
                    # Reset usage count on unexpected error
                    if lang in self.engine_usage_count:
                        self.engine_usage_count[lang] = 0
                    raise

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    def cleanup(self):
        """Release all OCR engines safely before shutdown"""
        logger.info("🧹 Cleaning up OCR engines...")

        with self._ocr_lock:  # Thread-safe cleanup
            for lang in list(self.engines.keys()):
                self._destroy_engine(lang)

            self.engines.clear()
            self.engine_usage_count.clear()
            gc.collect()

        logger.info("✅ OCR cleanup complete")

# ===========================================================================================






class TextDetector:
    """Advanced text detection with preprocessing variants and rotation"""
    
    def __init__(self, config, ocr_engine):
        self.config = config
        self.ocr_engine = ocr_engine
        self.doc_preprocessor = DocumentPreprocessor(config)
        self.text_sorter = TextRegionSorter()
        self.structure_analyzer = DocumentStructureAnalyzer()
    
    def detect_text(self, image_path, img_type):
        logger.info(f"🔍 Phase 1: Text Detection ({img_type} mode)")
        
        # ✅ FIX: Load original image first
        original_img = cv2.imread(image_path)
        if original_img is None:
            logger.error(f"❌ Failed to load image: {image_path}")
            return []
        
        orig_h, orig_w = original_img.shape[:2]
        logger.info(f"   📐 Image size: {orig_w}x{orig_h}")
        
        try:
            # Generate variants (now in-memory arrays)
            variants = self._generate_variants(original_img, image_path, img_type)
            logger.info(f"   🔄 Generated {len(variants)} variants")
            
            all_detections = []

            for variant_img, variant_name, weight in variants:
                try:
                    # Validate variant image before OCR
                    if variant_img is None or not isinstance(variant_img, np.ndarray):
                        logger.warning(f"⚠️ {variant_name}: Invalid image, skipping")
                        continue
                    
                    if variant_img.size == 0:
                        logger.warning(f"⚠️ {variant_name}: Empty image, skipping")
                        continue
                    
                    # ✅ Pass the numpy array directly to OCR with retry logic
                    result = self.ocr_engine.perform_ocr(variant_img)
                    
                    if result and result[0]:
                        logger.info(f"   ✅ {variant_name}: Found {len(result[0])} regions")
                        
                        for line in result[0]:
                            detection = self._parse_detection(
                                line, weight, variant_name,
                                orig_w, orig_h
                            )
                            if detection:
                                # Skip phantom vertical boxes
                                if self._is_phantom_vertical_box(detection):
                                    continue
                                all_detections.append(detection)
                    else:
                        logger.info(f"   ⚠️ {variant_name}: No text found")
                        
                except RuntimeError as e:
                    # PaddleOCR backend errors - already handled in perform_ocr with retries
                    logger.error(f"❌ RuntimeError in {variant_name}: {e}")
                    # Continue with next variant
                    continue
                except Exception as e:
                    logger.error(f"❌ Error in {variant_name}: {e}")
                    import traceback
                    traceback.print_exc()
                    # Continue with next variant instead of failing completely
                    continue
            
            logger.info(f"   📊 Total raw detections: {len(all_detections)}")
            
            # Deduplicate and merge
            detections = self._merge_detections(all_detections, img_type)
            
            # Sort in reading order
            detections = self.text_sorter.sort_regions(detections)
            
            logger.info(f"   ✅ Final unique regions: {len(detections)}")
            return detections
            
        except Exception as e:
            logger.error(f"❌ Text detection error: {e}")
            import traceback
            traceback.print_exc()
            return []

    def _is_phantom_vertical_box(self, detection):
        """
        Detects and removes 'Phantom Vertical Columns' that cut through text.
        These are common when OCR runs on 90-degree rotated dense text.
        """
        w, h = detection['size']
        text = detection['text']
        
        # Calculate Aspect Ratio (Height / Width)
        aspect_ratio = h / max(w, 1)
        
        # RULE 1: If box is extremely tall and thin (Vertical Line)
        # Real text lines are almost never vertical in these documents
        if aspect_ratio > 4.0:
            # Exception: Barcodes or very short side-labels (less than 10 chars)
            if len(text) < 10: 
                return False
            return True # It's a phantom column -> REJECT
            
        # RULE 2: If box is moderately vertical but contains a LOT of text
        # (e.g., cutting through a paragraph)
        if aspect_ratio > 1.5 and len(text) > 50:
            return True # REJECT
            
        return False
    
    def _generate_variants(self, original_img, image_path, img_type):
        """FAST MODE: Skip all preprocessing on Raspberry Pi"""
        if original_img is None:
            original_img = cv2.imread(image_path)
        if original_img is None:
            return []
        
        # ✅ ONLY return original - no variants
        return [(original_img, "original", 1.0)]

    def _map_coordinates(self, box, variant_name, orig_w, orig_h):
        """
        Map coordinates from rotated variants back to original space.
        Only applies to rotation variants, leaves others unchanged.
        """
        # If not a rotation variant, return as-is
        if "rotated" not in variant_name:
            return box
        
        # For rotations, we need the variant's dimensions
        # But since we're mapping BACK to original, we use original dimensions
        new_box = []
        
        for point in box:
            x, y = int(point[0]), int(point[1])
            
            if variant_name == "rotated_90":
                # After 90° CW rotation: new_x = old_y, new_y = orig_h - old_x
                nx = y
                ny = orig_h - x
                new_box.append([nx, ny])
                
            elif variant_name == "rotated_180":
                # After 180° rotation: flip both axes
                nx = orig_w - x
                ny = orig_h - y
                new_box.append([nx, ny])
                
            elif variant_name == "rotated_270":
                # After 270° (or 90° CCW): new_x = orig_w - old_y, new_y = old_x
                nx = orig_w - y
                ny = x
                new_box.append([nx, ny])
            else:
                new_box.append([x, y])
        
        return new_box
    
    def _parse_detection(self, line, weight, variant_name, orig_w, orig_h):
        """Parse a single OCR detection line with coordinate mapping"""
        try:
            box = line[0]
            text = line[1][0].strip()
            conf = float(line[1][1] * weight)
            
            min_len = self.config.get('text_processing', 'min_text_length')
            if len(text) < min_len:
                return None
            
            # --- APPLY COORDINATE MAPPING ---
            mapped_box = self._map_coordinates(box, variant_name, orig_w, orig_h)
            
            # Convert to numpy for calculations
            box_np = np.array(mapped_box).astype(np.int32)
            
            center_x = int(np.mean(box_np[:, 0]))
            center_y = int(np.mean(box_np[:, 1]))
            width = int(np.max(box_np[:, 0]) - np.min(box_np[:, 0]))
            height = int(np.max(box_np[:, 1]) - np.min(box_np[:, 1]))
            
            return {
                "text": text,
                "confidence": conf,
                "box": box_np.tolist(),
                "center": (center_x, center_y),
                "size": (width, height),
                "variant": variant_name
            }
        except Exception as e:
            # logger.debug(f"Parse error: {e}")
            return None

    # --- NEW MERGE LOGIC ---
    def _merge_detections(self, detections, img_type):
        """Deduplication with BOX MERGING to fix missing text"""
        if not detections: return []

        # 1. Filter noise
        clean_detections = [d for d in detections if d['size'][0] > 5 and d['size'][1] > 5]
        
        # 2. Sort by length then confidence
        clean_detections.sort(key=lambda x: (len(x['text']), x['confidence']), reverse=True)
        
        final_detections = []
        
        while clean_detections:
            best_det = clean_detections.pop(0)
            
            # Skip phantom columns that might have slipped through
            if best_det['size'][1] > best_det['size'][0] * 3 and len(best_det['text']) > 20:
                continue

            remaining = []
            merged_any = False
            
            for other_det in clean_detections:
                iou = self._calculate_iou(best_det['box'], other_det['box'])
                text_sim = self._text_similarity(best_det['text'], other_det['text'])
                
                is_duplicate = False
                should_merge = False

                # High overlap or very similar text -> Candidate for merge/delete
                if iou > 0.3 or text_sim > 0.85:
                    is_duplicate = True
                    # If they are spatially close and horizontally aligned, merge them
                    if iou > 0.1 and abs(best_det['center'][1] - other_det['center'][1]) < 20:
                        should_merge = True

                if should_merge:
                    # Merge boxes and keep the longer text
                    best_det['box'] = self._merge_boxes(best_det['box'], other_det['box'])
                    # Re-calculate center/size after merge
                    box_np = np.array(best_det['box']).astype(np.int32)
                    best_det['center'] = (int(np.mean(box_np[:, 0])), int(np.mean(box_np[:, 1])))
                    best_det['size'] = (int(np.max(box_np[:, 0]) - np.min(box_np[:, 0])), 
                                        int(np.max(box_np[:, 1]) - np.min(box_np[:, 1])))
                    merged_any = True
                
                if not is_duplicate:
                    remaining.append(other_det)
            
            final_detections.append(best_det)
            clean_detections = remaining

        return final_detections

    def _merge_boxes(self, box1, box2):
        """Combines two bounding boxes into one encompassing box"""
        b1 = np.array(box1, dtype=np.int32)
        b2 = np.array(box2, dtype=np.int32)
        
        # Find min/max coordinates of both boxes
        x_min = min(np.min(b1[:, 0]), np.min(b2[:, 0]))
        y_min = min(np.min(b1[:, 1]), np.min(b2[:, 1]))
        x_max = max(np.max(b1[:, 0]), np.max(b2[:, 0]))
        y_max = max(np.max(b1[:, 1]), np.max(b2[:, 1]))
        
        # Return new 4-point box
        return [[x_min, y_min], [x_max, y_min], [x_max, y_max], [x_min, y_max]]

    
    def _merge_detections(self, detections, img_type):
        """Enhanced merging with looser duplicate thresholds"""
        if not detections:
            return []

        # ==========================================
        # STEP 1: PRE-FILTER
        # ==========================================
        clean_detections = []
        for det in detections:
            width, height = det['size']
            text = det['text']
            conf = det['confidence']
            
            # Allow slightly lower confidence for forms
            if conf < 0.35: 
                continue
            
            if len(text) < 1:
                continue
            
            if width < 5 or height < 5:
                continue
            
            clean_detections.append(det)

        if not clean_detections:
            return []

        # ==========================================
        # STEP 2: INTELLIGENT DEDUPLICATION
        # ==========================================
        
        # CRITICAL CHANGE: Sort by Length FIRST, then Confidence
        # This keeps the full sentence "Contract Agreement" instead of "Contract"
        clean_detections.sort(key=lambda x: (len(x['text']), x['confidence']), reverse=True)
        
        final_detections = []
        
        while clean_detections:
            best_det = clean_detections.pop(0)
            final_detections.append(best_det)
            
            remaining = []
            for other_det in clean_detections:
                # Calculate IoU
                iou = self._calculate_iou(best_det['box'], other_det['box'])
                
                # Calculate text similarity
                text_sim = self._text_similarity(best_det['text'], other_det['text'])
                
                is_duplicate = False

                # 1. High overlap usually means duplicate
                if iou > 0.4:
                    # If shorter text is substring of longer (best) text -> Duplicate
                    if other_det['text'] in best_det['text']:
                        is_duplicate = True
                    # If heavily overlapping
                    elif iou > 0.6:
                        is_duplicate = True
                
                # 2. Very similar text + close proximity (handled by IoU mostly, but extra safety)
                elif text_sim > 0.9 and iou > 0.1:
                     is_duplicate = True

                if not is_duplicate:
                    remaining.append(other_det)
            
            clean_detections = remaining

        # ==========================================
        # STEP 3: FINAL QUALITY CHECK & OUTLIER REMOVAL
        # ==========================================
        
        # Remove detections that are spatial outliers (far from all others)
        if len(final_detections) > 3:
            final_detections = self._remove_spatial_outliers(final_detections)
        
        # Sort in reading order
        final_detections.sort(key=lambda d: (d['center'][1], d['center'][0]))
        
        return final_detections

    def _text_similarity(self, text1, text2):
        from difflib import SequenceMatcher
        return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()

    def _remove_spatial_outliers(self, detections):
        """
        Remove detections that are too far from the main cluster
        (likely false positives / noise on the table)
        """
        if len(detections) < 5:
            return detections
        
        # Calculate center of mass
        centers = np.array([det['center'] for det in detections])
        mean_center = centers.mean(axis=0)
        
        # Calculate distances from center
        distances = [
            np.sqrt((det['center'][0] - mean_center[0])**2 + 
                    (det['center'][1] - mean_center[1])**2)
            for det in detections
        ]
        
        # Calculate threshold (2.5 standard deviations - slightly relaxed)
        mean_dist = np.mean(distances)
        std_dist = np.std(distances)
        threshold = mean_dist + 2.5 * std_dist
        
        # Keep only non-outliers
        filtered = [
            det for det, dist in zip(detections, distances)
            if dist <= threshold
        ]
        
        return filtered

    def _calculate_iou(self, boxA, boxB):
        try:
            boxA = np.array(boxA, dtype=np.float32); boxB = np.array(boxB, dtype=np.float32)
            xA = max(np.min(boxA[:, 0]), np.min(boxB[:, 0])); yA = max(np.min(boxA[:, 1]), np.min(boxB[:, 1]))
            xB = min(np.max(boxA[:, 0]), np.max(boxB[:, 0])); yB = min(np.max(boxA[:, 1]), np.max(boxB[:, 1]))
            interW = max(0, xB - xA); interH = max(0, yB - yA); interArea = interW * interH
            if interArea == 0: return 0
            boxAArea = self._box_area(boxA); boxBArea = self._box_area(boxB)
            return interArea / float(boxAArea + boxBArea - interArea)
        except: return 0

    def _box_area(self, box):
        try:
            box = np.array(box, dtype=np.float32)
            return 0.5 * np.abs(np.dot(box[:, 0], np.roll(box[:, 1], 1)) - np.dot(box[:, 1], np.roll(box[:, 0], 1)))
        except: return 0

class TextCorrector:
    """Domain-adaptive text correction"""
    
    def __init__(self, config):
        self.config = config
        self.custom_dict = config.custom_dict
        self.word_freq = defaultdict(int)

        for word in self.custom_dict.values():
            self.word_freq[word.lower()] += 1

        # NEW: general English spell checker
        self.spell = SpellChecker(language='en') 
    
    def correct_text(self, text, img_type, confidence):
        """Apply domain-adaptive correction to text"""
        high_conf_threshold = self.config.get('text_processing', 'high_confidence_no_correct')
        
        # Skip high-confidence text
        if confidence > high_conf_threshold:
            return text, False
        
        words = text.split()
        corrected_words = []
        was_corrected = False
        
        for word in words:
            punct = ""
            clean_word = word
            
            if word and not word[-1].isalnum():
                punct = word[-1]
                clean_word = word[:-1]
            
            if clean_word:
                corrected, method = self._correct_word(clean_word, img_type)
                if method != "unchanged":
                    was_corrected = True
                    corrected_words.append(corrected + punct)
                else:
                    corrected_words.append(word)
            else:
                corrected_words.append(word)
        
        return " ".join(corrected_words), was_corrected
    
    def _correct_word(self, word, img_type):
        """Correct individual word based on domain rules"""
        # Check custom dictionary
        if word in self.custom_dict:
            return self.custom_dict[word], "custom"
        if word.lower() in self.custom_dict:
            return self.custom_dict[word.lower()], "custom"
        
        # Product-specific rules
        if img_type == "product":
            prod_rules = self.config.get('correction', 'product_rules')
            
            if prod_rules.get('preserve_all_caps', True) and word.isupper() and len(word) > 2:
                return word, "unchanged"
            
            if prod_rules.get('preserve_numbers', True) and any(c.isdigit() for c in word):
                return word, "unchanged"
            
            if len(word) <= prod_rules.get('preserve_short_words', 3):
                return word, "unchanged"
        
        # Document-specific correction
        if img_type == "document":
            doc_rules = self.config.get('correction', 'document_rules')
            
            if len(word) >= doc_rules.get('min_word_length', 4):
                corrected = self._spell_correct(word)
                if corrected and corrected != word:
                    similarity = SequenceMatcher(None, word.lower(), corrected.lower()).ratio()
                    threshold = self.config.get('text_processing', 'similarity_threshold')
                    if similarity > threshold:
                        return corrected, "spell"
        
        return word, "unchanged"
    
    def _spell_correct(self, word):
        """Hybrid correction: custom dict + general spell checker."""
        word_lower = word.lower()

        # 1) keep if already in our domain vocab
        if word_lower in self.word_freq:
            return word

        # 2) ignore very short / mostly numeric "words"
        if len(word) < 4 or sum(c.isalpha() for c in word) < 2:
            return word

        # 3) ask pyspellchecker
        candidate = self.spell.correction(word_lower)
        if candidate and candidate != word_lower:
            sim = SequenceMatcher(None, word_lower, candidate).ratio()
            if sim > 0.75:
                # preserve capitalization style
                if word.istitle():
                    return candidate.title()
                elif word.isupper():
                    return candidate.upper()
                else:
                    return candidate

        return word

class SentenceBuilder:
    """Enhanced sentence builder with better spatial merging"""
    
    @staticmethod
    def detections_to_lines(detections, base_y_threshold=15):
        """
        Group detections into lines with DYNAMIC threshold calculation
        Optimized for dense legal documents with tight line spacing
        
        Args:
            detections: List of detection dictionaries
            base_y_threshold: Minimum Y-axis threshold (default: 15px)
            
        Returns:
            List of text lines
        """
        if not detections:
            return []

        # Calculate DYNAMIC thresholds based on actual text heights
        heights = [det['size'][1] for det in detections if det['size'][1] > 0]
        widths = [det['size'][0] for det in detections if det['size'][0] > 0]
        
        if heights:
            median_h = sorted(heights)[len(heights) // 2]
            # CRITICAL: Use 70% of median height for dense text
            # Lower percentage = tighter grouping (prevents merging separate lines)
            y_threshold = max(base_y_threshold, int(0.7 * median_h))
            logger.info(f"   📏 Dynamic line threshold: {y_threshold}px (median height: {median_h}px)")
        else:
            y_threshold = base_y_threshold
        
        if widths:
            median_w = sorted(widths)[len(widths) // 2]
            avg_char_width = median_w / max(1, np.mean([len(d['text']) for d in detections]))
        else:
            avg_char_width = 10

        # Sort by position (top to bottom, left to right)
        sorted_dets = sorted(detections, key=lambda d: (d['center'][1], d['center'][0]))

        # Group into rows based on Y-coordinate
        rows = []
        current_row = [sorted_dets[0]]
        current_y = sorted_dets[0]['center'][1]

        for det in sorted_dets[1:]:
            y = det['center'][1]
            if abs(y - current_y) <= y_threshold:
                current_row.append(det)
            else:
                rows.append(current_row)
                current_row = [det]
                current_y = y
        
        if current_row:
            rows.append(current_row)

        logger.info(f"   📄 Grouped into {len(rows)} text lines")

        # Process each row with intelligent spacing
        all_lines = []
        for row in rows:
            # Sort left to right within the row
            row = sorted(row, key=lambda d: d['center'][0])
            line_text = SentenceBuilder._merge_row_intelligent(row, avg_char_width)
            if line_text.strip():
                all_lines.append(line_text)

        return all_lines
    
    @staticmethod
    def _merge_row_intelligent(row, avg_char_width):
        """
        Intelligently merge text fragments in a row
        Uses gap analysis to decide spacing
        """
        if not row:
            return ""
        
        result = row[0]['text']
        prev_right = row[0]['center'][0] + row[0]['size'][0] / 2
        
        for det in row[1:]:
            curr_left = det['center'][0] - det['size'][0] / 2
            gap = curr_left - prev_right
            
            # Intelligent spacing based on gap size:
            # - Small gap (< 1.5 chars): Direct concatenation (same word)
            # - Medium gap (< 3 chars): Single space (same phrase)
            # - Large gap (>= 3 chars): Field separator " | "
            
            if gap < avg_char_width * 1.5:
                # Same word (e.g., broken characters)
                result += det['text']
            elif gap < avg_char_width * 3:
                # Same phrase/sentence
                result += " " + det['text']
            else:
                # Different field (common in forms)
                result += " | " + det['text']
            
            prev_right = det['center'][0] + det['size'][0] / 2
        
        # Clean up: Remove extra spaces and redundant separators
        result = ' '.join(result.split())  # Normalize spaces
        result = result.replace(' |  | ', ' | ')  # Clean double separators
        result = result.replace('  |  ', ' | ')   # Clean spacing around separators
        
        return result
    
    @staticmethod
    def _merge_row_aggressive(row, avg_char_width):
        """
        DEPRECATED: Use _merge_row_intelligent instead
        Kept for backward compatibility
        """
        return SentenceBuilder._merge_row_intelligent(row, avg_char_width)
    
    @staticmethod
    def _join_line(detections_in_line, gap_factor=4.0):
        """
        Alternative method: Join detections with gap-based line splitting
        Used for very wide documents (receipts, invoices)
        """
        if not detections_in_line:
            return []

        # Sort left to right
        dets = sorted(detections_in_line, key=lambda d: d['center'][0])

        # Calculate average width for gap heuristic
        widths = [d['size'][0] for d in dets if d['size'][0] > 0]
        avg_w = sum(widths) / len(widths) if widths else 1.0

        segments = [[]]  # List of text segments
        prev_x = dets[0]['center'][0]

        # First word
        segments[0].append(dets[0]['text'])

        for det in dets[1:]:
            x = det['center'][0]
            gap = x - prev_x

            if gap > gap_factor * avg_w:
                # Large gap → start NEW logical segment
                segments.append([det['text']])
            else:
                # Same segment → add with space
                segments[-1].append(det['text'])

            prev_x = x

        # Convert each segment to a string
        lines = [" ".join(seg) for seg in segments if seg]
        return lines


# ============================================================
# ALTERNATIVE: Simple fallback implementation
# ============================================================

class SimpleSentenceBuilder:
    """
    Fallback implementation - basic line grouping
    Use this if the main SentenceBuilder causes issues
    """
    
    @staticmethod
    def detections_to_lines(detections, base_y_threshold=20):
        """Simple line grouping - no fancy logic"""
        if not detections:
            return []
        
        # Sort by Y coordinate
        sorted_dets = sorted(detections, key=lambda d: d['center'][1])
        
        # Group by Y proximity
        lines = []
        current_line = [sorted_dets[0]]
        
        for det in sorted_dets[1:]:
            if abs(det['center'][1] - current_line[-1]['center'][1]) < base_y_threshold:
                current_line.append(det)
            else:
                # Sort current line by X, then join
                current_line.sort(key=lambda d: d['center'][0])
                line_text = " ".join([d['text'] for d in current_line])
                lines.append(line_text)
                current_line = [det]
        
        # Don't forget last line
        if current_line:
            current_line.sort(key=lambda d: d['center'][0])
            line_text = " ".join([d['text'] for d in current_line])
            lines.append(line_text)
        
        return lines

if __name__ == "__main__":
    print("🧪 Testing Enhanced OCR Text Processor\n")
    print("✅ OCR Text Processor Module with Rotation Support Loaded")




