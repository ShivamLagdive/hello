"""
Pharma HMI Controller - Handles pharmaceutical packaging verification routes
COMPLETELY REWRITTEN - Clean, simple, working flow
"""
from flask import render_template, request
from pathlib import Path
import cv2
import numpy as np
from datetime import datetime
from typing import Dict, Tuple
import logging
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError

from backend.controllers.base_controller import BaseController
from backend.core.singleton import SingletonMeta
from backend.models.ocr_model import OCRModel
from backend.models.camera_model import CameraModel
from backend.models.session_model import SessionModel
from backend.services.video_stream_service import VideoStreamService
from backend.utils.image_utils import rotate_image, resize_image, encode_frame_to_base64
from backend.utils.validators import ValueExtractor
from backend.utils.response_helpers import success_response, error_response, handle_exception
from backend.config import (
    MAX_IMAGE_SIZE, JPEG_QUALITY, DEFAULT_SCAN_TYPE, VALID_SCAN_TYPES,
    VALID_ROTATION_ANGLES, WORKFLOW_STEPS, ERROR_MESSAGES
)

logger = logging.getLogger(__name__)


class PharmaController(BaseController, metaclass=SingletonMeta):
    """Controller for Pharma HMI - Completely rewritten"""
    
    _initialized = False
    
    def __init__(self, project_root: Path = None):
        """Initialize Pharma Controller"""
        if self._initialized:
            return
        
        if project_root is None:
            raise ValueError("project_root is required for first initialization")
        
        super().__init__(project_root, 'pharma', '/pharma')
        
        # Get singleton instances
        self.ocr_model = OCRModel()
        self.camera_model = CameraModel()
        self.session_model = SessionModel()
        
        # Initialize video stream service - Match camera FPS (10 FPS) to reduce lag
        self.video_service = VideoStreamService(
            camera=self.camera_model,
            max_fps=10,  # Match camera FPS (10) to prevent frame accumulation and lag
            cache_duration=0.05,  # Very short cache to minimize latency
            stream_width=960  # Resize to 960px width for faster encoding/transmission
        )
        self.video_service.start_streaming()
        
        # Shared thread pool for OCR processing (avoids creating new executor per request)
        # max_workers=2 allows one OCR task + one pending
        self._ocr_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="OCR")
        
        self._register_routes()
        self._initialized = True
    
    def _register_routes(self):
        """Register all routes"""
        routes = [
            ('/', 'GET', self.index),
            ('/api/status', 'GET', self.get_status),
            ('/api/capture', 'POST', self.capture_and_process),
            ('/api/verify', 'POST', self.verify_step),
            ('/api/rescan', 'POST', self.rescan_step),
            ('/api/next', 'POST', self.next_step),
            ('/api/reset', 'POST', self.reset_cycle),
            ('/api/frame', 'GET', self.get_frame),
            ('/api/stats', 'GET', self.get_stream_stats),
            ('/api/set_rotation', 'POST', self.set_rotation),
            ('/api/session', 'GET', self.get_session),
        ]
        
        for path, methods, handler in routes:
            self.blueprint.route(path, methods=[methods])(handler)
    
    def index(self):
        """Render main pharma HMI page"""
        try:
            session_id = self.get_session_id()
            session_data = self.session_model.get_session_dict(session_id)
            return render_template('pharma_hmi.html', session_data=session_data)
        except Exception as e:
            logger.error(f"Error rendering index: {e}", exc_info=True)
            return render_template('pharma_hmi.html', session_data={})
    
    def get_status(self) -> Tuple:
        """Get system status - NON-BLOCKING"""
        try:
            return success_response({
                'status': 'ready',
                'ocr_initialized': self.ocr_model.is_initialized(),
                'camera_initialized': self.camera_model.is_initialized(),
                'streaming': self.video_service.is_streaming()
            })
        except Exception as e:
            return handle_exception(e, "Failed to get status")
    
    def get_session(self) -> Tuple:
        """Get current session data - NON-BLOCKING, FAST"""
        try:
            session_id = self.get_session_id()
            session_data = self.session_model.get_session_dict(session_id)
            return success_response({'session_data': session_data})
        except Exception as e:
            logger.error(f"Error getting session: {e}", exc_info=True)
            # Return default session on error - don't block
            return success_response({
                'session_data': {
                    'current_step': 'tag',
                    'cycle_count': 0,
                    'weight_value': '',
                    'tag_value': '',
                    'box_label_value': '',
                    'camera_rotation': 0
                }
            })
    
    def get_frame(self) -> Tuple:
        """Get current camera frame"""
        try:
            frame_data, metadata = self.video_service.get_frame()
            
            if frame_data:
                return success_response({
                    'frame': frame_data,
                    'metadata': metadata
                })
            else:
                return error_response(
                    ERROR_MESSAGES['no_frame_available'],
                    status_code=404,
                    details=metadata
                )
        except Exception as e:
            return handle_exception(e, "Failed to get frame")
    
    def get_stream_stats(self) -> Tuple:
        """Get video stream statistics"""
        try:
            stats = self.video_service.get_statistics()
            return success_response(stats)
        except Exception as e:
            return handle_exception(e, "Failed to get statistics")
    
    def capture_and_process(self) -> Tuple:
        """Capture and process image with OCR"""
        try:
            data = request.get_json() or {}
            scan_type = data.get('scan_type', DEFAULT_SCAN_TYPE)
            session_id = self.get_session_id()
            
            if scan_type not in VALID_SCAN_TYPES:
                return error_response(
                    f"{ERROR_MESSAGES['invalid_scan_type']}. Must be one of: {VALID_SCAN_TYPES}",
                    status_code=400
                )
            
            rotation = data.get('rotation')
            if rotation is None:
                session_state = self.session_model.get_session(session_id)
                rotation = session_state.camera_rotation
            rotation = int(rotation)
            
            if rotation not in VALID_ROTATION_ANGLES:
                return error_response(ERROR_MESSAGES['invalid_rotation'], status_code=400)
            
            # Get frame from video stream service to avoid concurrent camera access issues
            # This prevents MJPEG boundary errors when both streaming and capturing
            frame = None
            
            # Try to get frame from video stream service (preferred - avoids camera conflicts)
            for attempt in range(3):
                frame = self.video_service.get_raw_frame()
                if frame is not None:
                    break
                # Small delay to allow video stream to capture a frame
                time.sleep(0.1)
            
            # Fallback to direct capture only if video service has no frame
            if frame is None:
                logger.warning("No frame available from video service after retries, attempting direct capture")
                # CameraModel.capture_frame() now returns image path, not numpy array
                image_path = self.camera_model.capture_frame()
                if image_path is None:
                    return error_response(ERROR_MESSAGES['capture_failed'], status_code=500)
                
                # Read image from path
                try:
                    frame = cv2.imread(image_path)
                    if frame is None:
                        logger.error(f"Could not read captured image: {image_path}")
                        return error_response(ERROR_MESSAGES['capture_failed'], status_code=500)
                except Exception as e:
                    logger.error(f"Error reading captured image {image_path}: {e}")
                    return error_response(ERROR_MESSAGES['capture_failed'], status_code=500)
            
            if rotation != 0:
                frame = rotate_image(frame, rotation)
            
            # Process with timeout using shared thread pool
            # This avoids creating new executor per request (saves ~10-50ms)
            future = self._ocr_executor.submit(self._process_captured_frame, frame, scan_type)
            
            try:
                result = future.result(timeout=30)  # 30 second timeout for OCR processing
            except FutureTimeoutError:
                logger.error("OCR processing timed out after 30 seconds")
                future.cancel()
                return error_response(
                    "OCR processing timed out. Please try again.",
                    status_code=504
                )
            
            if result.get('success'):
                return success_response(result)
            else:
                return error_response(
                    result.get('error', ERROR_MESSAGES['processing_failed']),
                    status_code=500
                )
            
        except ValueError as e:
            return error_response(str(e), status_code=400)
        except Exception as e:
            return handle_exception(e, ERROR_MESSAGES['processing_failed'])
    
    def _process_captured_frame(self, frame: np.ndarray, scan_type: str) -> Dict:
        """Process captured frame"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        capture_dir = self.project_root / 'data' / 'captures'
        capture_dir.mkdir(parents=True, exist_ok=True)
        
        filename = f"{scan_type}_{timestamp}.jpg"
        filepath = capture_dir / filename
        
        frame = resize_image(frame, max_size=MAX_IMAGE_SIZE)
        cv2.imwrite(str(filepath), frame)
        logger.info(f"Saved capture: {filepath}")
        
        result = self.ocr_model.process_image(str(filepath), save_outputs=True, scan_type=scan_type)
        
        if not result.get('success'):
            return {
                'success': False,
                'error': result.get('error', ERROR_MESSAGES['processing_failed'])
            }
        
        full_text = result.get('full_text', '')
        extracted_value = ValueExtractor.extract(scan_type, full_text)
        frame_data = encode_frame_to_base64(frame, quality=JPEG_QUALITY)
        
        return {
            'success': True,
            'extracted_value': extracted_value,
            'full_text': full_text,
            'frame': frame_data,
            'result': result,
            'filepath': str(filepath)
        }
    
    def verify_step(self) -> Tuple:
        """Verify current step"""
        try:
            data = request.get_json() or {}
            session_id = self.get_session_id()
            session_state = self.session_model.get_session(session_id)
            
            extracted_value = data.get('extracted_value')
            if not extracted_value:
                return error_response(ERROR_MESSAGES['no_value_extracted'], status_code=400)
            
            step_value_key = f'{session_state.current_step}_value'
            self.session_model.update_session(session_id, {step_value_key: extracted_value})
            
            return success_response({
                'step': session_state.current_step,
                'value': extracted_value
            }, message='Step verified')
            
        except Exception as e:
            return handle_exception(e, "Failed to verify step")
    
    def rescan_step(self) -> Tuple:
        """Rescan current step - clear value and captured image"""
        try:
            session_id = self.get_session_id()
            session_state = self.session_model.get_session(session_id)
            
            # Clear the current step's value
            step_value_key = f'{session_state.current_step}_value'
            self.session_model.update_session(session_id, {
                step_value_key: '',
                'captured_image': None
            })
            
            return success_response({
                'step': session_state.current_step,
                'cleared': True
            }, message='Value cleared')
        except Exception as e:
            return handle_exception(e, "Failed to rescan")
    
    def next_step(self) -> Tuple:
        """Move to next step - FAST, NO LOCKS, NO LOGGING"""
        try:
            session_id = self.get_session_id()
            session_state = self.session_model.get_session(session_id)
            current_step = session_state.current_step or 'tag'
            
            # Find next step
            if current_step not in WORKFLOW_STEPS:
                current_step = 'tag'
            
            current_index = WORKFLOW_STEPS.index(current_step)
            
            # Calculate next step
            if current_index < len(WORKFLOW_STEPS) - 1:
                next_step = WORKFLOW_STEPS[current_index + 1]
                self.session_model.update_session(session_id, {'current_step': next_step})
                
                return success_response({
                    'success': True,
                    'next_step': next_step,
                    'current_step': next_step,
                    'cycle_complete': False
                })
            else:
                # Cycle complete
                cycle_count = self.session_model.increment_cycle(session_id)
                self.session_model.reset_session(session_id, preserve_cycle=True)
                
                return success_response({
                    'success': True,
                    'cycle_complete': True,
                    'cycle_count': cycle_count,
                    'next_step': 'tag',
                    'current_step': 'tag'
                })
            
        except Exception as e:
            logger.error(f"Error in next_step: {e}", exc_info=True)
            return error_response(f"Error: {str(e)}", status_code=500)
    
    def reset_cycle(self) -> Tuple:
        """Reset to start new cycle"""
        try:
            session_id = self.get_session_id()
            self.session_model.reset_session(session_id)
            return success_response(message='Cycle reset')
        except Exception as e:
            return handle_exception(e, "Failed to reset cycle")
    
    def set_rotation(self) -> Tuple:
        """Set camera rotation angle"""
        try:
            data = request.get_json() or {}
            rotation_angle = int(data.get('rotation_angle', 0))
            
            if rotation_angle not in VALID_ROTATION_ANGLES:
                return error_response(ERROR_MESSAGES['invalid_rotation'], status_code=400)
            
            session_id = self.get_session_id()
            self.session_model.update_session(session_id, {
                'camera_rotation': rotation_angle
            })
            
            return success_response({'rotation_angle': rotation_angle})
        except ValueError as e:
            return error_response(str(e), status_code=400)
        except Exception as e:
            return handle_exception(e, "Failed to set rotation")
    
    def cleanup(self):
        """Cleanup resources"""
        try:
            if hasattr(self, 'video_service'):
                self.video_service.stop_streaming()
            if hasattr(self, '_ocr_executor'):
                self._ocr_executor.shutdown(wait=False, cancel_futures=True)
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
