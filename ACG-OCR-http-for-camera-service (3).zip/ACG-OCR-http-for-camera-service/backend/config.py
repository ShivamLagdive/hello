"""
Application Configuration - Centralized constants and settings
"""
from pathlib import Path
from typing import Dict, Set

# Image Processing Constants
MAX_IMAGE_SIZE = 960
JPEG_QUALITY = 85
JPEG_OPTIMIZE = True

# Video Streaming Constants
DEFAULT_MAX_FPS = 10  # Match camera FPS to prevent frame accumulation and lag
FRAME_CACHE_DURATION = 0.05  # Very short cache to minimize latency
FRAME_BUFFER_SIZE = 1  # Minimal buffer - always show latest frame
# STREAM_WIDTH = 640  # Target width for streaming frames (reduces data size)
STREAM_WIDTH = 960  # Target width for streaming frames (reduces data size)

# Pharma HMI Constants
DEFAULT_SCAN_TYPE = 'weight'
VALID_SCAN_TYPES: Set[str] = {'tag', 'weight', 'box_label'}
VALID_ROTATION_ANGLES: Set[int] = {0, 90, 180, 270}
WORKFLOW_STEPS = ['tag', 'weight', 'box_label']

# File Upload Constants
ALLOWED_IMAGE_EXTENSIONS: Set[str] = {'jpg', 'jpeg', 'png', 'bmp', 'tiff', 'webp'}
MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # 10MB

# Session Constants
DEFAULT_SESSION_STATE = {
    'current_step': 'tag',
    'cycle_count': 0,
    'weight_value': '',
    'tag_value': '',
    'box_label_value': '',
    'notification': None,
    'captured_image': None,
    'camera_rotation': 0
}

# Error Messages
ERROR_MESSAGES = {
    'camera_not_initialized': 'Camera not initialized',
    'ocr_not_initialized': 'OCR system not initialized',
    'invalid_scan_type': 'Invalid scan type',
    'invalid_rotation': 'Invalid rotation angle',
    'no_frame_available': 'No frame available',
    'capture_failed': 'Failed to capture frame',
    'processing_failed': 'Processing failed',
    'no_value_extracted': 'No value extracted',
    'invalid_file_type': 'Invalid file type',
    'file_too_large': 'File too large'
}

def get_camera_config(project_root: Path) -> Dict:
    """
    Get default camera configuration
    
    ⚠️ IMPORTANT: Resolution and FPS settings significantly affect network camera performance:
    
    **Resolution Impact:**
    - Higher resolution = More bandwidth, more latency, more MJPEG parsing errors
    - 1280x720 = ~1.3 MB per frame (at JPEG quality 75)
    - 640x480 = ~200 KB per frame (75% less data!)
    - For network cameras, lower resolution = more stable stream
    
    **FPS Impact:**
    - Higher FPS = More frames/second = More bandwidth
    - 10 FPS at 1280x720 = ~13 MB/second
    - 5 FPS at 640x480 = ~1 MB/second (much more stable)
    - Network cameras often struggle with high FPS + high resolution
    
    **Recommended Settings:**
    - Network Camera (IP Webcam): 640x480 @ 5-10 FPS
    - USB Camera: Can handle higher (1280x720 @ 10-15 FPS)
    
    Camera ID options:
    - USB Camera: Use integer (0, 1, 2, etc.) - e.g., 'camera_id': 0
    - Network Camera: Use URL string
      - IP Webcam app: "http://YOUR_IP:8080/video" or "http://YOUR_IP:8080/shot.jpg"
      - Other IP cameras: "http://YOUR_IP:PORT/stream_path"
    
    Troubleshooting network cameras:
    - Run: python test_camera_connection.py <your_url> to diagnose issues
    - Check that camera is on the same network
    - Verify URL works in browser (try /shot.jpg endpoint)
    - Check firewall settings
    - Lower resolution/FPS if experiencing MJPEG parsing errors
    """
    # Optimized for network cameras - lower resolution for stability
    return {
        'camera_id': "http://10.76.64.32:8080/video",  # Change to your camera IP/URL or USB ID (0, 1, etc.)
        # 'camera_id': 0,  # Uncomment for USB camera
        
        # For network cameras: Lower resolution = more stable, less bandwidth
        'resolution': (960, 540),  # Optimized for Raspberry Pi
        'framerate': 10,  
        
        # For USB cameras, you can use higher settings:
        # 'resolution': (1280, 720),
        # 'framerate': 10,
        
        'capture_dir': str(project_root / 'data' / 'captures'),
        'max_capture_size': MAX_IMAGE_SIZE
    }

