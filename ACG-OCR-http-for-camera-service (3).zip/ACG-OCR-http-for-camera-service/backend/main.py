"""
Main entry point for MVC Flask Backend
Run: python -m backend.main
"""
from pathlib import Path
import sys
import logging
import signal
import atexit

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backend.app import create_app
from backend.config import get_camera_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global references for cleanup
_app = None
_cleanup_done = False


def cleanup_resources():
    """Cleanup all application resources"""
    global _cleanup_done
    
    if _cleanup_done:
        return
    
    _cleanup_done = True
    logger.info("🧹 Starting resource cleanup...")
    
    try:
        # Mark OCR model as shutting down before cleanup
        from backend.models.ocr_model import OCRModel
        OCRModel.mark_shutting_down()
        
        # Cleanup OCR model (this releases PaddleOCR instances)
        ocr_model = OCRModel()
        if ocr_model.is_initialized():
            ocr_model.cleanup()
        
        # Cleanup camera model
        from backend.models.camera_model import CameraModel
        camera_model = CameraModel()
        if camera_model.is_initialized():
            camera_model.cleanup()
        
        # Cleanup controllers
        from backend.controllers.pharma_controller import PharmaController
        pharma_controller = PharmaController()
        if hasattr(pharma_controller, 'cleanup'):
            pharma_controller.cleanup()
        
        logger.info("✅ Resource cleanup complete")
    except Exception as e:
        logger.error(f"Error during resource cleanup: {e}", exc_info=True)


def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info(f"\n⚠️ Received signal {signum}, shutting down...")
    cleanup_resources()
    # Exit immediately to prevent PaddlePaddle's cleanup from running
    # This prevents the SIGABRT crash during shutdown
    import os
    os._exit(0)  # Use _exit to bypass Python's cleanup handlers (including PaddlePaddle)


def main():
    """Main entry point"""
    global _app
    
    print("\n" + "="*70)
    print("🏭 ACG-OCR - MVC Flask Backend")
    print("="*70 + "\n")
    
    # Register signal handlers for shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    # Register atexit handler as backup (only runs on normal exit)
    atexit.register(cleanup_resources)
    
    # Get camera configuration from config module (optional, kept for compatibility)
    camera_config = get_camera_config(PROJECT_ROOT)
    
    # Create Flask app (camera is now accessed via Camera Service)
    print("🔧 Initializing application components...")
    try:
        _app = create_app(PROJECT_ROOT, camera_config)
        print("✅ Application components initialized")
    except Exception as e:
        logger.error(f"Failed to initialize application: {e}", exc_info=True)
        print(f"❌ Failed to initialize application: {e}")
        raise
    
    # Check camera service status (non-blocking, quick check)
    print("🔍 Checking camera service status...")
    try:
        from backend.models.camera_model import CameraModel
        camera_model = CameraModel()
        # Quick non-blocking check with timeout
        if camera_model.is_initialized():
            print("✅ Camera service connection established")
        else:
            print("⚠️  Camera service not available - app will start but camera features may not work")
            print("   Make sure camera_service.py is running on Python 3.13")
            print("   Camera features will be checked on-demand")
    except Exception as e:
        logger.warning(f"Camera service check failed: {e}")
        print("⚠️  Could not check camera service status - app will continue")
    
    print("\n" + "="*70)
    print("🚀 Backend Server Starting...")
    print("="*70)
    print("\n📍 Access your applications:")
    print("   • Root:              http://localhost:5000")
    print("   • Pharma HMI:        http://localhost:5000/pharma")
    print("   • OCR Dashboard:     http://localhost:5000/ocr")
    print("   • Manual Upload testing:     http://localhost:5000/test")

    print("\n" + "="*70 + "\n")
    
    try:
        _app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n\n⚠️ Shutting down...")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
    finally:
        cleanup_resources()
        print("✅ Shutdown complete")


if __name__ == "__main__":
    main()
