"""
OCR Model - Handles OCR system initialization and processing
Refactored with singleton pattern and context managers
"""
from pathlib import Path
from typing import Optional, Dict, Any
import logging

from backend.core.singleton import SingletonMeta
from backend.utils.context_managers import working_directory, add_to_path

logger = logging.getLogger(__name__)


class OCRModel(metaclass=SingletonMeta):
    """Model for OCR operations with proper resource management - Singleton"""
    
    _initialized = False
    _shutting_down = False  # Flag to prevent accidental cleanup during normal operation
    _recovery_attempted = False  # Flag to prevent repeated recovery attempts
    
    def __init__(self, project_root: Path = None):
        """
        Initialize OCR Model (singleton - only initialized once)
        
        Args:
            project_root: Project root directory (required on first call)
        """
        # If already initialized with a working OCR system, just return
        if hasattr(self, '_ocr_system') and self._ocr_system is not None:
            return
        
        # If _initialized flag is set but OCR system is None (recovery case)
        # or if this is first initialization
        if hasattr(self, '_initialized') and self._initialized and hasattr(self, 'project_root'):
            # Recovery case: OCR system was lost but we have project_root
            if self._ocr_system is None:
                if project_root is None:
                    project_root = self.project_root  # Use existing project_root
                else:
                    self.project_root = project_root
                # Reinitialize OCR system
                self._initialize_ocr()
                return
        
        # First initialization - project_root is required
        if project_root is None:
            raise ValueError("project_root is required for first initialization")
        
        self.project_root = project_root
        self.script_dir = project_root / "scripts"
        self._ocr_system: Optional[Any] = None
        
        # Try to initialize OCR, but don't fail if it crashes
        try:
            self._initialize_ocr()
        except Exception as e:
            logger.error(f"OCR initialization failed, but continuing: {e}")
            # Set _ocr_system to None to indicate initialization failed
            self._ocr_system = None
        
        self._initialized = True
        OCRModel._initialized = True  # Set class variable too
    
    def _initialize_ocr(self) -> None:
        """Initialize OCR system with proper error handling"""
        try:
            if not self.script_dir.exists():
                raise FileNotFoundError(f"Scripts directory not found: {self.script_dir}")
            
            logger.info("Loading OCR modules...")
            with add_to_path(self.script_dir):
                from main_ocr_system import AdvancedOCRSystem
                from config_manager import OCRConfig
                
                config_path = self.script_dir / 'ocr_config.yaml'
                if not config_path.exists():
                    # Create default config
                    config = OCRConfig()
                    config.save_config(str(config_path))
                    logger.info("Created default OCR config")
                
                logger.info("Initializing AdvancedOCRSystem (this may take 10-30 seconds)...")
                # Change to scripts directory for initialization
                with working_directory(self.script_dir):
                    try:
                        self._ocr_system = AdvancedOCRSystem(config_path=str(config_path))
                        logger.info("✅ OCR System initialized")
                    except SystemExit as e:
                        # PaddleOCR sometimes calls sys.exit() on errors
                        logger.error(f"❌ OCR System crashed during initialization: {e}")
                        logger.error("This may be due to memory issues, GPU conflicts, or library problems")
                        self._ocr_system = None
                        raise RuntimeError(f"OCR initialization crashed: {e}")
                    except Exception as e:
                        # Catch any other crashes (SIGTERM, etc.)
                        logger.error(f"❌ OCR System crashed during initialization: {e}")
                        logger.error("This may be due to memory issues, GPU conflicts, or library problems")
                        self._ocr_system = None
                        raise
                    
        except ImportError as e:
            logger.error(f"❌ Failed to import OCR modules: {e}")
            self._ocr_system = None
            raise
        except Exception as e:
            logger.error(f"❌ OCR initialization failed: {e}", exc_info=True)
            self._ocr_system = None
            raise
    
    def process_image(self, image_path: str, save_outputs: bool = True, scan_type: Optional[str] = None) -> Dict[str, Any]:
        """
        Process image with OCR
        
        Args:
            image_path: Path to image file
            save_outputs: Whether to save output files
            scan_type: Optional scan type ('tag', 'weight', 'box_label')
        
        Returns:
            Processing result dictionary
        
        Raises:
            RuntimeError: If OCR system is not initialized and cannot be reinitialized
        """
        # Check if OCR system is initialized, and try to recover if it's not
        if not self._ocr_system:
            # Check if we've already attempted recovery (to prevent repeated attempts)
            recovery_key = f"_recovery_attempted_{id(self)}"
            if getattr(self, '_recovery_attempted', False) or OCRModel._recovery_attempted:
                logger.error("❌ OCR system not initialized and recovery already attempted - cannot recover")
                return {
                    'success': False,
                    'error': "OCR system not initialized and recovery failed previously. Please restart the application."
                }
            
            logger.warning("⚠️ OCR system not initialized, attempting recovery...")
            # Only try to reinitialize if we have project_root (from previous initialization)
            if hasattr(self, 'project_root') and self.project_root:
                try:
                    logger.info("🔄 Attempting to reinitialize OCR system...")
                    self._initialize_ocr()
                    self._initialized = True
                    OCRModel._recovery_attempted = True  # Mark recovery as attempted
                    self._recovery_attempted = True
                    logger.info("✅ OCR system recovered successfully")
                except Exception as e:
                    logger.error(f"❌ Failed to recover OCR system: {e}", exc_info=True)
                    OCRModel._recovery_attempted = True  # Mark as attempted even on failure
                    self._recovery_attempted = True
                    return {
                        'success': False,
                        'error': f"OCR system not initialized and recovery failed: {str(e)}"
                    }
            else:
                logger.error("❌ Cannot recover OCR system: project_root not available")
                OCRModel._recovery_attempted = True
                self._recovery_attempted = True
                return {
                    'success': False,
                    'error': "OCR system not initialized and cannot be recovered"
                }
        
        try:
            with working_directory(self.script_dir):
                result = self._ocr_system.process_image(image_path, save_outputs=save_outputs, scan_type=scan_type)
                return result
        except Exception as e:
            # Check if the exception might indicate the OCR system is broken
            error_msg = str(e).lower()
            # Don't try to recover on every error, only on specific failure conditions
            # that might indicate the system needs reinitialization
            if any(keyword in error_msg for keyword in ['not initialized', 'deleted', 'cleanup', 'destroyed']):
                logger.error(f"❌ OCR system appears to be broken: {e}")
                logger.warning("⚠️ OCR system will be marked as uninitialized for next request")
                # Don't set _ocr_system to None here - let the next request handle recovery
                # This prevents infinite reinitialization loops
            raise
    
    @property
    def ocr_system(self) -> Optional[Any]:
        """Get OCR system instance (read-only)"""
        return self._ocr_system
    
    def is_initialized(self) -> bool:
        """Check if OCR system is initialized"""
        return self._ocr_system is not None
    
    def cleanup(self):
        """Cleanup OCR system resources
        
        NOTE: This should only be called during application shutdown, not during
        normal operation. This method sets a flag to prevent cleanup from being
        called multiple times or during normal operation.
        """
        # Prevent cleanup from being called during normal operation
        if not getattr(self, '_shutting_down', False) and not OCRModel._shutting_down:
            logger.warning("⚠️ cleanup() called but _shutting_down flag not set - skipping to prevent accidental cleanup")
            return
        
        try:
            if self._ocr_system:
                logger.info("🧹 Cleaning up OCR model...")
                # Call cleanup on the OCR system
                if hasattr(self._ocr_system, 'cleanup'):
                    self._ocr_system.cleanup()
                self._ocr_system = None
                logger.info("✅ OCR model cleaned up")
        except Exception as e:
            logger.error(f"Error during OCR model cleanup: {e}")
    
    @classmethod
    def mark_shutting_down(cls):
        """Mark the OCR model as shutting down - call this before cleanup"""
        cls._shutting_down = True