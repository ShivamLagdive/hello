"""
Backend package initialization
"""

