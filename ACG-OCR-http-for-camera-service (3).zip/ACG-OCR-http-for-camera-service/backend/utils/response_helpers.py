"""
Response Helpers - Standardized API response formatting
"""
from flask import jsonify
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger(__name__)


def success_response(data: Any = None, message: str = None, status_code: int = 200) -> tuple:
    """
    Create standardized success response
    
    Args:
        data: Response data
        message: Optional success message
        status_code: HTTP status code
    
    Returns:
        Tuple of (jsonify response, status_code)
    """
    response: Dict[str, Any] = {'success': True}
    if message:
        response['message'] = message
    if data is not None:
        if isinstance(data, dict):
            response.update(data)
        else:
            response['data'] = data
    return jsonify(response), status_code


def error_response(
    error: str,
    status_code: int = 400,
    details: Optional[Dict] = None
) -> tuple:
    """
    Create standardized error response
    
    Args:
        error: Error message
        status_code: HTTP status code
        details: Optional additional error details
    
    Returns:
        Tuple of (jsonify response, status_code)
    """
    response: Dict[str, Any] = {
        'success': False,
        'error': error
    }
    if details:
        response['details'] = details
    return jsonify(response), status_code


def handle_exception(e: Exception, default_message: str = "An error occurred") -> tuple:
    """
    Handle exception and return error response
    
    Args:
        e: Exception instance
        default_message: Default error message
    
    Returns:
        Tuple of (jsonify response, status_code)
    """
    logger.error(f"Exception: {e}", exc_info=True)
    return error_response(str(e) or default_message, status_code=500)

