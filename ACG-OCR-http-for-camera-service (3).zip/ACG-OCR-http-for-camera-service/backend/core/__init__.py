"""
Core package - Singleton pattern and base classes
"""
from .singleton import SingletonMeta

__all__ = ['SingletonMeta']

