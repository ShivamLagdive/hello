/**
 * Pharma HMI Application
 * COMPLETELY REWRITTEN - Clean, working flow
 */
(function() {
    'use strict';

    // ============================================================================
    // STATE
    // ============================================================================
    
    const state = {
        currentStep: 'tag',
        cycleCount: 0,
        cameraRotation: 0,
        sessionState: {
    weight_value: '',
    tag_value: '',
    box_label_value: '',
            captured_image: null
        },
        nextStepInProgress: false,
        cameraFeedInterval: null,
        lastFrameTime: 0
    };

    const config = {
        FRAME_INTERVAL: 100,  // 100ms = 10 FPS to match camera and reduce lag
        WORKFLOW_STEPS: ['tag', 'weight', 'box_label'],
        STEP_NAMES: {
            'tag': 'Tag Scan',
            'weight': 'Weight Scan',
            'box_label': 'Box Label'
        }
    };

    // ============================================================================
    // API
    // ============================================================================

    const api = {
        async request(url, options = {}) {
            const defaults = {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                credentials: 'same-origin'
            };

            const response = await fetch(url, { ...defaults, ...options });
            
            if (!response.ok) {
                let errorData;
                try {
                    errorData = await response.json();
                } catch {
                    errorData = { error: `HTTP ${response.status}` };
                }
                throw new Error(errorData.error || errorData.message || `HTTP ${response.status}`);
            }

            return response.json();
        },

        async getSession() {
            return this.request('/pharma/api/session');
        },

        async getStatus() {
            return this.request('/pharma/api/status');
        },

        async getFrame() {
            return this.request('/pharma/api/frame');
        },

        async nextStep() {
            console.log('🌐 [API] Fetching /pharma/api/next');
            const startTime = Date.now();
            
            try {
                const response = await fetch('/pharma/api/next', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    credentials: 'same-origin'
                });
                
                const elapsed = Date.now() - startTime;
                console.log(`🌐 [API] Response received in ${elapsed}ms. Status: ${response.status}`);
                
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('❌ [API] Error response:', errorText);
                    throw new Error(`HTTP ${response.status}: ${errorText}`);
                }
                
                const data = await response.json();
                console.log('🌐 [API] Parsed JSON:', data);
                return data;
            } catch (error) {
                console.error('❌ [API] Fetch error:', error);
                throw error;
            }
        },

        async verify(extractedValue) {
            return this.request('/pharma/api/verify', {
                method: 'POST',
                body: JSON.stringify({ extracted_value: extractedValue })
            });
        },

        async capture(scanType, rotation) {
            return this.request('/pharma/api/capture', {
                method: 'POST',
                body: JSON.stringify({ 
                    scan_type: scanType,
                    rotation: rotation
                })
            });
        },

        async setRotation(angle) {
            return this.request('/pharma/api/set_rotation', {
        method: 'POST',
                body: JSON.stringify({ rotation_angle: angle })
            });
        },

        async rescan() {
            return this.request('/pharma/api/rescan', {
                method: 'POST'
            });
        }
    };

    // ============================================================================
    // UI
    // ============================================================================

    const ui = {
        updateStepDisplay(step) {
    const stepMap = {
        'tag': { elementId: 'step-tag', statusId: 'tag-status' },
        'weight': { elementId: 'step-weight', statusId: 'weight-status' },
        'box_label': { elementId: 'step-box-label', statusId: 'box-status' }
    };
    
            if (!step || !stepMap[step]) {
                console.error(`Invalid step: ${step}`);
                return;
            }

            // Reset all
    Object.values(stepMap).forEach(({ elementId, statusId }) => {
                const el = document.getElementById(elementId);
                const status = document.getElementById(statusId);
                if (el) {
                    el.classList.remove('step-active');
                    el.classList.add('step-inactive');
        }
                if (status) {
                    status.textContent = 'Waiting...';
        }
    });
    
            // Activate current
    const current = stepMap[step];
            const el = document.getElementById(current.elementId);
            const status = document.getElementById(current.statusId);
        
            if (el) {
                el.classList.remove('step-inactive');
                el.classList.add('step-active');
        }

            if (status) {
                status.textContent = '🔵 Active';
                if (step === 'tag' && state.sessionState.tag_value) {
                    status.textContent = `✅ ${state.sessionState.tag_value}`;
                } else if (step === 'weight' && state.sessionState.weight_value) {
                    status.textContent = `✅ ${state.sessionState.weight_value}`;
                } else if (step === 'box_label' && state.sessionState.box_label_value) {
                    status.textContent = `✅ ${state.sessionState.box_label_value}`;
        }
    }
        },

        updateVerificationPanel() {
    const panel = document.getElementById('verification-panel');
            if (!panel) {
                console.error('❌ [UI] verification-panel element not found!');
                return;
            }

            const step = state.currentStep;
            console.log(`🎨 [UI] updateVerificationPanel() called. state.currentStep = '${step}'`);
    
    let html = '';
    
            if (step === 'tag') {
                console.log('🎨 [UI] Rendering TAG step');
                html = this.renderTagStep();
            } else if (step === 'weight') {
                console.log('🎨 [UI] Rendering WEIGHT step');
                html = this.renderWeightStep();
            } else if (step === 'box_label') {
                console.log('🎨 [UI] Rendering BOX_LABEL step');
                html = this.renderBoxLabelStep();
            } else {
                console.error(`❌ [UI] Unknown step: '${step}'`);
                html = `<div>Unknown step: ${step}</div>`;
            }

            console.log(`🎨 [UI] Setting panel HTML (length: ${html.length})`);
            panel.innerHTML = html;
            console.log(`✅ [UI] Panel updated. Current step displayed: '${step}'`);
        },

        renderTagStep() {
            const hasValue = !!state.sessionState.tag_value;
            return `
            <div class="verification-step active">
                <h3>🏷️ Step 1: Tag Scan</h3>
                    ${hasValue ? 
                        `<div class="value-display">${state.sessionState.tag_value}</div>` :
                    `<div class="st-info">📸 Hold tag below camera...</div>
                         <button class="btn-primary stButton" data-action="capture-tag" style="width: 100%; margin-top: 10px; padding: 0.75rem;">
                        🎯 Capture Tag
                     </button>`
                }
                    ${hasValue ? `
                    <div class="step-buttons">
                            <button class="btn-success stButton" data-action="confirm-and-next" style="flex: 2;">✅ Confirm and Next</button>
                            <button class="btn-warning stButton" data-action="rescan" data-step="tag" style="flex: 1;">🔄 Rescan</button>
                    </div>
                ` : ''}
            </div>
        `;
        },

        renderWeightStep() {
            const hasValue = !!state.sessionState.weight_value;
            return `
            <div class="verification-step active">
                <h3>⚖️ Step 2: Weight Verification</h3>
                    ${hasValue ? 
                        `<div class="value-display">${state.sessionState.weight_value}</div>` :
                    `<div class="st-info">📸 Waiting for weight scan (Screen must be Red/Green)...</div>
                         <button class="btn-primary stButton" data-action="capture-weight" style="width: 100%; margin-top: 10px; padding: 0.75rem;">
                        🎯 Capture Weight
                     </button>`
                }
                    ${hasValue ? `
                    <div class="step-buttons">
                            <button class="btn-success stButton" data-action="confirm-and-next" style="flex: 2;">✅ Confirm and Next</button>
                            <button class="btn-warning stButton" data-action="rescan" data-step="weight" style="flex: 1;">🔄 Rescan</button>
                    </div>
                ` : ''}
            </div>
        `;
        },

        renderBoxLabelStep() {
            const hasValue = !!state.sessionState.box_label_value;
            return `
            <div class="verification-step active">
                <h3>📦 Step 3: Box Label & Machine Number</h3>
                    ${hasValue ? 
                        `<div class="value-display">${state.sessionState.box_label_value}</div>` :
                    `<div class="st-info">📸 Waiting for box label...</div>
                         <button class="btn-primary stButton" data-action="capture-box" style="width: 100%; margin-top: 10px; padding: 0.75rem;">
                        🎯 Capture Box Label
                     </button>`
                }
                    ${hasValue ? `
                    <div class="step-buttons">
                            <button class="btn-success stButton" data-action="complete" style="flex: 2;">✅ Complete Cycle</button>
                            <button class="btn-warning stButton" data-action="rescan" data-step="box_label" style="flex: 1;">🔄 Rescan</button>
                    </div>
                ` : ''}
            </div>
        `;
        },

        updateCycleCount() {
            const el = document.getElementById('cycle-count');
            if (el) el.textContent = state.cycleCount;
        },

        updateSummary() {
            const elements = {
                cycle: document.getElementById('summary-cycle'),
                step: document.getElementById('summary-step'),
                weight: document.getElementById('summary-weight'),
                tag: document.getElementById('summary-tag'),
                box: document.getElementById('summary-box')
            };

            if (elements.cycle) elements.cycle.textContent = state.cycleCount;
            if (elements.step) elements.step.textContent = config.STEP_NAMES[state.currentStep] || state.currentStep;
            if (elements.weight) elements.weight.textContent = state.sessionState.weight_value || 'Not scanned';
            if (elements.tag) elements.tag.textContent = state.sessionState.tag_value || 'Not scanned';
            if (elements.box) elements.box.textContent = state.sessionState.box_label_value || 'Not scanned';
        },

        showNotification(message, type) {
            const area = document.getElementById('notification-area');
            if (!area) return;

            const notification = document.createElement('div');
            notification.className = `notification-box notification-${type}`;
            notification.textContent = message;

            area.innerHTML = '';
            area.appendChild(notification);

            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 5000);
        },

        applyRotation() {
            const wrapper = document.getElementById('camera-wrapper');
            if (wrapper) {
                wrapper.style.transform = `rotate(${state.cameraRotation}deg)`;
            }
        },

        updateRotationButtons() {
            document.querySelectorAll('.btn-rotation').forEach(btn => {
                const angle = parseInt(btn.getAttribute('data-rotation'));
                if (angle === state.cameraRotation) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
}
            });
        }
    };

    // ============================================================================
    // ACTIONS
    // ============================================================================

    const actions = {
        async nextStep() {
            // Calculate next step locally (instant, no API wait)
            const currentIndex = config.WORKFLOW_STEPS.indexOf(state.currentStep);
            
            if (currentIndex < config.WORKFLOW_STEPS.length - 1) {
                const nextStep = config.WORKFLOW_STEPS[currentIndex + 1];
                
                // Update UI IMMEDIATELY (0ms delay!)
                state.currentStep = nextStep;
                state.sessionState.captured_image = null;
                
                const stepName = config.STEP_NAMES[nextStep] || nextStep;
                ui.updateStepDisplay(state.currentStep);
                ui.updateVerificationPanel();
                ui.updateSummary();
                ui.showNotification(`Moving to ${stepName}`, 'info');
                
                // Sync with backend in background (non-blocking)
                api.nextStep().catch(err => {
                    console.error('Backend sync failed:', err);
                    // UI already updated, user doesn't notice
                });
            } else {
                // Cycle complete
                state.cycleCount++;
                state.currentStep = 'tag';
                state.sessionState = {
                    weight_value: '',
                    tag_value: '',
                    box_label_value: '',
                    captured_image: null
                };
                
                ui.updateCycleCount();
                ui.updateStepDisplay('tag');
                ui.updateVerificationPanel();
                ui.updateSummary();
                ui.showNotification('✅ Cycle complete! Starting new cycle...', 'success');
                
                // Sync with backend in background
                api.nextStep().catch(() => {});
            }
        },

        async captureAndProcess(scanType) {
    const panel = document.getElementById('verification-panel');
    if (panel) {
                panel.innerHTML = '<div style="text-align: center; padding: 2rem;"><div class="spinner"></div><p>Processing...</p></div>';
    }
    
            try {
                const data = await api.capture(scanType, state.cameraRotation);

                if (!data.success) {
                    ui.showNotification(data.error || 'Capture failed', 'error');
                    ui.updateVerificationPanel();
                    return;
                }

                const value = data.extracted_value || '';
            
            if (scanType === 'tag') {
                    state.sessionState.tag_value = value;
            } else if (scanType === 'weight') {
                    state.sessionState.weight_value = value;
            } else if (scanType === 'box_label') {
                    state.sessionState.box_label_value = value;
            }
            
            if (value) {
                    ui.showNotification(`✅ Success: ${value}`, 'success');
            } else {
                    ui.showNotification('❌ No value extracted. Please rescan.', 'error');
            }
            
            if (data.frame) {
                const img = document.getElementById('camera-frame');
                if (img) img.src = data.frame;
            }
            
                ui.updateStepDisplay(state.currentStep);
                ui.updateVerificationPanel();
                ui.updateSummary();

            } catch (error) {
        console.error('Capture error:', error);
                ui.showNotification('Error capturing image', 'error');
                ui.updateVerificationPanel();
            }
        },

        async verifyStep() {
            try {
                const valueKey = state.currentStep === 'tag' ? 'tag_value' : 
                                state.currentStep === 'weight' ? 'weight_value' : 'box_label_value';
                const value = state.sessionState[valueKey];

                const data = await api.verify(value);

        if (data.success) {
                    ui.showNotification('Step verified successfully!', 'success');
        } else {
                    ui.showNotification(data.error || 'Verification failed', 'error');
        }
            } catch (error) {
        console.error('Verification error:', error);
                ui.showNotification('Error during verification', 'error');
            }
        },

        async confirmAndNext() {
            // Verify step first (non-blocking), then move to next immediately
            const valueKey = state.currentStep === 'tag' ? 'tag_value' : 
                            state.currentStep === 'weight' ? 'weight_value' : 'box_label_value';
            const value = state.sessionState[valueKey];

            // Verify with backend in background (non-blocking)
            api.verify(value).catch(err => {
                console.error('Verification error:', err);
                // Continue anyway - UI already updated
            });

            // Move to next step immediately (user doesn't wait)
            actions.nextStep();
        },

        rescanStep(step) {
            // Clear local state immediately (instant UI update)
            if (step === 'tag') {
                state.sessionState.tag_value = '';
            } else if (step === 'weight') {
                state.sessionState.weight_value = '';
            } else if (step === 'box_label') {
                state.sessionState.box_label_value = '';
            }
            state.sessionState.captured_image = null;
            
            // Update UI immediately (no waiting)
            ui.updateStepDisplay(state.currentStep);
            ui.updateVerificationPanel();
            ui.updateSummary();
            
            // Sync with backend in background (non-blocking)
            api.rescan().catch(err => {
                console.error('Rescan backend sync error:', err);
                // Silent failure - UI already updated
            });
        },

        completeCycle() {
            actions.nextStep();
        }
    };

    // ============================================================================
    // EVENT HANDLERS
    // ============================================================================

    const events = {
        attachButtonListeners() {
            const panel = document.getElementById('verification-panel');
            if (!panel) return;

            panel.addEventListener('click', (e) => {
                const button = e.target.closest('button');
                if (!button) return;

                e.preventDefault();
                e.stopPropagation();

                const action = button.getAttribute('data-action');
                const step = button.getAttribute('data-step') || state.currentStep;

                switch (action) {
                    case 'next':
                        actions.nextStep();
                        break;
                    case 'verify':
                        actions.verifyStep();
                        break;
                    case 'confirm-and-next':
                        actions.confirmAndNext();
                        break;
                    case 'rescan':
                        actions.rescanStep(step);
                        break;
                    case 'complete':
                        actions.completeCycle();
                        break;
                    case 'capture-tag':
                        actions.captureAndProcess('tag');
                        break;
                    case 'capture-weight':
                        actions.captureAndProcess('weight');
                        break;
                    case 'capture-box':
                        actions.captureAndProcess('box_label');
                        break;
                }
            });
        },

        rotateCamera(angle) {
            state.cameraRotation = angle;
            ui.applyRotation();
            ui.updateRotationButtons();
            localStorage.setItem('cameraRotation', angle.toString());
            api.setRotation(angle).catch(err => console.error('Rotation error:', err));
        }
    };

    // ============================================================================
    // CAMERA
    // ============================================================================

    const camera = {
        startFeed() {
            if (state.cameraFeedInterval) {
                clearInterval(state.cameraFeedInterval);
            }

            state.cameraFeedInterval = setInterval(async () => {
                const now = Date.now();
                if (now - state.lastFrameTime < config.FRAME_INTERVAL) {
                    return;
    }

                try {
                    const data = await api.getFrame();
                    if (data && data.frame) {
                        const img = document.getElementById('camera-frame');
                        const loading = document.getElementById('camera-loading');

                        if (img) {
                            img.src = data.frame;
                            img.style.display = 'block';
                            state.lastFrameTime = now;
                            ui.applyRotation();
                        }
                        if (loading) {
                            loading.style.display = 'none';
                        }
                    }
                } catch (error) {
                    // Silent fail for camera feed
                }
            }, config.FRAME_INTERVAL);
        }
    };

    // ============================================================================
    // INIT
    // ============================================================================

    const init = {
        async initializeApp() {
            try {
                // Set timeout to prevent hanging
                const timeoutPromise = new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Session request timeout')), 3000)
                );

                const data = await Promise.race([
                    api.getSession(),
                    timeoutPromise
                ]);
                
                if (data.success && data.session_data) {
                    state.sessionState = {
                        weight_value: data.session_data.weight_value || '',
                        tag_value: data.session_data.tag_value || '',
                        box_label_value: data.session_data.box_label_value || '',
                        captured_image: null
                    };
                    state.currentStep = data.session_data.current_step || 'tag';
                    state.cycleCount = data.session_data.cycle_count || 0;

                    ui.updateCycleCount();
                    ui.updateStepDisplay(state.currentStep);
                    ui.updateVerificationPanel();
                    ui.updateSummary();
                } else {
                    state.currentStep = 'tag';
                    ui.updateStepDisplay(state.currentStep);
                    ui.updateVerificationPanel();
                }
            } catch (error) {
                console.error('Init error:', error);
                // Don't block - use defaults
                state.currentStep = 'tag';
                ui.updateStepDisplay(state.currentStep);
                ui.updateVerificationPanel();
            }

            // Non-blocking status check
            api.getStatus().catch(() => {});
        },

        loadSavedRotation() {
            const saved = localStorage.getItem('cameraRotation');
            if (saved) {
                state.cameraRotation = parseInt(saved, 10);
                ui.applyRotation();
                ui.updateRotationButtons();
            }
        }
    };

    // ============================================================================
    // EXPOSE
    // ============================================================================

    window.rotateCamera = events.rotateCamera;

    // ============================================================================
    // DOM READY
    // ============================================================================

    document.addEventListener('DOMContentLoaded', () => {
        init.loadSavedRotation();
        events.attachButtonListeners();
        init.initializeApp();
        camera.startFeed();
        ui.updateVerificationPanel();
    });

})();
