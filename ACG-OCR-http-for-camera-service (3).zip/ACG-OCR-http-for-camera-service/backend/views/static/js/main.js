// Main JavaScript utilities

// Utility functions
function formatDate(date) {
    return new Date(date).toLocaleString();
}

function showLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div class="spinner"></div>';
    }
}

function hideLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '';
    }
}

// Export for use in other scripts
window.ACGUtils = {
    formatDate,
    showLoading,
    hideLoading
};

