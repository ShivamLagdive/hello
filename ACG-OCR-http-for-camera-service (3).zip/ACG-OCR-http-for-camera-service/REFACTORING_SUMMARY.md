# Refactoring Summary: Dual-Service Architecture

## Overview

The application has been refactored from a single Flask app with direct camera access into **two separate services** that communicate via HTTP:

1. **Camera Service** (Python 3.13 + Picamera2) - Handles CSI camera operations
2. **Flask OCR App** (Python 3.10 + PaddleOCR) - Handles OCR processing and web UI

## Changes Made

### New Files Created

1. **`camera_service.py`** (Root directory)
   - Standalone Flask service running on Python 3.13
   - Uses Picamera2 for CSI camera access
   - Provides endpoints:
     - `GET /stream.mjpg` - MJPEG live stream
     - `POST /capture` - Capture still image, returns JSON with path
     - `GET /health` - Health check endpoint
   - Runs on `http://127.0.0.1:8000`

2. **`backend/services/camera_client.py`**
   - HTTP client singleton for communicating with camera service
   - Provides methods:
     - `capture_image()` - Capture image and return path
     - `capture_frame()` - Capture image and return as numpy array
     - `get_stream_url()` - Get MJPEG stream URL
     - `is_available()` - Check if camera service is running

3. **`systemd/camera-service.service`**
   - Systemd service file for camera service (auto-start on boot)

4. **`systemd/flask-ocr-app.service`**
   - Systemd service file for Flask OCR app (auto-start on boot)

### Modified Files

1. **`backend/models/camera_model.py`**
   - **Before:** Direct camera access via `WebcamCapture` class
   - **After:** Uses `CameraClient` singleton to communicate with camera service via HTTP
   - Removed direct camera initialization code
   - Added `get_stream_url()` method

2. **`backend/app.py`**
   - Added `/video_feed` route to proxy MJPEG stream from camera service
   - Made `camera_config` parameter optional (kept for compatibility)
   - Added `requests` import for video feed proxying

3. **`backend/main.py`**
   - Updated camera initialization messages to reflect camera service architecture
   - Updated status messages

4. **`backend/services/video_stream_service.py`**
   - Updated comments to reflect camera service usage
   - No functional changes (still uses CameraModel, which now uses CameraClient)

5. **`Readme.md`**
   - Updated architecture diagram to show dual-service architecture
   - Updated Quick Start section with instructions for running both services
   - Added systemd setup instructions
   - Updated prerequisites section

## Architecture Flow

### Before (Single Service)
```
Browser → Flask App → CameraModel → WebcamCapture → Camera Hardware
```

### After (Dual Service)
```
Browser → Flask OCR App → CameraModel → CameraClient → HTTP → Camera Service → Picamera2 → Camera Hardware
```

## Running the Application

### Manual Start

**Terminal 1 - Camera Service:**
```bash
python3 camera_service.py
```

**Terminal 2 - Flask OCR App:**
```bash
source venv/bin/activate
python -m backend.main
```

### Using systemd (Auto-start on boot)

```bash
# Copy service files
sudo cp systemd/camera-service.service /etc/systemd/system/
sudo cp systemd/flask-ocr-app.service /etc/systemd/system/

# Edit paths in service files to match your installation
sudo nano /etc/systemd/system/camera-service.service
sudo nano /etc/systemd/system/flask-ocr-app.service

# Enable and start
sudo systemctl daemon-reload
sudo systemctl enable camera-service.service
sudo systemctl enable flask-ocr-app.service
sudo systemctl start camera-service.service
sudo systemctl start flask-ocr-app.service
```

## Dependencies

### Camera Service (Python 3.13)
- Flask (install via: `pip3 install flask`)
- Picamera2 (install via: `sudo apt-get install python3-picamera2`)
- OpenCV (install via: `sudo apt-get install python3-opencv`)

### Flask OCR App (Python 3.10)
- All dependencies in `requirements.txt` (unchanged)
- `requests` library (already in requirements.txt)

## API Endpoints

### Camera Service (`http://127.0.0.1:8000`)

- `GET /stream.mjpg` - MJPEG live stream
- `POST /capture` - Capture image, returns `{"success": true, "path": "/tmp/capture.jpg"}`
- `GET /health` - Health check, returns `{"status": "ok", "camera_initialized": true}`

### Flask OCR App (`http://localhost:5000`)

All existing endpoints remain unchanged:
- `GET /video_feed` - **NEW:** Proxies MJPEG stream from camera service
- All other routes remain the same

## Benefits

1. **Python Version Separation**: Camera service runs on Python 3.13 (required for Picamera2), OCR app runs on Python 3.10 (required for PaddlePaddle)
2. **Service Isolation**: Camera failures don't crash OCR app and vice versa
3. **Easy Deployment**: Each service can be managed independently
4. **Scalability**: Camera service could be moved to a separate device if needed
5. **Maintainability**: Clear separation of concerns

## Testing

1. Start camera service: `python3 camera_service.py`
2. Verify camera service: `curl http://127.0.0.1:8000/health`
3. Start Flask app: `source venv/bin/activate && python -m backend.main`
4. Access UI: `http://localhost:5000/pharma`
5. Verify live feed works
6. Test capture button - should trigger OCR processing

## Troubleshooting

### Camera Service Not Starting
- Check Python version: `python3 --version` (should be 3.13)
- Check Picamera2 installation: `python3 -c "from picamera2 import Picamera2"`
- Check camera hardware: `libcamera-hello --list-cameras`

### Flask App Can't Connect to Camera Service
- Verify camera service is running: `curl http://127.0.0.1:8000/health`
- Check firewall settings
- Verify camera service URL in `CameraClient` initialization

### Video Feed Not Working
- Check `/video_feed` route is proxying correctly
- Verify camera service `/stream.mjpg` endpoint works directly
- Check browser console for errors

## Migration Notes

- **No frontend changes required** - UI remains unchanged
- **API compatibility maintained** - All existing endpoints work the same
- **Backward compatible** - Old code paths still work (CameraModel interface unchanged)
