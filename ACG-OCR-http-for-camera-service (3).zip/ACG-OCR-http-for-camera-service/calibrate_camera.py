"""
Camera Calibration Tool for Raspberry Pi OCR System
Helps you find the perfect settings for your setup
"""

import sys
from pathlib import Path
import time
import cv2
import numpy as np

# Add scripts to path
script_dir = Path(__file__).parent
if (script_dir / "scripts").exists():
    sys.path.insert(0, str(script_dir / "scripts"))
else:
    sys.path.insert(0, str(script_dir))

try:
    from camera_capture import PiCameraCapture, MotionDetector
except ImportError as e:
    print(f"❌ Error: {e}")
    print("Make sure camera_capture.py is in the scripts/ folder")
    sys.exit(1)


class CameraCalibrator:
    """Interactive camera calibration tool"""
    
    def __init__(self):
        self.camera = None
        self.config = {
            'resolution': (1280, 720),
            'framerate': 10,
            'rotation': 0,
            'capture_dir': 'calibration_test',
            'motion_detection': {
                'min_detection_area': 5000,
                'motion_threshold': 25,
                'stable_frames': 3,
                'capture_cooldown': 2
            }
        }
    
    def print_header(self, text):
        """Print formatted header"""
        print("\n" + "="*70)
        print(text.center(70))
        print("="*70 + "\n")
    
    def test_camera_connection(self):
        """Test if camera is accessible"""
        self.print_header("📷 STEP 1: Camera Connection Test")
        
        try:
            print("Initializing camera...")
            self.camera = PiCameraCapture(config=self.config, ocr_system=None)
            print("✅ Camera initialized successfully!\n")
            
            # Capture test frame
            print("Capturing test frame...")
            frame = self.camera.capture_frame()
            
            if frame is not None:
                h, w = frame.shape[:2]
                print(f"✅ Test capture successful!")
                print(f"   Resolution: {w}x{h}")
                print(f"   Shape: {frame.shape}")
                return True
            else:
                print("❌ Test capture failed - frame is None")
                return False
                
        except Exception as e:
            print(f"❌ Camera initialization failed: {e}")
            print("\nTroubleshooting:")
            print("1. Check camera cable connection")
            print("2. Run: sudo raspi-config → Interface → Camera → Enable")
            print("3. Run: vcgencmd get_camera")
            print("4. Reboot if needed")
            return False
    
    def test_image_quality(self):
        """Visual image quality test"""
        self.print_header("🎨 STEP 2: Image Quality Test")
        
        print("Capturing image for quality check...")
        frame = self.camera.capture_frame()
        
        # Save for inspection
        test_path = Path('calibration_test') / 'quality_test.jpg'
        test_path.parent.mkdir(exist_ok=True)
        cv2.imwrite(str(test_path), frame)
        
        print(f"✅ Image saved: {test_path}")
        print(f"\nImage statistics:")
        
        # Calculate quality metrics
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        brightness = np.mean(gray)
        contrast = np.std(gray)
        
        # Blur detection (Laplacian variance)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        print(f"   Brightness: {brightness:.1f} (ideal: 100-160)")
        print(f"   Contrast: {contrast:.1f} (ideal: 40-80)")
        print(f"   Sharpness: {laplacian_var:.1f} (higher = sharper, ideal: >100)")
        
        # Recommendations
        print("\n💡 Recommendations:")
        if brightness < 80:
            print("   ⚠️  Too dark - add more lighting")
        elif brightness > 180:
            print("   ⚠️  Too bright - reduce lighting or adjust exposure")
        else:
            print("   ✅ Brightness is good")
        
        if contrast < 30:
            print("   ⚠️  Low contrast - improve lighting or background")
        else:
            print("   ✅ Contrast is good")
        
        if laplacian_var < 50:
            print("   ⚠️  Image is blurry - check focus or reduce camera shake")
        else:
            print("   ✅ Image is sharp")
    
    def calibrate_motion_detection(self):
        """Interactive motion detection calibration"""
        self.print_header("🎯 STEP 3: Motion Detection Calibration")
        
        print("This will help you find the perfect sensitivity settings.\n")
        print("Instructions:")
        print("1. Keep camera still and area clear")
        print("2. Press ENTER to start baseline")
        print("3. Move object in/out of view")
        print("4. Watch for detection triggers")
        print("\nPress ENTER to start...")
        input()
        
        # Baseline phase
        print("\n📊 Phase 1: Baseline (5 seconds - keep area clear)")
        baseline_areas = []
        
        for i in range(50):  # 5 seconds at 10 FPS
            frame = self.camera.capture_frame()
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (21, 21), 0)
            
            if i == 0:
                self.camera.motion_detector.background = gray
            
            has_motion, thresh, contours = self.camera.motion_detector.detect_motion(frame)
            
            # Track background noise
            if contours:
                max_area = max([cv2.contourArea(c) for c in contours])
                baseline_areas.append(max_area)
            
            time.sleep(0.1)
        
        # Calculate baseline noise
        if baseline_areas:
            noise_level = np.percentile(baseline_areas, 95)
            print(f"✅ Baseline noise: {noise_level:.0f} pixels")
        else:
            noise_level = 0
            print("✅ No baseline noise detected (perfect!)")
        
        # Recommend min_detection_area
        recommended_min_area = max(noise_level * 2, 3000)
        print(f"\n💡 Recommended min_detection_area: {recommended_min_area:.0f}")
        
        # Detection phase
        print("\n📊 Phase 2: Detection Test (30 seconds)")
        print("Now move your object in and out of view...\n")
        
        detections = []
        start_time = time.time()
        
        try:
            while time.time() - start_time < 30:
                frame = self.camera.capture_frame()
                has_motion, thresh, contours = self.camera.motion_detector.detect_motion(frame)
                
                if has_motion and contours:
                    max_area = max([cv2.contourArea(c) for c in contours])
                    detections.append(max_area)
                    print(f"🔥 Motion detected! Area: {max_area:.0f} pixels")
                
                time.sleep(0.1)
        
        except KeyboardInterrupt:
            print("\n⚠️  Test stopped early")
        
        # Analysis
        print("\n" + "="*70)
        print("CALIBRATION RESULTS")
        print("="*70)
        
        if detections:
            min_det = min(detections)
            max_det = max(detections)
            avg_det = np.mean(detections)
            
            print(f"\nDetection Statistics:")
            print(f"   Smallest detection: {min_det:.0f} pixels")
            print(f"   Largest detection: {max_det:.0f} pixels")
            print(f"   Average detection: {avg_det:.0f} pixels")
            print(f"   Total triggers: {len(detections)}")
            
            # Recommendations
            print("\n💡 RECOMMENDED SETTINGS:")
            print("-"*70)
            
            # min_detection_area: Set to filter out noise but catch real objects
            if min_det < noise_level * 2:
                rec_min_area = noise_level * 2.5
            else:
                rec_min_area = min_det * 0.8
            
            print(f"min_detection_area: {rec_min_area:.0f}")
            print(f"   (Will detect objects similar to what you just tested)")
            
            # motion_threshold
            print(f"\nmotion_threshold: 25")
            print(f"   (Good default, adjust if too sensitive)")
            
            # stable_frames
            if len(detections) > 30:
                rec_stable = 5
                print(f"\nstable_frames: {rec_stable}")
                print(f"   (Many detections - need stability to avoid duplicates)")
            else:
                rec_stable = 3
                print(f"\nstable_frames: {rec_stable}")
                print(f"   (Few detections - can be more responsive)")
            
            # cooldown
            print(f"\ncapture_cooldown: 2")
            print(f"   (2 seconds between captures - adjust for workflow)")
            
        else:
            print("\n⚠️  No motion detected during test!")
            print("Possible issues:")
            print("   - Motion too small (increase object size)")
            print("   - Detection area too large (lower min_detection_area)")
            print("   - Insufficient motion (move object more)")
    
    def generate_config(self):
        """Generate optimized config file"""
        self.print_header("📝 STEP 4: Generate Config")
        
        print("Based on calibration, here's your optimized config:\n")
        
        config_code = """
camera_config = {
    'resolution': (1280, 720),
    'framerate': 10,
    'rotation': 0,
    'capture_dir': 'camera_captures',
    'max_capture_size': 960,
    
    'motion_detection': {
        # Calibrated settings:
        'min_detection_area': 5000,      # Adjust based on test results
        'motion_threshold': 25,           # Good default
        'stable_frames': 3,               # Increase if many false triggers
        'capture_cooldown': 2             # Seconds between captures
    }
}
"""
        
        print(config_code)
        
        # Save to file
        config_path = Path('camera_config_calibrated.txt')
        with open(config_path, 'w') as f:
            f.write(config_code)
        
        print(f"\n💾 Saved to: {config_path}")
        print("\n✅ Copy this config into your camera_app.py or app.py!")
    
    def run_full_calibration(self):
        """Run complete calibration workflow"""
        print("\n" + "="*70)
        print("🎯 RASPBERRY PI CAMERA CALIBRATION WIZARD")
        print("="*70)
        print("\nThis will help you configure your camera for optimal performance.")
        print("Make sure your camera is mounted and your workspace is set up.")
        print("\nPress ENTER to begin...")
        input()
        
        # Step 1: Connection test
        if not self.test_camera_connection():
            print("\n❌ Cannot proceed without working camera")
            return
        
        input("\nPress ENTER for next step...")
        
        # Step 2: Image quality
        self.test_image_quality()
        
        input("\nPress ENTER for next step...")
        
        # Step 3: Motion detection
        self.calibrate_motion_detection()
        
        input("\nPress ENTER for final step...")
        
        # Step 4: Generate config
        self.generate_config()
        
        print("\n" + "="*70)
        print("✅ CALIBRATION COMPLETE!")
        print("="*70)
        print("\nNext steps:")
        print("1. Copy the generated config to your script")
        print("2. Test with: python3 camera_app.py")
        print("3. Fine-tune settings based on real usage")
        print("\n")
    
    def cleanup(self):
        """Clean up resources"""
        if self.camera:
            self.camera.cleanup()


def main():
    calibrator = CameraCalibrator()
    
    try:
        calibrator.run_full_calibration()
    except KeyboardInterrupt:
        print("\n\n⚠️  Calibration interrupted")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        calibrator.cleanup()


if __name__ == "__main__":
    main()