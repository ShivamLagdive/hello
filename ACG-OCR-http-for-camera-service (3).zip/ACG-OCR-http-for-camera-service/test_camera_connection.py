#!/usr/bin/env python3
"""
Camera Connection Test Script
Tests camera connection with detailed diagnostics
"""
import sys
from pathlib import Path
import cv2
import requests
import time

def test_network_camera(url: str):
    """Test network camera connection"""
    print(f"\n{'='*70}")
    print(f"Testing Network Camera: {url}")
    print(f"{'='*70}\n")
    
    # Test 1: Check if URL is accessible via HTTP
    print("1️⃣ Testing HTTP connection...")
    try:
        # Try to get a single frame (shot.jpg works better for testing)
        test_url = url.replace('/video', '/shot.jpg') if '/video' in url else url
        if '/shot.jpg' not in test_url and '/video' not in test_url:
            test_url = url + '/shot.jpg'
        
        print(f"   Trying: {test_url}")
        response = requests.get(test_url, timeout=5)
        if response.status_code == 200:
            print(f"   ✅ HTTP connection successful! (Status: {response.status_code})")
            print(f"   📊 Response size: {len(response.content)} bytes")
        else:
            print(f"   ❌ HTTP connection failed (Status: {response.status_code})")
    except requests.exceptions.Timeout:
        print(f"   ❌ Connection timeout - camera may be unreachable")
    except requests.exceptions.ConnectionError:
        print(f"   ❌ Connection error - check IP address and network")
    except Exception as e:
        print(f"   ⚠️ HTTP test error: {e}")
    
    # Test 2: Try OpenCV with different backends
    print("\n2️⃣ Testing OpenCV backends...")
    backends = [
        (cv2.CAP_FFMPEG, "FFMPEG"),
        (cv2.CAP_GSTREAMER, "GStreamer"),
        (cv2.CAP_ANY, "Any/Default"),
    ]
    
    working_backend = None
    for backend_id, backend_name in backends:
        print(f"   Trying {backend_name} backend...")
        try:
            cap = cv2.VideoCapture(url, backend_id)
            cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000)
            cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
            
            if cap.isOpened():
                print(f"      ✅ Opened successfully")
                ret, frame = cap.read()
                if ret and frame is not None:
                    print(f"      ✅ Frame captured! Size: {frame.shape[1]}x{frame.shape[0]}")
                    working_backend = (backend_id, backend_name)
                    cap.release()
                    break
                else:
                    print(f"      ⚠️ Opened but couldn't read frame")
            else:
                print(f"      ❌ Failed to open")
            cap.release()
        except Exception as e:
            print(f"      ❌ Error: {e}")
    
    # Test 3: Try alternative URL formats
    print("\n3️⃣ Testing alternative URL formats...")
    url_variants = []
    if '/video' in url:
        url_variants.append(url.replace('/video', '/shot.jpg'))
        url_variants.append(url.replace('/video', '/videofeed'))
    elif '/shot.jpg' in url:
        url_variants.append(url.replace('/shot.jpg', '/video'))
        url_variants.append(url.replace('/shot.jpg', '/videofeed'))
    else:
        url_variants.append(url + '/video')
        url_variants.append(url + '/shot.jpg')
        url_variants.append(url + '/videofeed')
    
    for variant in url_variants:
        if variant == url:
            continue
        print(f"   Trying: {variant}")
        try:
            cap = cv2.VideoCapture(variant, cv2.CAP_FFMPEG)
            cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    print(f"      ✅ Works! Use this URL: {variant}")
                    cap.release()
                    return variant
            cap.release()
        except:
            pass
    
    # Summary
    print(f"\n{'='*70}")
    if working_backend:
        print(f"✅ Camera connection successful!")
        print(f"   Working backend: {working_backend[1]}")
        print(f"   Use this URL in config.py: {url}")
    else:
        print(f"❌ Camera connection failed")
        print(f"\n💡 Troubleshooting tips:")
        print(f"   1. Verify IP address: {url.split('://')[1].split(':')[0] if '://' in url else 'N/A'}")
        print(f"   2. Check if camera is on the same network")
        print(f"   3. Try accessing in browser: {url.replace('/video', '/shot.jpg')}")
        print(f"   4. Check firewall settings")
        print(f"   5. For IP Webcam app, ensure server is running")
    print(f"{'='*70}\n")
    
    return working_backend is not None


def test_usb_camera(camera_id: int):
    """Test USB camera connection"""
    print(f"\n{'='*70}")
    print(f"Testing USB Camera: {camera_id}")
    print(f"{'='*70}\n")
    
    cap = cv2.VideoCapture(camera_id)
    if cap.isOpened():
        ret, frame = cap.read()
        if ret and frame is not None:
            print(f"✅ Camera {camera_id} working!")
            print(f"   Frame size: {frame.shape[1]}x{frame.shape[0]}")
            cap.release()
            return True
        else:
            print(f"⚠️ Camera opened but couldn't read frame")
    else:
        print(f"❌ Could not open camera {camera_id}")
    
    cap.release()
    return False


if __name__ == "__main__":
    print("\n" + "="*70)
    print("📷 CAMERA CONNECTION TESTER")
    print("="*70)
    
    if len(sys.argv) < 2:
        print("\nUsage:")
        print("  python test_camera_connection.py <camera_id_or_url>")
        print("\nExamples:")
        print("  python test_camera_connection.py 0                    # USB camera 0")
        print("  python test_camera_connection.py http://192.168.1.100:8080/video")
        print("  python test_camera_connection.py http://192.168.1.100:8080/shot.jpg")
        sys.exit(1)
    
    camera_input = sys.argv[1]
    
    # Check if it's a URL or integer
    if camera_input.startswith('http'):
        success = test_network_camera(camera_input)
    else:
        try:
            camera_id = int(camera_input)
            success = test_usb_camera(camera_id)
        except ValueError:
            print(f"❌ Invalid camera ID: {camera_input}")
            print("   Use an integer (0, 1, 2...) for USB cameras")
            print("   Use a URL (http://...) for network cameras")
            sys.exit(1)
    
    sys.exit(0 if success else 1)

