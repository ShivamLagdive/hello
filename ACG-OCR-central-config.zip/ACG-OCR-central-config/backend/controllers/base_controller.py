"""
Base Controller - Common functionality for all controllers
"""
from flask import Blueprint, session
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class BaseController:
    """Base controller with common functionality"""
    
    def __init__(self, project_root: Path, blueprint_name: str, url_prefix: str):
        """
        Initialize base controller
        
        Args:
            project_root: Project root directory
            blueprint_name: Name for the blueprint
            url_prefix: URL prefix for routes
        """
        self.project_root = project_root
        self.blueprint = Blueprint(blueprint_name, __name__, url_prefix=url_prefix)
    
    def get_session_id(self) -> str:
        """
        Get current session ID
        
        Returns:
            Session ID string
        """
        return session.get('session_id', 'default')
    
    def _register_routes(self):
        """Register routes - to be implemented by subclasses"""
        raise NotImplementedError("Subclasses must implement _register_routes")

