"""
Session Model - Manages application state
Refactored with singleton pattern, dataclass and proper type hints
"""
from typing import Dict, Optional
from datetime import datetime
from dataclasses import dataclass, field, asdict

from backend.core.singleton import SingletonMeta
from backend.config import DEFAULT_SESSION_STATE


@dataclass
class SessionState:
    """Session state data class"""
    current_step: str = 'tag'
    cycle_count: int = 0
    weight_value: str = ''
    tag_value: str = ''
    box_label_value: str = ''
    notification: Optional[Dict] = None
    captured_image: Optional[str] = None
    camera_rotation: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return asdict(self)
    
    def reset(self, preserve_cycle: bool = True) -> None:
        """Reset session state"""
        if preserve_cycle:
            cycle_count = self.cycle_count
        else:
            cycle_count = 0
        
        self.current_step = 'tag'
        self.cycle_count = cycle_count
        self.weight_value = ''
        self.tag_value = ''
        self.box_label_value = ''
        self.notification = None
        self.captured_image = None
        self.updated_at = datetime.now().isoformat()


class SessionModel(metaclass=SingletonMeta):
    """Model for managing session state - Singleton (no locks needed for single-user Pi)"""
    
    def __init__(self):
        """Initialize session model (singleton - only initialized once)"""
        if hasattr(self, '_sessions'):
            return  # Already initialized
        
        self._sessions: Dict[str, SessionState] = {}
    
    def get_session(self, session_id: str) -> SessionState:
        """
        Get or create session
        
        Args:
            session_id: Session identifier
        
        Returns:
            SessionState instance
        """
        if session_id not in self._sessions:
            self._sessions[session_id] = SessionState()
        return self._sessions[session_id]
    
    def update_session(self, session_id: str, updates: Dict) -> None:
        """
        Update session data
        
        Args:
            session_id: Session identifier
            updates: Dictionary of updates to apply
        """
        session = self.get_session(session_id)
        for key, value in updates.items():
            if hasattr(session, key):
                setattr(session, key, value)
        session.updated_at = datetime.now().isoformat()
    
    def reset_session(self, session_id: str, preserve_cycle: bool = True) -> None:
        """
        Reset session to initial state
        
        Args:
            session_id: Session identifier
            preserve_cycle: Whether to preserve cycle count
        """
        if session_id in self._sessions:
            self._sessions[session_id].reset(preserve_cycle=preserve_cycle)
    
    def increment_cycle(self, session_id: str) -> int:
        """
        Increment cycle count
        
        Args:
            session_id: Session identifier
        
        Returns:
            New cycle count
        """
        session = self.get_session(session_id)
        session.cycle_count += 1
        session.updated_at = datetime.now().isoformat()
        return session.cycle_count
    
    def get_session_dict(self, session_id: str) -> Dict:
        """
        Get session as dictionary
        
        Args:
            session_id: Session identifier
        
        Returns:
            Session data as dictionary
        """
        return self.get_session(session_id).to_dict()
