"""
Camera Model - Handles camera operations via Camera Service
Refactored to use CameraClient (HTTP client) instead of direct camera access

IMPORTANT: This module has NO heavy imports (no cv2, no numpy).
All initialization is NON-BLOCKING - no network requests in __init__.
"""
from pathlib import Path
from typing import Optional, Dict
import logging

from backend.core.singleton import SingletonMeta

logger = logging.getLogger(__name__)


class CameraModel(metaclass=SingletonMeta):
    """Model for camera operations via Camera Service - Singleton"""
    
    _initialized = False
    
    def __init__(self, project_root: Path = None, camera_config: Dict = None):
        """
        Initialize Camera Model (singleton - only initialized once)
        
        NON-BLOCKING: This method does NOT make any network requests.
        Camera service availability is checked on-demand when methods are called.
        
        Args:
            project_root: Project root directory (optional, kept for compatibility)
            camera_config: Camera configuration dictionary (optional, kept for compatibility)
        """
        if self._initialized:
            return
        
        # Import CameraClient here to avoid import-time blocking
        # This is a lazy import to ensure no blocking during module import
        from backend.services.camera_client import CameraClient
        
        # Initialize camera client (singleton) - NON-BLOCKING, no network requests
        # Camera service URL can be configured via environment variable if needed
        camera_service_url = camera_config.get('camera_service_url', 'http://127.0.0.1:8000') if camera_config else 'http://127.0.0.1:8000'
        
        self.camera_client = CameraClient(base_url=camera_service_url)
        
        # Don't block initialization - check availability asynchronously
        # The app should start even if camera service isn't ready yet
        # Camera availability will be checked on-demand when needed
        self._initialized = True
        logger.info("📷 CameraModel initialized (service availability will be checked on-demand)")
    
    def capture_frame(self) -> Optional[str]:
        """
        Capture a frame from camera service
        
        Returns:
            Path to captured image file (string) or None on error.
            The caller should read the image using cv2.imread() or PIL.Image.open()
        """
        if not self._initialized:
            logger.warning("Camera service not available, cannot capture frame")
            return None
        
        try:
            image_path = self.camera_client.capture_frame()
            if image_path:
                logger.debug(f"Frame captured successfully: {image_path}")
            return image_path
        except Exception as e:
            logger.error(f"Error capturing frame: {e}")
            return None
    
    def is_initialized(self) -> bool:
        """
        Check if camera service is available (non-blocking)
        
        This makes a network request to check service health, so it may take up to 0.5s.
        Use sparingly - prefer checking availability only when needed.
        
        Returns:
            True if camera service is available, False otherwise
        """
        if not self._initialized:
            return False
        # This makes a network request, but with a short timeout (0.5s)
        return self.camera_client.is_available()
    
    def get_camera(self):
        """Get camera client instance (for compatibility)"""
        return self.camera_client
    
    def get_stream_url(self) -> str:
        """Get MJPEG stream URL"""
        return self.camera_client.get_stream_url()
    
    def get_frame_bytes(self) -> Optional[bytes]:
        """
        Get frame as JPEG bytes directly (no file I/O).
        
        OPTIMIZED: Returns JPEG bytes directly from camera service.
        Much faster than capture_frame() for high-frequency requests (streaming).
        
        Returns:
            JPEG bytes or None on error
        """
        if not self._initialized:
            return None
        
        try:
            return self.camera_client.get_frame_bytes()
        except Exception as e:
            logger.debug(f"Error getting frame bytes: {e}")
            return None
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup"""
        self.cleanup()
        return False
    
    def cleanup(self):
        """Cleanup camera resources (no-op for HTTP client)"""
        # No cleanup needed for HTTP client
        pass
