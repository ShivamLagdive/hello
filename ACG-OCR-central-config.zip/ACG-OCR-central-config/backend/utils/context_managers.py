"""
Context Managers - For resource management
"""
import os
import sys
from pathlib import Path
from contextlib import contextmanager
from typing import Iterator
import logging

logger = logging.getLogger(__name__)


@contextmanager
def working_directory(path: Path) -> Iterator[Path]:
    """
    Context manager for temporarily changing working directory
    
    Args:
        path: Directory path to change to
    
    Yields:
        The path
    
    Example:
        with working_directory(Path('/tmp')):
            # Do work in /tmp
            pass
        # Back to original directory
    """
    original_dir = os.getcwd()
    try:
        os.chdir(str(path))
        yield path
    finally:
        os.chdir(original_dir)


@contextmanager
def add_to_path(path: Path) -> Iterator[None]:
    """
    Context manager for temporarily adding path to sys.path
    
    Args:
        path: Path to add to sys.path
    
    Yields:
        None
    """
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)
    try:
        yield
    finally:
        if path_str in sys.path:
            sys.path.remove(path_str)

