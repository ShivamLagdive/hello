"""
Image Utilities - Image processing helper functions
Refactored with proper imports
"""
import cv2
import base64
import numpy as np
from typing import Optional
import logging

logger = logging.getLogger(__name__)


def rotate_image(frame: np.ndarray, angle: int) -> np.ndarray:
    """
    Rotate image by specified angle
    
    Args:
        frame: Input image frame
        angle: Rotation angle in degrees (0, 90, 180, 270)
    
    Returns:
        Rotated image frame
    """
    if angle == 0:
        return frame
    elif angle == 90:
        return cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
    elif angle == 180:
        return cv2.rotate(frame, cv2.ROTATE_180)
    elif angle == 270:
        return cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
    else:
        logger.warning(f"Invalid rotation angle: {angle}, using 0")
        return frame


def resize_image(frame: np.ndarray, max_size: int = 1920) -> np.ndarray:
    """
    Resize image if it exceeds max_size
    
    Args:
        frame: Input image frame
        max_size: Maximum dimension size
    
    Returns:
        Resized image frame
    """
    if frame is None:
        return frame
    
    h, w = frame.shape[:2]
    if max(h, w) > max_size:
        scale = max_size / max(h, w)
        new_w = int(w * scale)
        new_h = int(h * scale)
        return cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)
    
    return frame


def encode_frame_to_base64(frame: np.ndarray, quality: int = 85) -> Optional[str]:
    """
    Encode frame to base64 JPEG string
    
    Args:
        frame: Input image frame
        quality: JPEG quality (1-100)
    
    Returns:
        Base64 encoded image string or None on error
    """
    try:
        encode_params = [
            cv2.IMWRITE_JPEG_QUALITY, quality,
            cv2.IMWRITE_JPEG_OPTIMIZE, 1
        ]
        
        success, buffer = cv2.imencode('.jpg', frame, encode_params)
        if not success:
            logger.error("Failed to encode frame")
            return None
        
        frame_base64 = base64.b64encode(buffer).decode('utf-8')
        return f'data:image/jpeg;base64,{frame_base64}'
    except Exception as e:
        logger.error(f"Frame encoding error: {e}")
        return None
