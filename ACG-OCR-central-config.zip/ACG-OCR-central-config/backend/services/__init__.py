"""
Services package
"""
from .video_stream_service import VideoStreamService

__all__ = ['VideoStreamService']

