# ACG-OCR Backend - MVC Architecture with Singleton Pattern

## Overview

This is a Flask-based MVC (Model-View-Controller) backend that serves HTML/CSS/JS frontend applications. The architecture uses **Singleton Pattern** for all MVC components to ensure single instances and better resource management.

## Architecture

### Singleton Pattern
All models and controllers are implemented as **thread-safe singletons**:
- **Single Instance**: Only one instance of each class exists throughout the application lifecycle
- **Thread-Safe**: Uses double-checked locking pattern for multi-threaded Flask environment
- **Resource Management**: Ensures proper initialization and cleanup
- **Easy Access**: Can be accessed from anywhere without passing instances around

### Models (`backend/models/`) - Singletons
- **OCRModel**: Handles OCR operations using AdvancedOCRSystem (singleton)
- **CameraModel**: Manages camera capture operations (singleton)
- **SessionModel**: Manages user session state (singleton)

### Controllers (`backend/controllers/`) - Singletons
- **PharmaController**: Handles pharmaceutical packaging verification routes (singleton)
- **OCRController**: Handles OCR dashboard routes (singleton)

### Services (`backend/services/`)
- **VideoStreamService**: Efficient video frame streaming with threading and buffering

### Utils (`backend/utils/`)
- **image_utils**: Image processing utilities (rotation, resizing, encoding)
- **validators**: Value extraction from OCR text
- **context_managers**: Resource management context managers
- **response_helpers**: Standardized API response formatting

### Core (`backend/core/`)
- **SingletonMeta**: Thread-safe singleton metaclass

### Views (`backend/views/`)
- **templates/**: Jinja2 HTML templates
- **static/**: CSS, JavaScript, and other static assets

## Singleton Pattern Benefits

1. **Single Instance**: Only one instance of each model/controller exists
2. **Resource Efficiency**: Camera, OCR system initialized once
3. **State Consistency**: Shared state across all requests
4. **Easy Access**: Get instances anywhere: `OCRModel()`, `CameraModel()`, etc.
5. **Thread-Safe**: Safe for Flask's multi-threaded environment
6. **Clean Architecture**: No need to pass instances through function parameters

## Usage Examples

### Accessing Singleton Models
```python
# First call initializes, subsequent calls return same instance
ocr_model = OCRModel(project_root)  # Initialize
ocr_model2 = OCRModel()  # Returns same instance

camera_model = CameraModel(project_root, config)  # Initialize
camera_model2 = CameraModel()  # Returns same instance

session_model = SessionModel()  # Initialize
session_model2 = SessionModel()  # Returns same instance
```

### Accessing Singleton Controllers
```python
# First call initializes, subsequent calls return same instance
pharma_controller = PharmaController(project_root)  # Initialize
pharma_controller2 = PharmaController()  # Returns same instance

ocr_controller = OCRController(project_root)  # Initialize
ocr_controller2 = OCRController()  # Returns same instance
```

## Running the Backend

```bash
# From project root
python -m backend.main

# Or use the run script
python run_backend.py
```

## API Endpoints

### Pharma HMI (`/pharma`)
- `GET /pharma/` - Main HMI page
- `GET /pharma/api/status` - System status
- `GET /pharma/api/frame` - Get current camera frame
- `GET /pharma/api/stats` - Video stream statistics
- `GET /pharma/api/session` - Get session data
- `POST /pharma/api/capture` - Capture and process image
- `POST /pharma/api/verify` - Verify current step
- `POST /pharma/api/rescan` - Rescan current step
- `POST /pharma/api/next` - Move to next step
- `POST /pharma/api/reset` - Reset cycle
- `POST /pharma/api/set_rotation` - Set camera rotation angle

### OCR Dashboard (`/ocr`)
- `GET /ocr/` - Main dashboard page
- `GET /ocr/api/status` - System status
- `POST /ocr/api/process` - Process uploaded image

## Configuration

Camera configuration is set in `backend/config.py`:

```python
def get_camera_config(project_root: Path) -> Dict:
    return {
        'camera_id': "http://192.168.0.169:8080/video",
        'resolution': (1280, 720),
        'framerate': 10,
        'capture_dir': str(project_root / 'data' / 'captures'),
        'max_capture_size': 1920
    }
```

## Video Streaming Improvements

1. **Background Threading**: Frames are captured in a separate thread, reducing latency
2. **Frame Caching**: Frames are cached for 200ms to reduce redundant camera reads
3. **Rate Limiting**: Maximum 5 FPS to prevent camera overload
4. **Error Recovery**: Automatic backoff on consecutive errors
5. **Statistics**: Real-time FPS and error tracking

## Code Quality

- ✅ Singleton pattern for all MVC components
- ✅ Thread-safe singleton implementation
- ✅ Type hints throughout
- ✅ Comprehensive docstrings
- ✅ Error handling with logging
- ✅ Resource cleanup
- ✅ Input validation
- ✅ Separation of concerns
- ✅ Constants for magic numbers
- ✅ Thread-safe operations

## Architecture Benefits

1. **Single Source of Truth**: One instance per component
2. **Reduced Memory**: No duplicate instances
3. **Consistent State**: Shared state across requests
4. **Easier Testing**: Can reset singletons for testing
5. **Better Resource Management**: Single camera/OCR initialization
6. **Cleaner Code**: No need to pass instances around
