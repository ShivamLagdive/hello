"""
Quick Camera Test - No OCR needed
Save this as: test_camera.py (in project root)
"""

import cv2
import numpy as np
from datetime import datetime

print("\n" + "="*60)
print("🎥 QUICK CAMERA TEST")
print("="*60 + "\n")

# Test camera 0
print("Testing camera 0...")
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("❌ Camera 0 not found. Trying camera 1...")
    cap = cv2.VideoCapture(1)
    
    if not cap.isOpened():
        print("\n❌ NO CAMERA FOUND!")
        print("\nFor phone camera:")
        print("1. Install 'IP Webcam' app on Android")
        print("2. Start the app, note the IP address")
        print("3. In camera_app.py, change:")
        print("   'camera_id': 0")
        print("   to:")
        print("   'camera_id': 'http://YOUR_PHONE_IP:8080/video'")
        print("\nFor USB camera:")
        print("1. Check: ls /dev/video*")
        print("2. Run: sudo usermod -a -G video $USER")
        print("3. Logout and login")
        exit(1)

print("✅ Camera opened!\n")

# Get properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

print(f"Resolution: {width}x{height}")

# Test capture
ret, frame = cap.read()
if not ret:
    print("❌ Can't capture frames!")
    cap.release()
    exit(1)

print("✅ Frame capture works!\n")

# Quality check
gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
brightness = np.mean(gray)

print(f"Brightness: {brightness:.1f}/255")
if brightness < 80:
    print("⚠️  Too dark - add lighting")
elif brightness > 180:
    print("⚠️  Too bright")
else:
    print("✅ Good!")

print("\n👁️ Opening preview window...")
print("Press Q to quit, S to save test image\n")

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Add info
    timestamp = datetime.now().strftime("%H:%M:%S")
    cv2.putText(frame, f"Time: {timestamp}", (10, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "Press Q=Quit | S=Save", (10, 60),
               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    cv2.imshow('Camera Test', frame)
    
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('s'):
        filename = f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        cv2.imwrite(filename, frame)
        print(f"💾 Saved: {filename}")

cap.release()
cv2.destroyAllWindows()

print("\n✅ Test complete!")
print("\nNext: run python3 camera_app.py")