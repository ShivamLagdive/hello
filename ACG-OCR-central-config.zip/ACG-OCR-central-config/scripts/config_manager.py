"""
Configuration Management Module
Handles all configuration loading, validation, and custom dictionary management
"""

import os
import json
import yaml
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class OCRConfig:
    """Centralized configuration with YAML support and validation"""
    
    DEFAULT_CONFIG = {
        'ocr_engine': {
            'use_angle_cls': False,
            'lang': 'en',
            # RASPBERRY PI OPTIMIZED
            'det_limit_side_len': 1920,  # Reduced from 1280 for Raspberry Pi
            'det_db_box_thresh': 0.3,
            'det_db_thresh': 0.3,
            'det_db_unclip_ratio': 1.6,
            'use_gpu': False,  # Disable GPU for Raspberry Pi
            'enable_mkldnn': False  # Disable MKLDNN for Raspberry Pi
        },
        'image_classifier': {
            'aspect_ratio_threshold': 1.3,
            'edge_density_low': 0.12,
            'saturation_low': 20,
            'brightness_high': 150,
            'document_score_threshold': 5
        },
        'text_processing': {
            'min_text_length': 2,
            'confidence_threshold': 0.60,  # Match the YAML
            'high_confidence_no_correct': 0.95,
            'similarity_threshold': 0.7,
            'duplicate_threshold': 0.95
        },
        'variants': {
            'document_mode': {
                'enabled': ['original', 'enhanced', 'rotated_180'],
                'weights': {
                    'original': 1.0,
                    'enhanced': 0.95,
                    'rotated_180': 0.9
                }
            },
            'product_mode': {
                'enabled': [
                    'original', 
                    'enhanced', 
                    'high_contrast',
                    'sharpened',
                    'denoised',
                    'rotated_180'  # Most common for upside-down boxes
                ],
                'weights': {
                    'original': 1.0, 
                    'enhanced': 0.95,
                    'high_contrast': 0.92,
                    'sharpened': 0.9,
                    'denoised': 0.85,
                    'rotated_180': 0.95,
                    'rotated_90': 0.9,
                    'rotated_270': 0.9
                },
                'clahe': {'clipLimit': 3.0, 'tileGridSize': [8, 8]},
                'denoise': {'h': 10, 'hColor': 10, 'templateWindowSize': 7, 'searchWindowSize': 21}
            }
        },
        'clustering': {
            'spatial_tolerance': 30,  # Increased for better merging
            'method': 'average',
            'criterion': 'distance',
            'distance_threshold': 50
        },
        'correction': {
            'product_rules': {
                'preserve_all_caps': True,
                'preserve_numbers': True,
                'preserve_short_words': 3
            },
            'document_rules': {
                'correct_mixed_case': True,
                'min_word_length': 4,
                'case_ratio_threshold': 2
            }
        },
        'barcode': {
            'save_individual_images': True,
            'output_dir': '../data/barcodes',
            'image_format': 'png',
            'padding': 10
        },
        'output': {
            'save_visualization': True,
            'visualization_dir': '../data/ocr_results',
            'text_output_dir': '../data/text',
            'save_json': True
        }
    }
    
    def __init__(self, config_path=None):
        """Initialize configuration with optional custom config file"""
        self.config = self._deep_copy(self.DEFAULT_CONFIG)
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = yaml.safe_load(f)
                    if user_config:
                        self._deep_update(self.config, user_config)
                        logger.info(f"✅ Loaded custom config from {config_path}")
            except Exception as e:
                logger.error(f"❌ Error loading config: {e}")
        
        # Load custom dictionaries
        self.custom_dict = {}
        self.load_custom_dictionary()
        
        # Create output directories
        self._create_output_dirs()
    
    def _deep_copy(self, obj):
        """Deep copy dictionary"""
        if isinstance(obj, dict):
            return {k: self._deep_copy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._deep_copy(item) for item in obj]
        return obj
    
    def _deep_update(self, base, update):
        """Recursively update nested dictionaries"""
        for key, value in update.items():
            if isinstance(value, dict) and key in base and isinstance(base[key], dict):
                self._deep_update(base[key], value)
            else:
                base[key] = value
    
    def _create_output_dirs(self):
        """Create necessary output directories"""
        dirs_to_create = [
            self.config['barcode']['output_dir'],
            self.config['output']['visualization_dir'],
            self.config['output']['text_output_dir']
        ]
        
        for dir_path in dirs_to_create:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    def load_custom_dictionary(self, dict_path='custom_dict.json'):
        """Load user-provided custom dictionary"""
        if os.path.exists(dict_path):
            try:
                with open(dict_path, 'r', encoding='utf-8') as f:
                    self.custom_dict = json.load(f)
                    logger.info(f"✅ Loaded custom dictionary: {len(self.custom_dict)} entries")
            except Exception as e:
                logger.error(f"❌ Error loading custom dictionary: {e}")
                self._load_default_dictionary()
        else:
            self._load_default_dictionary()
    
    def _load_default_dictionary(self):
        """Load default minimal dictionary"""
        self.custom_dict = {
            "lietle": "lifestyle",
            "uthor": "author",
            "cocretor": "cocreator",
            "recieve": "receive",
            "occured": "occurred",
            "Handk": "Handle",
            "workplay": "work and play",
            "computingboth": "computing, both",
            "Essentia": "Essential"
        }
        logger.info("ℹ️ Using default dictionary")
    
    def save_config(self, path='ocr_config.yaml'):
        """Save current configuration to file"""
        try:
            with open(path, 'w') as f:
                yaml.dump(self.config, f, default_flow_style=False, sort_keys=False)
            logger.info(f"💾 Saved config to {path}")
        except Exception as e:
            logger.error(f"❌ Error saving config: {e}")
    
    def save_custom_dictionary(self, path='custom_dict.json'):
        """Save custom dictionary to file"""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.custom_dict, f, indent=2, ensure_ascii=False)
            logger.info(f"💾 Saved custom dictionary to {path}")
        except Exception as e:
            logger.error(f"❌ Error saving dictionary: {e}")
    
    def add_dictionary_entry(self, wrong_word, correct_word):
        """Add entry to custom dictionary"""
        self.custom_dict[wrong_word] = correct_word
        logger.info(f"➕ Added: '{wrong_word}' → '{correct_word}'")
    
    def get(self, *keys, default=None):
        """Access nested config values safely"""
        value = self.config
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            if default is not None:
                return default
            raise KeyError(f"Configuration key not found: {'.'.join(keys)}")
    
    def validate(self):
        """Validate configuration values"""
        errors = []
        
        # Validate thresholds
        if not 0 <= self.get('text_processing', 'confidence_threshold') <= 1:
            errors.append("confidence_threshold must be between 0 and 1")
        
        if not 0 <= self.get('text_processing', 'similarity_threshold') <= 1:
            errors.append("similarity_threshold must be between 0 and 1")
        
        # Validate directories
        barcode_dir = self.get('barcode', 'output_dir')
        if not isinstance(barcode_dir, str) or not barcode_dir:
            errors.append("barcode output_dir must be a non-empty string")
        
        if errors:
            logger.error(f"❌ Configuration validation failed:")
            for error in errors:
                logger.error(f"   - {error}")
            return False
        
        logger.info("✅ Configuration validation passed")
        return True


if __name__ == "__main__":
    # Test configuration manager
    print("🧪 Testing Configuration Manager\n")
    
    config = OCRConfig()
    
    # Validate
    config.validate()
    
    # Test access
    print(f"\nOCR Language: {config.get('ocr_engine', 'lang')}")
    print(f"Barcode Output Dir: {config.get('barcode', 'output_dir')}")
    
    # Add custom dictionary entry
    config.add_dictionary_entry("teh", "the")
    
    # Save configuration
    config.save_config('test_config.yaml')
    config.save_custom_dictionary('test_dict.json')
    
    print("\n✅ Configuration Manager Test Complete")