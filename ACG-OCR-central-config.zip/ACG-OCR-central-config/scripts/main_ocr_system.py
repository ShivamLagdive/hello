"""
Main OCR System - Orchestrator
Combines all modules for complete OCR + Barcode processing with 100% accuracy focus
"""

import os
import cv2
import numpy as np
from pathlib import Path
import json
import csv
from datetime import datetime
import logging
import traceback
from ocr_text_processor import (
    ImageClassifier,
    OCREngine,
    TextDetector,
    TextCorrector,
    SentenceBuilder   # ← ADD THIS
)

# Import custom modules
from config_manager import OCRConfig
from spellchecker import SpellChecker
from barcode_processor import BarcodeProcessor
from ocr_text_processor import ImageClassifier, OCREngine, TextDetector, TextCorrector

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ocr_system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class AdvancedOCRSystem:
    """
    Complete OCR System with modular architecture
    - Barcode/QR detection and extraction
    - Text OCR with preprocessing
    - Domain-adaptive text correction
    - Comprehensive output with images
    """
    
    def __init__(self, config_path=None):
        """Initialize all system components"""
        logger.info("🧠 Loading Advanced OCR System...")
        
        try:
            # Load configuration
            self.config = OCRConfig(config_path)
            self.config.validate()
            
            # Initialize components
            self.barcode_processor = BarcodeProcessor(self.config)
            self.image_classifier = ImageClassifier(self.config)
            self.ocr_engine = OCREngine(self.config)
            self.text_detector = TextDetector(self.config, self.ocr_engine)
            self.text_corrector = TextCorrector(self.config)
            
            logger.info("✅ OCR System Ready!\n")
            
        except Exception as e:
            logger.error(f"❌ System initialization failed: {e}")
            logger.error(traceback.format_exc())
            raise
    
    def process_image(self, image_path, save_outputs=True, scan_type=None):
        """
        Complete image processing pipeline
        
        Args:
            image_path: Path to input image
            save_outputs: Whether to save results to disk
            scan_type: Optional scan type ('tag', 'weight', 'box_label'). 
                      If None, will try to extract from filename.
            
        Returns:
            dict: Complete processing results
        """
        if not os.path.exists(image_path):
            error_msg = f"File not found: {image_path}"
            logger.error(f"❌ {error_msg}")
            return {"success": False, "error": error_msg}
        
        logger.info(f"🤖 Processing: {image_path}\n")
        logger.info("="*70)
        
        try:
            # Load image
            original_img = cv2.imread(image_path)
            if original_img is None:
                raise ValueError("Failed to load image")
            
            image_name = Path(image_path).stem
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Extract scan_type from filename if not provided
            if scan_type is None:
                # Try to extract from filename pattern: {scan_type}_{timestamp}.jpg
                filename_parts = image_name.split('_')
                if filename_parts:
                    potential_scan_type = filename_parts[0]
                    if potential_scan_type in ['tag', 'weight', 'box_label']:
                        scan_type = potential_scan_type
                        logger.info(f"📋 Detected scan_type from filename: {scan_type}")
            else:
                logger.info(f"📋 Using provided scan_type: {scan_type}")
            
            # ============================================================
            # STEP 1: CLASSIFY IMAGE TYPE
            # ============================================================
            logger.info("STEP 1: Image Classification")
            img_type, features = self.image_classifier.classify(image_path)
            logger.info("")
            
            # ============================================================
            # STEP 2: DETECT AND EXTRACT BARCODES
            # ============================================================
            # Skip barcode detection for all scan types (weight, tag, box_label)
            skip_barcode_detection = scan_type in ['weight', 'tag', 'box_label']
            
            if skip_barcode_detection:
                logger.info(f"⏭️  STEP 2: Barcode/QR Code Detection - SKIPPED (scan_type: {scan_type})")
                logger.info(f"   Reason: Barcode detection is disabled for '{scan_type}' scan type")
                barcodes = []
                barcode_count = 0
                metadata_path = None
            else:
                logger.info("STEP 2: Barcode/QR Code Detection")
                barcode_result = self.barcode_processor.detect_and_extract(
                    image_path, image_name
                )
                
                barcodes = barcode_result.get('barcodes', [])
                barcode_count = barcode_result.get('count', 0)
                
                # Save metadata if barcodes found
                metadata_path = None
                if barcode_count > 0 and save_outputs:
                    metadata_path = self.barcode_processor.save_barcode_metadata(
                        barcodes, image_name, timestamp
                    )
            logger.info("")
            
            # ============================================================
            # STEP 3: TEXT DETECTION (OCR)
            # ============================================================
            logger.info("STEP 3: Text Detection (OCR)")
            detections = self.text_detector.detect_text(image_path, img_type)
            
            if not detections:
                logger.warning("⚠️ No text detected in image")
            
            # ============================================================
            # STEP 4: TEXT CORRECTION
            # ============================================================
            logger.info("STEP 4: Text Correction")
            corrections_made = 0
            
            for det in detections:
                original_text = det["text"]
                corrected_text, was_corrected = self.text_corrector.correct_text(
                    original_text,
                    img_type,
                    det["confidence"]
                )
                
                if was_corrected:
                    corrections_made += 1
                    det["original_text"] = original_text
                    det["text"] = corrected_text
                    logger.info(f"   ✅ '{original_text}' → '{corrected_text}'")
            
            if corrections_made == 0:
                logger.info("   ℹ️ No corrections needed")
            logger.info("")
            
            # ============================================================
            # STEP 5: BUILD OUTPUT TEXT
            # ============================================================
            logger.info("STEP 5: Building Output")
            
            # Combine barcode and OCR text
            full_text = self._build_output_text(barcodes, detections)
            
            # ============================================================
            # STEP 6: VISUALIZATION
            # ============================================================
            visualization_img = original_img.copy()
            
            # Draw barcodes (green boxes)
            if barcodes:
                visualization_img = self.barcode_processor.draw_barcodes_on_image(
                    visualization_img, barcodes, color=(0, 255, 0), thickness=3
                )
            
            # Draw text regions (red/orange boxes)
            for det in detections:
                box = np.array(det["box"]).astype(np.int32)
                color = (0, 165, 255) if "original_text" in det else (0, 0, 255)
                cv2.polylines(visualization_img, [box], True, color, 2)
                
                # Add confidence label
                cx, cy = det["center"]
                conf_text = f"{int(det['confidence']*100)}%"
                cv2.putText(visualization_img, conf_text, (cx, cy),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
            
# ============================================================
            # STEP 7: SAVE OUTPUTS (UPDATED FOR FOLDER-PER-IMAGE)
            # ============================================================
            output_paths = {}
            
            if save_outputs:
                # 1. Create a specific folder for this image
                # It will create: ocr_results/YourImageName/
                base_folder = Path(self.config.get('output', 'visualization_dir'))
                image_folder = base_folder / image_name
                image_folder.mkdir(parents=True, exist_ok=True)

                # 2. Save Visualization
                viz_path = image_folder / f"{image_name}_{timestamp}_result.jpg"
                cv2.imwrite(str(viz_path), visualization_img)
                output_paths['visualization'] = str(viz_path)
                logger.info(f"💾 Visualization: {viz_path}")
                
                # 3. Save Text Output
                text_path = image_folder / f"{image_name}_{timestamp}_text.txt"
                with open(text_path, 'w', encoding='utf-8') as f:
                    f.write(full_text)
                output_paths['text'] = str(text_path)
                logger.info(f"💾 Text Output: {text_path}")
                
                # 4. Save JSON Report
                if self.config.get('output', 'save_json'):
                    json_path = image_folder / f"{image_name}_{timestamp}_report.json"
                    report = self._build_json_report(
                        image_path, img_type, features, barcodes, 
                        detections, corrections_made, output_paths
                    )
                    with open(json_path, 'w', encoding='utf-8') as f:
                        json.dump(report, f, indent=2, ensure_ascii=False)
                    output_paths['json'] = str(json_path)
                    logger.info(f"💾 JSON Report: {json_path}")
            
            # ============================================================
            # STEP 8: PRINT SUMMARY
            # ============================================================
            self._print_summary(img_type, barcode_count, len(detections), 
                               corrections_made, full_text)
            
            # Build final result
            result = {
                "success": True,
                "image_path": image_path,
                "image_type": img_type,
                "timestamp": timestamp,
                "features": features,
                "statistics": {
                    "barcodes_detected": barcode_count,
                    "text_regions_detected": len(detections),
                    "corrections_made": corrections_made
                },
                "barcodes": barcodes,
                "barcode_metadata_path": metadata_path,
                "text_detections": detections,
                "full_text": full_text,
                "output_files": output_paths
            }
            
            logger.info("="*70)
            logger.info("✅ Processing Complete!\n")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Processing error: {e}")
            logger.error(traceback.format_exc())
            return {
                "success": False,
                "error": str(e),
                "traceback": traceback.format_exc()
            }
    
    def _build_output_text(self, barcodes, detections):
        """Enhanced with form detection"""
        lines = []
        
        # Barcodes section (unchanged)
        if barcodes:
            lines.append("="*60)
            lines.append("BARCODES & QR CODES DETECTED")
            lines.append("="*60)
            for barcode in barcodes:
                lines.append(f"[{barcode['index']}] {barcode['type']}: {barcode['data']}")
            lines.append("")
        
        # OCR with form awareness
        if detections:
            lines.append("="*60)
            lines.append("FORM DATA EXTRACTED")
            lines.append("="*60)
            
            # Use enhanced builder
            sentence_lines = SentenceBuilder.detections_to_lines(
                detections, 
                base_y_threshold=15
            )
            
            for line_text in sentence_lines:
                # Format field separators
                if " | " in line_text:
                    # Multiple fields on same line
                    lines.append(line_text)
                else:
                    # Single field/line
                    lines.append(line_text)

        return "\n".join(lines)
    
    def _build_json_report(self, image_path, img_type, features, barcodes, 
                          detections, corrections, output_paths):
        """Build comprehensive JSON report"""
        return {
            "metadata": {
                "input_image": image_path,
                "processed_at": datetime.now().isoformat(),
                "image_type": img_type,
                "system_version": "2.0"
            },
            "image_features": features,
            "barcodes": {
                "count": len(barcodes),
                "details": barcodes
            },
            "ocr_results": {
                "text_regions": len(detections),
                "corrections_made": corrections,
                "details": detections
            },
            "output_files": output_paths
        }
    
    def _print_summary(self, img_type, barcode_count, text_count, corrections, full_text):
        """Print processing summary"""
        logger.info("📊 PROCESSING SUMMARY")
        logger.info("="*70)
        logger.info(f"Image Type: {img_type.upper()}")
        logger.info(f"Barcodes/QR Codes: {barcode_count}")
        logger.info(f"Text Regions: {text_count}")
        logger.info(f"Corrections Applied: {corrections}")
        logger.info("")
        logger.info("📜 EXTRACTED TEXT (Preview - First 500 chars):")
        logger.info("-"*70)
        logger.info(full_text[:500])
        if len(full_text) > 500:
            logger.info("...")
        logger.info("")
    
    def batch_process(self, image_paths, output_summary=True):
        """
        Process multiple images in batch
        
        Args:
            image_paths: List of image paths
            output_summary: Whether to generate batch summary
            
        Returns:
            dict: Batch processing results
        """
        logger.info(f"🔄 Starting batch processing: {len(image_paths)} images\n")
        
        results = []
        successful = 0
        failed = 0
        
        for idx, img_path in enumerate(image_paths, 1):
            logger.info(f"\n{'='*70}")
            logger.info(f"IMAGE {idx}/{len(image_paths)}: {img_path}")
            logger.info('='*70)
            
            result = self.process_image(img_path)
            results.append(result)
            
            if result.get('success'):
                successful += 1
            else:
                failed += 1
        
        # Generate summary
        if output_summary:
            summary = {
                "total_images": len(image_paths),
                "successful": successful,
                "failed": failed,
                "results": results,
                "processed_at": datetime.now().isoformat()
            }
            
            summary_path = Path(self.config.get('output', 'text_output_dir')) / \
                          f"batch_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            
            logger.info(f"\n💾 Batch summary saved: {summary_path}")
            # ========================================================
            # 👇 ADD THIS BLOCK HERE (CSV GENERATION)
            # ========================================================
            csv_path = Path(self.config.get('output', 'text_output_dir')) / \
                      f"batch_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            
            try:
                with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # 1. Write Header (With dedicated Barcode Content column)
                    writer.writerow([
                        'Image Name', 
                        'Date', 
                        'Type', 
                        'Barcode Count', 
                        'Barcode Content',   # <--- New Column
                        'OCR Text Content', 
                        'Status'
                    ])
                    
                    # 2. Write Data Rows
                    for res in results:
                        if res.get('success'):
                            stats = res.get('statistics', {})
                            barcodes = res.get('barcodes', [])
                            
                            # Format Barcode Data: "TYPE: Data | TYPE: Data"
                            if barcodes:
                                barcode_text = " | ".join([f"{b['type']}: {b['data']}" for b in barcodes])
                            else:
                                barcode_text = "None"
                            
                            # Clean OCR Text (Remove newlines to keep CSV clean)
                            ocr_text = res.get('full_text', '').replace('\n', ' | ')[:5000]
                            
                            writer.writerow([
                                Path(res['image_path']).name,       # Image Name
                                res.get('timestamp', ''),           # Date/Time
                                res.get('image_type', 'unknown'),   # Type
                                stats.get('barcodes_detected', 0),  # Barcode Count
                                barcode_text,                       # Barcode Content
                                ocr_text,                           # Text Content
                                'Success'
                            ])
                        else:
                            # Handle failed images
                            writer.writerow([
                                Path(res.get('image_path', 'unknown')).name, 
                                datetime.now().strftime("%Y%m%d_%H%M%S"),
                                'ERROR', 0, "N/A", "N/A", 
                                f"Error: {res.get('error', 'Unknown')}"
                            ])
                
                logger.info(f"💾 Batch CSV saved: {csv_path}")
            except Exception as e:
                logger.error(f"❌ Failed to save CSV: {e}")
            # ========================================================
            # ========================================================       
        logger.info(f"\n✅ Batch processing complete: {successful} successful, {failed} failed")
        
        return results
    
    def cleanup(self):
        """Cleanup all system components and release resources"""
        try:
            logger.info("🧹 Cleaning up OCR system components...")
            
            # Cleanup OCR engine first (this releases PaddleOCR instances)
            if hasattr(self, 'ocr_engine') and self.ocr_engine:
                self.ocr_engine.cleanup()
            
            # Cleanup other components
            if hasattr(self, 'text_detector') and self.text_detector:
                # TextDetector doesn't hold resources that need explicit cleanup
                del self.text_detector
            
            if hasattr(self, 'text_corrector') and self.text_corrector:
                # TextCorrector doesn't hold resources that need explicit cleanup
                del self.text_corrector
            
            if hasattr(self, 'image_classifier') and self.image_classifier:
                del self.image_classifier
            
            if hasattr(self, 'barcode_processor') and self.barcode_processor:
                del self.barcode_processor
            
            # Clear references
            self.ocr_engine = None
            self.text_detector = None
            self.text_corrector = None
            self.image_classifier = None
            self.barcode_processor = None
            
            # Force garbage collection
            import gc
            gc.collect()
            
            logger.info("✅ OCR system components cleaned up")
        except Exception as e:
            logger.error(f"Error during OCR system cleanup: {e}")


def main():
    """Main entry point"""
    print("\n" + "="*70)
    print("🚀 ADVANCED OCR SYSTEM v2.0")
    print("="*70 + "\n")
    
    # Initialize system
    config_file = 'ocr_config.yaml' if os.path.exists('ocr_config.yaml') else None
    ocr_system = AdvancedOCRSystem(config_path=config_file)
    
    # Save default config if doesn't exist
    if not os.path.exists('ocr_config.yaml'):
        ocr_system.config.save_config('ocr_config.yaml')
        logger.info("💾 Saved default config to 'ocr_config.yaml'\n")
    
    # ---------------------------------------------------------
    # 📝 USER CONFIGURATION
    # Enter your Folder Name OR File Name here:
    # ---------------------------------------------------------
    input_source = "/home/mahesh/Videos/Autonex/OCR/test/selfmade/0.jpg"   
    # Examples:
    #input_source = "/home/mahesh/Videos/Autonex/OCR/zip files/archive (1)/OCR_TEXT"   #<-- For a whole folder
    # input_source = "receipt.jpg"    <-- For a single file
    # ---------------------------------------------------------

    image_paths = []

    # 1. Check if input is a Folder
    if os.path.isdir(input_source):
        print(f"📂 Detected FOLDER: {input_source}")
        valid_extensions = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"}
        
        # Scan folder for valid images
        for file in os.listdir(input_source):
            ext = os.path.splitext(file)[1].lower()
            if ext in valid_extensions:
                full_path = os.path.join(input_source, file)
                image_paths.append(full_path)
        
        print(f"   Found {len(image_paths)} images in folder.")

    # 2. Check if input is a Single File
    elif os.path.isfile(input_source):
        print(f"📄 Detected SINGLE IMAGE: {input_source}")
        image_paths = [input_source]

    # 3. Fallback: Path doesn't exist
    else:
        print(f"⚠️ Input '{input_source}' not found.")
        print("   Checking for default test images...")
        defaults = ["0.jpg", "nik2.jpeg", "test1.jpg"]
        image_paths = [img for img in defaults if os.path.exists(img)]

    # --- EXECUTION ---
    if not image_paths:
        logger.warning("❌ No valid images found to process!")
        return
    
    # We use batch_process for everything because it handles the CSV generation automatically
    ocr_system.batch_process(image_paths)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ Processing interrupted by user")
    except Exception as e:
        logger.error(f"\n❌ Fatal error: {e}")
        logger.error(traceback.format_exc())
