"""
Standalone Camera App
Save this as: camera_app.py (in project root, same level as app.py)
"""

import sys
from pathlib import Path
import logging
import time
import os

# Add scripts to path
script_dir = Path(__file__).parent
if (script_dir / "scripts").exists():
    sys.path.insert(0, str(script_dir / "scripts"))

try:
    from camera_capture import WebcamCapture
    from main_ocr_system import AdvancedOCRSystem
except ImportError as e:
    print(f"❌ Import Error: {e}")
    print("\nMake sure:")
    print("1. camera_capture.py is in scripts/ folder")
    print("2. Your other OCR files are in scripts/ folder")
    sys.exit(1)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def main():
    print("\n" + "="*70)
    print("📷 WEBCAM AUTO-OCR SYSTEM")
    print("="*70 + "\n")
    
    # ============================================================
    # CONFIGURATION
    # ============================================================
    
    camera_config = {
        #'camera_id': 0,                  # 0 = first camera
        # FOR PHONE via IP Webcam app, use:
        'camera_id': "http://10.76.64.32:8080/video",
        
        'resolution': (1280, 720),
        'framerate': 10,
        'capture_dir': 'camera_captures',
        'max_capture_size': 1920,
        
        'motion_detection': {
            'min_detection_area': 5000,
            'motion_threshold': 25,
            'stable_frames': 5,
            'capture_cooldown': 3
        }
    }
    
    # ============================================================
    # INITIALIZE
    # ============================================================
    
    try:
        print("Choose mode:")
        print("1. Full System (Camera + OCR)")
        print("2. Camera Only (no OCR)")
        
        mode = input("\nChoice (1 or 2): ").strip()
        
        ocr_system = None
        
        if mode == "1":
            logger.info("🤖 Initializing OCR...")
            config_path = 'scripts/ocr_config.yaml' if Path('scripts/ocr_config.yaml').exists() else None
            
            original_dir = os.getcwd()
            if Path('scripts').exists():
                os.chdir('scripts')
            
            try:
                ocr_system = AdvancedOCRSystem(config_path=config_path)
                logger.info("✅ OCR ready\n")
            finally:
                os.chdir(original_dir)
        
        logger.info("📷 Initializing Camera...")
        camera = WebcamCapture(config=camera_config, ocr_system=ocr_system)
        logger.info("✅ Camera ready\n")
        
    except Exception as e:
        logger.error(f"❌ Init failed: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # ============================================================
    # MENU
    # ============================================================
    
    print("\n" + "="*70)
    print("MODES:")
    print("="*70)
    print("1. 🚀 AUTO-CAPTURE - Continuously monitors")
    print("2. 📸 MANUAL CAPTURE - Single shot")
    print("3. 👁️  PREVIEW - 30 second preview")
    print("4. 🔧 TEST MOTION - See motion detection")
    print("5. 📋 LIST CAMERAS - Show available cameras")
    print("="*70 + "\n")
    
    choice = input("Choice (1-5): ").strip()
    
    # ============================================================
    # MODES
    # ============================================================
    
    if choice == "1":
        print("\n🚀 AUTO-CAPTURE MODE")
        print("="*70)
        print("Move objects in front of camera to trigger")
        print("Press Q in window to stop\n")
        
        try:
            camera.start_auto_capture()
        except KeyboardInterrupt:
            print("\n⚠️ Stopping...")
            camera.stop_auto_capture()
    
    elif choice == "2":
        print("\n📸 MANUAL CAPTURE")
        print("Window will open with countdown\n")
        
        result = camera.manual_capture()
        
        if result.get('success'):
            print("\n✅ SUCCESS!")
            print(f"📄 Saved: {result.get('image_path')}")
            
            if ocr_system:
                text = result.get('full_text', '')
                if text:
                    print("\n" + "="*70)
                    print("TEXT:")
                    print("="*70)
                    print(text[:500])
                    if len(text) > 500:
                        print("...")
                
                barcodes = result.get('barcodes', [])
                if barcodes:
                    print("\n" + "="*70)
                    print("BARCODES:")
                    print("="*70)
                    for bc in barcodes:
                        print(f"[{bc['type']}] {bc['data']}")
        else:
            print(f"\n❌ Error: {result.get('error')}")
    
    elif choice == "3":
        print("\n👁️ PREVIEW MODE (30 seconds)")
        print("Press Q to exit early\n")
        camera.preview_stream(duration=30)
    
    elif choice == "4":
        print("\n🔧 MOTION DETECTION TEST")
        print("="*70)
        print("Wave your hand or move objects")
        print("Green boxes show detected motion")
        print("Press Q to stop\n")
        
        original_ocr = camera.ocr_system
        camera.ocr_system = None
        
        try:
            camera.start_auto_capture()
        finally:
            camera.ocr_system = original_ocr
    
    elif choice == "5":
        print("\n📋 SCANNING FOR CAMERAS...\n")
        available = camera.list_cameras()
        
        if available:
            print(f"\n✅ Found {len(available)} camera(s): {available}")
            print("\nTo use different camera:")
            print("Edit camera_app.py, change: 'camera_id': 0")
        else:
            print("\n❌ No cameras!")
            print("Troubleshooting:")
            print("1. Check connection")
            print("2. ls /dev/video*")
            print("3. sudo usermod -a -G video $USER")
    
    else:
        print("Invalid choice")
    
    print("\n🧹 Cleanup...")
    camera.cleanup()
    print("✅ Done!\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.error(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()