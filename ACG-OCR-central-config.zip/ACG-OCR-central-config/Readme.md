# 🏭 ACG-OCR - Pharmaceutical Packaging Verification System

> **Advanced OCR-based Quality Control System for Pharmaceutical Manufacturing**

An automated packaging verification system that uses computer vision and OCR to verify weights, scan alphanumeric tags, and capture box labels in pharmaceutical manufacturing workflows.

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![OpenCV](https://img.shields.io/badge/OpenCV-4.5+-green.svg)](https://opencv.org/)
[![PaddleOCR](https://img.shields.io/badge/PaddleOCR-Latest-orange.svg)](https://github.com/PaddlePaddle/PaddleOCR)
[![Flask](https://img.shields.io/badge/Flask-3.0+-green.svg)](https://flask.palletsprojects.com/)

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Features](#-features)
- [System Architecture](#-system-architecture)
- [Prerequisites](#-prerequisites)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Usage Guide](#-usage-guide)
- [Configuration](#-configuration)
- [Project Structure](#-project-structure)
- [API Reference](#-api-reference)
- [Troubleshooting](#-troubleshooting)
- [License](#-license)

---

## 🎯 Overview

This system automates the pharmaceutical packaging quality control process by using real-time camera capture and OCR technology to:

1. **Verify package weights** from digital weighing scale displays
2. **Scan and validate alphanumeric tags** on product labels
3. **Capture machine numbers** written on sealed boxes

The system reduces human error, increases throughput, and maintains a digital audit trail of all packaging operations.

### Real-World Application

**Typical Workflow:**
```
Worker places bag → Scale shows weight → Camera captures → OCR extracts "45.5 kg"
→ HMI displays for verification → Worker confirms → Tag is scanned → Process continues
```

---

## ✨ Features

### Core Capabilities
- 🎥 **Real-time Camera Integration** - Live video feed with efficient frame streaming
- 🔍 **Advanced OCR Engine** - PaddleOCR + ZXing + Pyzbar for maximum accuracy
- 📊 **Web-based HMI Interface** - Clean, operator-friendly interface accessible via browser
- ✅ **Verification Workflow** - Confirm and Next button for streamlined workflow
- 📈 **Cycle Tracking** - Automatic counting of completed packages
- 🔔 **Smart Notifications** - Color-coded alerts and status messages
- 🔄 **Instant Rescan** - Quick value clearing and re-capture

### OCR Features
- Multi-language support (English, Hindi, Chinese, etc.)
- Barcode/QR code detection and extraction
- Rotation-invariant text detection
- Document preprocessing for challenging conditions
- Domain-adaptive text correction
- High-accuracy extraction patterns

### Hardware Support
- 💻 Laptop/Desktop webcams
- 🔌 USB cameras
- 📱 Phone cameras (via IP Webcam app)
- 🏭 Industrial cameras
- 🍓 Raspberry Pi compatible

---

## 🏗️ System Architecture

The application uses a **dual-service architecture** to support different Python versions:

### Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    WEB BROWSER                           │
│  ┌──────────────────────────────────────────────────┐  │
│  │  HTML/CSS/JS Frontend                             │  │
│  │  - Pharma HMI Interface                           │  │
│  │  - OCR Dashboard                                  │  │
│  │  - Live Camera Feed                               │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                           ↕ HTTP
┌─────────────────────────────────────────────────────────┐
│         FLASK OCR APP (Python 3.10 + PaddleOCR)          │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Controllers (Singleton Pattern)                  │  │
│  │  ├── PharmaController                             │  │
│  │  └── OCRController                                │  │
│  │                                                    │  │
│  │  Models (Singleton Pattern)                       │  │
│  │  ├── OCRModel                                     │  │
│  │  ├── CameraModel (uses CameraClient)              │  │
│  │  └── SessionModel                                 │  │
│  │                                                    │  │
│  │  Services                                         │  │
│  │  ├── VideoStreamService                           │  │
│  │  └── CameraClient (HTTP client)                  │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                           ↕ HTTP (localhost:8000)
┌─────────────────────────────────────────────────────────┐
│      CAMERA SERVICE (Python 3.13 + Picamera2)           │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Flask Service                                    │  │
│  │  ├── GET /stream.mjpg (MJPEG stream)            │  │
│  │  ├── POST /capture (capture image)               │  │
│  │  └── GET /health (health check)                  │  │
│  │                                                    │  │
│  │  Hardware Interface                               │  │
│  │  └── Picamera2 (CSI camera)                      │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                           ↕
┌─────────────────────────────────────────────────────────┐
│                   OCR ENGINE LAYER                       │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Advanced OCR System (main_ocr_system.py)        │  │
│  │  ├── PaddleOCR (Text Detection)                  │  │
│  │  ├── ZXing/Pyzbar (Barcode/QR)                  │  │
│  │  ├── Image Preprocessing                         │  │
│  │  └── Text Correction                             │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### Why Two Services?

- **Camera Service (Python 3.13)**: Uses Picamera2 which requires system Python 3.13
- **Flask OCR App (Python 3.10)**: Uses PaddlePaddle OCR which requires Python 3.10 in venv
- **Separation**: Allows each service to run in its optimal Python environment
- **Communication**: Services communicate via HTTP on localhost (127.0.0.1:8000)

---

## 📦 Prerequisites

### System Requirements

**Minimum:**
- Python 3.8 or higher
- 4GB RAM (8GB recommended for Raspberry Pi 4)
- 2GB free disk space
- USB/Built-in camera

**Recommended:**
- Python 3.9+
- 8GB+ RAM
- SSD storage
- 720p or higher camera

### Software Dependencies

All dependencies are listed in `requirements.txt`. Core libraries include:

```
opencv-python >= 4.5.0
paddleocr >= 2.6.0
pyzbar >= 0.1.9
zxing-cpp >= 2.3.0
flask >= 3.0.0
flask-cors >= 4.0.0
numpy >= 1.21.0
pillow >= 9.0.0
pyyaml >= 6.0
```

---

## 🚀 Installation

### Step 1: Clone or Download Project

```bash
# Navigate to project directory
cd ACG-OCR
```

### Step 2: Create Virtual Environment

```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

### Step 3: Install Dependencies

```bash
# Install all dependencies
pip install -r requirements.txt
```

**For Raspberry Pi:**
```bash
# Install system dependencies first
sudo apt-get update
sudo apt-get install -y python3-opencv libzbar0

# Then install Python packages
pip3 install -r requirements.txt
```

### Step 4: Install Camera Service Dependencies

For the Camera Service (Python 3.13), install Picamera2:

```bash
# Install Picamera2 (requires system Python 3.13)
sudo apt-get update
sudo apt-get install -y python3-picamera2 python3-opencv
```

**Note:** The camera service runs on system Python 3.13, while the Flask OCR app runs on Python 3.10 in a venv.

### Step 5: Configure Camera Service

The camera service uses Picamera2 and is configured in `camera_service.py`. For CSI cameras on Raspberry Pi, no additional configuration is needed. The service will automatically detect and use the CSI camera.

**Camera Service URL:** `http://127.0.0.1:8000` (default, can be changed in `camera_service.py`)

### Step 5: Initialize OCR Configuration

The OCR system will automatically create `scripts/ocr_config.yaml` with default settings on first run.

---

## 🎬 Quick Start

### Dual-Service Setup

The application consists of two services that must run simultaneously:

#### 1. Start Camera Service (Python 3.13)

```bash
# Run using system Python 3.13 (Picamera2 requires system Python)
python3 camera_service.py
```

The camera service will start on `http://127.0.0.1:8000`

**Endpoints:**
- `GET /stream.mjpg` - MJPEG live stream
- `POST /capture` - Capture still image
- `GET /health` - Health check

#### 2. Start Flask OCR App (Python 3.10)

```bash
# Activate virtual environment (Python 3.10)
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate  # Windows

# Run the Flask application
python -m backend.main
# or
python run.py
```

The Flask app will start on `http://localhost:5000`

### Quick Start Script

For convenience, you can run both services in separate terminals:

**Terminal 1 (Camera Service):**
```bash
python3 camera_service.py
```

**Terminal 2 (Flask OCR App):**
```bash
source venv/bin/activate
python -m backend.main
```

### Using systemd (Raspberry Pi)

For automatic startup on boot:

```bash
# Copy service files
sudo cp systemd/camera-service.service /etc/systemd/system/
sudo cp systemd/flask-ocr-app.service /etc/systemd/system/

# Edit service files to match your paths
sudo nano /etc/systemd/system/camera-service.service
sudo nano /etc/systemd/system/flask-ocr-app.service

# Enable and start services
sudo systemctl daemon-reload
sudo systemctl enable camera-service.service
sudo systemctl enable flask-ocr-app.service
sudo systemctl start camera-service.service
sudo systemctl start flask-ocr-app.service

# Check status
sudo systemctl status camera-service.service
sudo systemctl status flask-ocr-app.service
```

### Access the Interfaces

1. **Pharma HMI** (Main interface): `http://localhost:5000/pharma`
2. **OCR Dashboard** (Image processing): `http://localhost:5000/ocr`
3. **Root** (Redirects to Pharma HMI): `http://localhost:5000`

### First-Time Setup

1. Application starts and initializes camera and OCR system
2. Camera feed appears in the browser
3. System shows "✅ Systems initialized!"
4. Click "🎯 Capture" buttons to start scanning

---

## 📖 Usage Guide

### Complete Workflow

#### **Step 1: Tag Scan**

1. Worker holds alphanumeric tag below camera
2. Click **"🎯 Capture Tag"** button
3. OCR extracts tag code (e.g., "ABC1234")
4. HMI shows: **"ABC1234"**

**Worker Actions:**
- ✅ Click **"Confirm and Next"** if tag is correct
- 🔄 Click **"Rescan"** if wrong or unclear

#### **Step 2: Weight Verification**

1. Worker places bag on weighing scale
2. Scale displays weight (e.g., "45.5 kg")
3. Click **"🎯 Capture Weight"** button
4. OCR extracts the weight value
5. HMI shows: **"45.5 kg"**

**Worker Actions:**
- ✅ Click **"Confirm and Next"** if weight is correct
- 🔄 Click **"Rescan"** if value is wrong or unclear

#### **Step 3: Box Label & Machine Number**

1. Worker closes box flaps
2. Worker writes machine number on box (e.g., "M-15")
3. Click **"🎯 Capture Box Label"** button
4. OCR extracts machine number
5. HMI shows: **"M-15"**

**Worker Actions:**
- ✅ Click **"Complete Cycle"** to finish and start new box
- 🔄 Click **"Rescan"** if number is wrong

#### **Cycle Complete!**
- Cycle counter increments: `Cycle Count: 1 → 2`
- System automatically resets to Step 1 (Tag Scan)
- Ready for next box immediately

---

## ⚙️ Configuration

### Camera Configuration

Edit `backend/config.py`:

```python
def get_camera_config(project_root: Path) -> Dict:
    return {
        'camera_id': "http://192.168.0.169:8080/video",  # Your camera source
        'resolution': (1280, 720),  # Camera resolution
        'framerate': 10,  # FPS (lower for Raspberry Pi)
        'capture_dir': str(project_root / 'data' / 'captures'),
        'max_capture_size': 1920  # Resize for faster processing
    }
```

### OCR Configuration

Edit `scripts/ocr_config.yaml`:

```yaml
ocr_engine:
  use_angle_cls: false      # Rotation detection (slower)
  lang: 'en'                # Language: en, ch, hi, etc.
  det_limit_side_len: 1280  # Max image dimension
  det_db_box_thresh: 0.3    # Detection threshold
  det_db_thresh: 0.3        # Binarization threshold

text_processing:
  min_text_length: 2        # Minimum characters
  confidence_threshold: 0.60 # OCR confidence filter
  high_confidence_no_correct: 0.95  # Skip correction threshold
```

### Value Extraction Patterns

Customize patterns in `backend/utils/validators.py`:

```python
# Weight patterns
weight_patterns = [
    r'(\d+\.?\d*)\s*kg',      # "45.5 kg"
    r'Weight:\s*(\d+\.?\d*)', # "Weight: 45.5"
]

# Tag patterns
tag_patterns = [
    r'[A-Z]{2,4}\d{3,5}',     # "ABC1234"
    r'[A-Z]{2,4}-\d{3,5}',    # "ABC-1234"
]

# Machine number patterns
machine_patterns = [
    r'M-\d+',                 # "M-15"
    r'Machine\s*\d+',         # "Machine 15"
]
```

---

## 📁 Project Structure

```
ACG-OCR/
│
├── backend/                      # Flask MVC Backend
│   ├── app.py                    # Flask app factory
│   ├── main.py                   # Application entry point
│   ├── config.py                 # Configuration settings
│   │
│   ├── controllers/              # Route handlers (Singletons)
│   │   ├── base_controller.py    # Base controller class
│   │   ├── pharma_controller.py  # Pharma HMI routes
│   │   └── ocr_controller.py     # OCR Dashboard routes
│   │
│   ├── models/                   # Data models (Singletons)
│   │   ├── ocr_model.py          # OCR operations
│   │   ├── camera_model.py       # Camera operations
│   │   └── session_model.py      # Session state management
│   │
│   ├── services/                 # Business logic services
│   │   └── video_stream_service.py  # Video streaming
│   │
│   ├── utils/                    # Utility functions
│   │   ├── image_utils.py        # Image processing
│   │   ├── validators.py         # Value extraction
│   │   ├── context_managers.py   # Resource management
│   │   └── response_helpers.py   # API response formatting
│   │
│   ├── core/                     # Core functionality
│   │   └── singleton.py          # Singleton metaclass
│   │
│   └── views/                    # Frontend templates and assets
│       ├── templates/            # Jinja2 HTML templates
│       │   ├── pharma_hmi.html  # Pharma HMI page
│       │   └── ocr_dashboard.html  # OCR Dashboard page
│       └── static/              # Static assets
│           ├── css/             # Stylesheets
│           ├── js/              # JavaScript
│           └── images/         # Images
│
├── scripts/                      # OCR System Scripts
│   ├── main_ocr_system.py        # OCR orchestrator
│   ├── camera_capture.py         # Camera interface
│   ├── ocr_text_processor.py     # OCR processing
│   ├── config_manager.py         # Configuration management
│   ├── barcode_processor.py      # Barcode handling
│   └── ocr_config.yaml           # OCR settings
│
├── data/                         # Runtime data
│   ├── captures/                # Captured images
│   └── temp_uploads/            # Temporary uploads
│
├── result/                       # OCR results output
│   ├── barcodes/                # Extracted barcodes
│   ├── text/                    # Text outputs
│   └── visualization/           # Annotated images
│
├── tests/                        # Test files
│
├── run.py                        # Main entry point
├── requirements.txt              # Python dependencies
└── Readme.md                     # This file
```

---

## 📡 API Reference

### Pharma HMI Endpoints (`/pharma`)

#### `GET /pharma/`
**Description:** Main Pharma HMI page

**Response:** HTML page

#### `GET /pharma/api/status`
**Description:** Check system status

**Response:**
```json
{
  "success": true,
  "status": "ready",
  "ocr_initialized": true,
  "camera_ready": true
}
```

#### `GET /pharma/api/frame`
**Description:** Get current camera frame as JPEG

**Response:** Binary image data (JPEG)

#### `GET /pharma/api/stats`
**Description:** Get video stream statistics

**Response:**
```json
{
  "success": true,
  "fps": 5.2,
  "errors": 0,
  "cache_hits": 150
}
```

#### `GET /pharma/api/session`
**Description:** Get current session data

**Response:**
```json
{
  "success": true,
  "session_data": {
    "current_step": "tag",
    "cycle_count": 0,
    "weight_value": "",
    "tag_value": "",
    "box_label_value": "",
    "camera_rotation": 0
  }
}
```

#### `POST /pharma/api/capture`
**Description:** Capture and process image with OCR

**Request:**
```json
{
  "scan_type": "weight",  // "weight" | "tag" | "box_label"
  "rotation": 0  // Optional: 0, 90, 180, 270
}
```

**Response:**
```json
{
  "success": true,
  "extracted_value": "45.5 kg",
  "full_text": "Weight: 45.5 kg",
  "frame": "base64_encoded_image",
  "filepath": "data/captures/weight_20241229_143052.jpg"
}
```

#### `POST /pharma/api/verify`
**Description:** Verify current step value

**Request:**
```json
{
  "extracted_value": "45.5 kg"
}
```

**Response:**
```json
{
  "success": true,
  "step": "weight",
  "value": "45.5 kg"
}
```

#### `POST /pharma/api/rescan`
**Description:** Clear current step value for rescanning

**Response:**
```json
{
  "success": true,
  "step": "weight",
  "cleared": true
}
```

#### `POST /pharma/api/next`
**Description:** Move to next workflow step

**Response:**
```json
{
  "success": true,
  "next_step": "weight",
  "current_step": "weight",
  "cycle_complete": false
}
```

#### `POST /pharma/api/reset`
**Description:** Reset cycle (start new cycle)

**Response:**
```json
{
  "success": true,
  "cycle_count": 1,
  "message": "Cycle reset"
}
```

#### `POST /pharma/api/set_rotation`
**Description:** Set camera rotation angle

**Request:**
```json
{
  "rotation_angle": 90  // 0, 90, 180, or 270
}
```

**Response:**
```json
{
  "success": true,
  "rotation": 90
}
```

### OCR Dashboard Endpoints (`/ocr`)

#### `GET /ocr/`
**Description:** Main OCR Dashboard page

**Response:** HTML page

#### `GET /ocr/api/status`
**Description:** Check OCR system status

**Response:**
```json
{
  "success": true,
  "status": "ready",
  "ocr_initialized": true
}
```

#### `POST /ocr/api/process`
**Description:** Process uploaded image with OCR

**Request:** Multipart form data
- `image`: Image file (jpg, png, etc.)

**Response:**
```json
{
  "success": true,
  "original_image": "base64_encoded_image",
  "annotated_image": "base64_encoded_image",
  "full_text": "Extracted text...",
  "barcode_data": "Barcode information...",
  "statistics": {
    "text_regions_detected": 5,
    "barcodes_detected": 1,
    "corrections_made": 2
  },
  "image_type": "document",
  "features": {},
  "output_files": {}
}
```

---

## 🐛 Troubleshooting

### Common Issues & Solutions

#### ❌ Camera Not Working

**Symptoms:** "Camera not found" or black screen

**Solutions:**
```bash
# Check available cameras
ls /dev/video*

# Test camera with OpenCV
python3 -c "import cv2; cap = cv2.VideoCapture(0); print(cap.isOpened())"

# Check permissions (Linux)
sudo usermod -a -G video $USER
# Then logout and login

# For USB camera on Raspberry Pi
sudo modprobe bcm2835-v4l2
```

#### ❌ Phone Camera Not Connecting

**Symptoms:** "Failed to open stream" error

**Solutions:**
1. Verify phone and computer on same WiFi network
2. Check IP address in IP Webcam app (e.g., `192.168.0.101`)
3. Test connection:
   ```bash
   curl http://192.168.0.101:8080/video
   ```
4. Update camera URL in `backend/config.py`:
   ```python
   'camera_id': "http://192.168.0.101:8080/video"
   ```

#### ❌ OCR Not Extracting Values

**Symptoms:** "No value extracted" or incorrect extraction

**Solutions:**
1. **Check Lighting:** Ensure bright, even lighting
2. **Check Focus:** Camera should be in focus
3. **Check Distance:** Test 30-50cm from object
4. **Check Angle:** Camera perpendicular to text
5. **Increase Contrast:** Use white background for dark text
6. **Adjust Confidence Threshold:**
   ```yaml
   # In scripts/ocr_config.yaml
   text_processing:
     confidence_threshold: 0.50  # Lower = more detections
   ```

#### ❌ Port Already in Use

**Symptoms:** "Address already in use" error

**Solutions:**
```bash
# Kill existing process
lsof -ti:5000 | xargs kill -9

# Or change port in backend/main.py
app.run(host='0.0.0.0', port=5001, ...)
```

#### ❌ ImportError: Module Not Found

**Symptoms:** `ImportError: No module named 'paddleocr'`

**Solutions:**
```bash
# Activate virtual environment
source venv/bin/activate

# Reinstall missing package
pip install paddleocr

# Or reinstall all dependencies
pip install -r requirements.txt

# Verify installation
python3 -c "import paddleocr; print('OK')"
```

#### ❌ Slow Performance on Raspberry Pi

**Symptoms:** Lag between captures, slow OCR processing

**Solutions:**
1. **Reduce Resolution:**
   ```python
   # In backend/config.py
   'resolution': (640, 480),  # Instead of 1280x720
   'max_capture_size': 640,   # Instead of 1920
   ```

2. **Disable Rotation Detection:**
   ```yaml
   # In scripts/ocr_config.yaml
   ocr_engine:
     use_angle_cls: false  # Saves processing time
   ```

3. **Lower Frame Rate:**
   ```python
   # In backend/config.py
   'framerate': 5,  # Instead of 10
   ```

---

## 🎓 Best Practices

### For Operators

1. **Positioning:**
   - Keep camera 30-50cm from objects
   - Ensure perpendicular angle
   - Avoid shadows and glare

2. **Verification:**
   - Always cross-check displayed value
   - Use Rescan if any doubt
   - Don't rush through steps

3. **Maintenance:**
   - Clean camera lens daily
   - Check lighting conditions
   - Report any persistent errors

### For Administrators

1. **System Monitoring:**
   - Check logs regularly
   - Monitor capture success rate
   - Review OCR accuracy

2. **Performance Tuning:**
   - Adjust camera resolution based on hardware
   - Tune OCR confidence thresholds
   - Optimize frame rate for your setup

3. **Backup & Maintenance:**
   - Regular backups of configuration files
   - Monitor disk space for captures
   - Update dependencies periodically

---

## 📝 License

This project is licensed under the MIT License.

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

## 📞 Support

For issues, questions, or contributions, please open an issue on the project repository.

---

**Built with ❤️ for Pharmaceutical Manufacturing Quality Control**
