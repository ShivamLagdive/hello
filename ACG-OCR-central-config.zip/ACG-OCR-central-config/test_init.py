#!/usr/bin/env python3
"""Test script to debug initialization hanging"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

print("Step 1: Importing modules...")
try:
    from backend.app import create_app
    from backend.config import get_camera_config
    print("✓ Imports successful")
except Exception as e:
    print(f"✗ Import failed: {e}")
    sys.exit(1)

print("\nStep 2: Getting camera config...")
try:
    camera_config = get_camera_config(PROJECT_ROOT)
    print("✓ Camera config loaded")
except Exception as e:
    print(f"✗ Config failed: {e}")
    sys.exit(1)

print("\nStep 3: Creating Flask app...")
print("  This will initialize all models and controllers...")
try:
    app = create_app(PROJECT_ROOT, camera_config)
    print("✓ Flask app created successfully!")
except Exception as e:
    print(f"✗ Flask app creation failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n✅ All initialization complete!")
