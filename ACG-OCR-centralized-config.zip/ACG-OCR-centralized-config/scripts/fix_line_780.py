#!/usr/bin/env python3
import re

file_path = 'ocr_text_processor.py'

with open(file_path, 'r') as f:
    content = f.read()

# Find and replace the problematic line
old_code = r"variant_config = self\.config\.get\('variants', \{\}\)\.get\(mode, \{\}\)"

new_code = """# ✅ FIXED: Safe config access
        try:
            variants_config = self.config.config.get('variants', {})
            variant_config = variants_config.get(mode, {})
        except (KeyError, TypeError, AttributeError):
            variant_config = {
                'enabled': ['original'],
                'weights': {'original': 1.0}
            }"""

content = re.sub(old_code, new_code, content)

with open(file_path, 'w') as f:
    f.write(content)

print("✅ Fixed line 780 in ocr_text_processor.py")