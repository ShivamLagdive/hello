"""
Webcam Capture Module - Works with ANY camera
Supports: Laptop webcam, USB camera, Phone camera (via IP Webcam app)
Save this as: scripts/camera_capture.py
"""

import cv2
import numpy as np
from pathlib import Path
import time
import logging
from datetime import datetime
from threading import Thread, Event
import queue

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MotionDetector:
    """Detects motion/object changes using background subtraction"""
    
    def __init__(self, config=None):
        self.config = config or {}
        self.min_area = self.config.get('min_detection_area', 5000)
        self.threshold = self.config.get('motion_threshold', 25)
        self.blur_size = self.config.get('blur_size', 21)
        self.stable_frames = self.config.get('stable_frames', 5)
        self.background = None
        self.stable_count = 0
        self.last_capture_time = 0
        self.cooldown = self.config.get('capture_cooldown', 3)
        
    def detect_motion(self, frame):
        """Analyze frame for motion"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (self.blur_size, self.blur_size), 0)
        
        if self.background is None:
            self.background = gray
            return False, frame, []
        
        frame_delta = cv2.absdiff(self.background, gray)
        thresh = cv2.threshold(frame_delta, self.threshold, 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)
        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        has_significant_motion = any(cv2.contourArea(c) > self.min_area for c in contours)
        self.background = cv2.addWeighted(self.background, 0.95, gray, 0.05, 0)
        
        return has_significant_motion, thresh, contours
    
    def should_capture(self, has_motion):
        """Decide if we should capture"""
        current_time = time.time()
        if current_time - self.last_capture_time < self.cooldown:
            return False
        
        if has_motion:
            self.stable_count += 1
        else:
            self.stable_count = 0
        
        if self.stable_count >= self.stable_frames:
            self.last_capture_time = current_time
            self.stable_count = 0
            return True
        return False
    
    def reset(self):
        self.background = None
        self.stable_count = 0


class WebcamCapture:
    """Universal camera interface"""
    
    def __init__(self, config=None, ocr_system=None):
        self.config = config or {}
        self.ocr_system = ocr_system
        
        self.camera_id = self.config.get('camera_id', 0)
        self.resolution = self.config.get('resolution', (1280, 720))
        self.framerate = self.config.get('framerate', 10)
        
        self.auto_capture_enabled = False
        self.motion_detector = MotionDetector(self.config.get('motion_detection', {}))
        
        self.capture_dir = Path(self.config.get('capture_dir', 'camera_captures'))
        self.capture_dir.mkdir(parents=True, exist_ok=True)  # Create parent directories if needed
        
        self.processing_queue = queue.Queue(maxsize=5)
        self.processing_thread = None
        self.stop_event = Event()
        
        self.camera = None
        self._init_camera()
        
    def _init_camera(self):
        """Initialize camera with improved network camera support"""
        logger.info(f"🎥 Initializing camera: {self.camera_id}...")
        
        # For network cameras (URL strings), try multiple methods
        if isinstance(self.camera_id, str) and self.camera_id.startswith('http'):
            self.camera = self._init_network_camera(self.camera_id)
        else:
            # For USB cameras (integers like 0, 1), use default
            self.camera = cv2.VideoCapture(self.camera_id)
            if not self.camera.isOpened():
                raise RuntimeError(f"❌ Could not open camera {self.camera_id}")
        
        # Set timeout and buffer settings for network cameras
        if isinstance(self.camera_id, str):
            self.camera.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000)  # 5 second timeout
            self.camera.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
            # Minimal buffer to reduce lag - flush old frames immediately
            self.camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # Minimal buffer for network streams
            # Try to set low latency mode if supported
            try:
                self.camera.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))
            except Exception:
                pass  # Not critical if it fails
        
        # Set resolution
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, self.resolution[0])
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, self.resolution[1])
        self.camera.set(cv2.CAP_PROP_FPS, self.framerate)
        
        # Give camera time to initialize
        time.sleep(2)
        
        # Test capture with retries
        ret, frame = None, None
        for attempt in range(3):
            ret, frame = self.camera.read()
            if ret and frame is not None:
                break
            logger.warning(f"⚠️ Capture attempt {attempt + 1}/3 failed, retrying...")
            time.sleep(1)
        
        if not ret or frame is None:
            error_msg = (
                f"❌ Camera test capture failed after 3 attempts.\n"
                f"   Camera ID: {self.camera_id}\n"
                f"   Troubleshooting:\n"
            )
            if isinstance(self.camera_id, str):
                error_msg += (
                    f"   - Verify the IP address is correct\n"
                    f"   - Check if camera is on the same network\n"
                    f"   - Try accessing the URL in a browser: {self.camera_id}\n"
                    f"   - For IP Webcam, try: {self.camera_id.replace('/video', '/shot.jpg')}\n"
                    f"   - Check firewall settings\n"
                )
            else:
                error_msg += (
                    f"   - Check if camera is connected\n"
                    f"   - Try a different camera ID (0, 1, 2, etc.)\n"
                    f"   - Check camera permissions\n"
                )
            raise RuntimeError(error_msg)
        
        actual_size = frame.shape[:2]
        logger.info(f"✅ Camera ready: {actual_size[1]}x{actual_size[0]}")
    
    def _init_network_camera(self, url: str):
        """Initialize network camera with multiple backend attempts"""
        backends_to_try = [
            (cv2.CAP_FFMPEG, "FFMPEG"),
            (cv2.CAP_GSTREAMER, "GStreamer"),
            (cv2.CAP_ANY, "Any"),
        ]
        
        # Also try alternative URL formats for IP Webcam
        url_variants = [url]
        if '/video' in url:
            # Try /shot.jpg endpoint (single frame, more reliable)
            url_variants.append(url.replace('/video', '/shot.jpg'))
        elif '/shot.jpg' in url:
            # Try /video endpoint (stream)
            url_variants.append(url.replace('/shot.jpg', '/video'))
        
        for url_variant in url_variants:
            logger.info(f"   Trying URL: {url_variant}")
            
            for backend_id, backend_name in backends_to_try:
                try:
                    logger.info(f"   Attempting with {backend_name} backend...")
                    camera = cv2.VideoCapture(url_variant, backend_id)
                    
                    if camera.isOpened():
                        # Quick test read
                        camera.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000)
                        ret, test_frame = camera.read()
                        if ret and test_frame is not None:
                            logger.info(f"   ✅ Success with {backend_name} backend!")
                            return camera
                        else:
                            camera.release()
                            logger.warning(f"   ⚠️ {backend_name} opened but couldn't read frame")
                    else:
                        camera.release()
                        logger.warning(f"   ⚠️ {backend_name} backend failed to open")
                        
                except Exception as e:
                    logger.warning(f"   ⚠️ {backend_name} backend error: {e}")
                    continue
        
        # If all backends failed, try one more time with default
        logger.info("   Trying default backend as last resort...")
        camera = cv2.VideoCapture(url)
        if camera.isOpened():
            return camera
        
        raise RuntimeError(
            f"❌ Could not connect to network camera: {url}\n"
            f"   Tried {len(url_variants)} URL variant(s) and {len(backends_to_try)} backend(s)\n"
            f"   Please verify:\n"
            f"   1. IP address is correct\n"
            f"   2. Camera is on the same network\n"
            f"   3. URL is accessible (try in browser)\n"
            f"   4. Firewall is not blocking the connection"
        )
    
    def capture_frame(self):
        """
        Capture a single frame with retry logic for network cameras.
        Flushes old frames from buffer to get the latest frame and reduce lag.
        MJPEG boundary warnings from FFMPEG are common with network streams
        and don't necessarily indicate failure - we retry to get a valid frame.
        """
        max_retries = 2  # Reduced retries for lower latency
        retry_delay = 0.05  # Shorter delay (50ms) for faster recovery
        
        # For network cameras, flush buffer to get latest frame (reduce lag)
        if isinstance(self.camera_id, str):
            # Read and discard old frames to get the latest one
            for _ in range(2):  # Flush up to 2 old frames
                try:
                    self.camera.grab()  # Grab without decoding (fast)
                except Exception:
                    break
        
        for attempt in range(max_retries):
            try:
                ret, frame = self.camera.read()
                if ret and frame is not None and frame.size > 0:
                    return frame
                # If read failed, try again after a short delay
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
            except Exception as e:
                # MJPEG parsing errors are common with network streams
                # The FFMPEG warnings appear in stderr but don't always mean failure
                error_str = str(e).lower()
                if 'boundary' in error_str or 'mpjpeg' in error_str:
                    # Just retry - these are often transient
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
                        continue
                else:
                    # Other errors should be logged
                    logger.warning(f"Frame capture attempt {attempt + 1} failed: {e}")
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
        
        # All retries failed
        # Note: MJPEG boundary warnings in terminal are from FFMPEG and are often harmless
        # The actual failure is when we can't get a valid frame after retries
        return None
    
    def save_capture(self, frame, prefix="capture"):
        """Save frame to disk"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        filename = f"{prefix}_{timestamp}.jpg"
        filepath = self.capture_dir / filename
        
        max_size = self.config.get('max_capture_size', 1280)
        h, w = frame.shape[:2]
        if max(h, w) > max_size:
            scale = max_size / max(h, w)
            frame = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        
        cv2.imwrite(str(filepath), frame)
        logger.info(f"💾 Saved: {filepath}")
        return filepath
    
    def start_auto_capture(self):
        """Start auto-capture mode"""
        if self.auto_capture_enabled:
            logger.warning("Auto-capture already running")
            return
        
        self.auto_capture_enabled = True
        self.stop_event.clear()
        
        if self.ocr_system:
            self.processing_thread = Thread(target=self._process_queue, daemon=True)
            self.processing_thread.start()
        
        logger.info("🚀 Auto-capture STARTED")
        logger.info("Place objects in front of camera to trigger capture\n")
        
        try:
            while self.auto_capture_enabled and not self.stop_event.is_set():
                frame = self.capture_frame()
                if frame is None:
                    continue
                
                has_motion, motion_frame, contours = self.motion_detector.detect_motion(frame)
                
                display_frame = frame.copy()
                for contour in contours:
                    if cv2.contourArea(contour) > self.motion_detector.min_area:
                        (x, y, w, h) = cv2.boundingRect(contour)
                        cv2.rectangle(display_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                        cv2.putText(display_frame, "MOTION", (x, y - 10),
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                
                status = "DETECTING..." if has_motion else "MONITORING"
                cv2.putText(display_frame, status, (10, 30),
                          cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                cv2.imshow('Auto-Capture (Press Q to stop)', display_frame)
                
                if self.motion_detector.should_capture(has_motion):
                    logger.info("📸 TRIGGER: Object detected!")
                    
                    white = np.ones_like(frame) * 255
                    cv2.imshow('Auto-Capture (Press Q to stop)', white)
                    cv2.waitKey(100)
                    
                    filepath = self.save_capture(frame, prefix="auto_capture")
                    
                    if self.ocr_system:
                        try:
                            self.processing_queue.put_nowait(str(filepath))
                            logger.info("➕ Queued for OCR processing")
                        except queue.Full:
                            logger.warning("⚠️ Processing queue full, skipping")
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                time.sleep(1.0 / self.framerate)
                
        except KeyboardInterrupt:
            logger.info("\n⚠️ Auto-capture interrupted")
        finally:
            self.stop_auto_capture()
            cv2.destroyAllWindows()
    
    def stop_auto_capture(self):
        """Stop auto-capture"""
        self.auto_capture_enabled = False
        self.stop_event.set()
        
        if self.processing_thread and self.processing_thread.is_alive():
            self.processing_thread.join(timeout=5)
        
        logger.info("🛑 Auto-capture STOPPED")
    
    def _process_queue(self):
        """Background OCR processing"""
        logger.info("🔄 OCR processing thread started")
        
        while not self.stop_event.is_set():
            try:
                image_path = self.processing_queue.get(timeout=1)
                logger.info(f"🤖 Processing: {image_path}")
                
                result = self.ocr_system.process_image(image_path, save_outputs=True)
                
                if result['success']:
                    stats = result.get('statistics', {})
                    logger.info(f"✅ OCR Complete: {stats.get('text_regions_detected', 0)} text regions, "
                              f"{stats.get('barcodes_detected', 0)} barcodes")
                    
                    text = result.get('full_text', '')
                    if text:
                        preview = text[:200].replace('\n', ' ')
                        logger.info(f"📄 Text: {preview}...")
                else:
                    logger.error(f"❌ OCR failed: {result.get('error')}")
                
                self.processing_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"❌ Processing error: {e}")
    
    def manual_capture(self):
        """Manual capture with countdown"""
        logger.info("📸 Manual capture...")
        logger.info("Position your object... capturing in 3 seconds")
        
        for i in range(3, 0, -1):
            frame = self.capture_frame()
            if frame is not None:
                cv2.putText(frame, str(i), (frame.shape[1]//2 - 50, frame.shape[0]//2),
                          cv2.FONT_HERSHEY_SIMPLEX, 5, (0, 255, 0), 10)
                cv2.imshow('Manual Capture', frame)
                cv2.waitKey(1000)
        
        frame = self.capture_frame()
        cv2.destroyAllWindows()
        
        if frame is None:
            return {"success": False, "error": "Failed to capture frame"}
        
        filepath = self.save_capture(frame, prefix="manual_capture")
        
        if self.ocr_system:
            logger.info("🤖 Running OCR...")
            result = self.ocr_system.process_image(str(filepath), save_outputs=True)
            return result
        
        return {"success": True, "image_path": str(filepath)}
    
    def preview_stream(self, duration=10):
        """Show live preview"""
        logger.info(f"👁️ Preview for {duration} seconds...")
        logger.info("Press Q to exit early\n")
        
        start_time = time.time()
        
        while time.time() - start_time < duration:
            frame = self.capture_frame()
            if frame is None:
                continue
            
            timestamp = datetime.now().strftime("%H:%M:%S")
            elapsed = int(time.time() - start_time)
            remaining = duration - elapsed
            
            cv2.putText(frame, f"Time: {timestamp}", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, f"Remaining: {remaining}s", (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, "Press Q to exit", (10, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            cv2.imshow('Camera Preview', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
        cv2.destroyAllWindows()
    
    def list_cameras(self):
        """List available cameras"""
        logger.info("🔍 Scanning for cameras...")
        available = []
        
        for i in range(5):
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                ret, _ = cap.read()
                if ret:
                    available.append(i)
                    logger.info(f"✅ Camera {i} available")
                cap.release()
        
        if not available:
            logger.warning("❌ No cameras found!")
        
        return available
    
    def cleanup(self):
        """Release resources"""
        if self.camera:
            self.camera.release()
        cv2.destroyAllWindows()
        logger.info("🔌 Camera released")