"""
ULTIMATE BARCODE SCANNER
Combines all successful strategies from recovery attempts:
- Dual Engine (ZXing + Pyzbar)
- Multi-angle rotation sweep
- Image tiling for busy backgrounds
- ROI extraction (center strips)
- Advanced preprocessing (CLAHE, sharpening, morphology)
- Multi-scale detection
"""
import cv2
import numpy as np
import zxingcpp
from pyzbar.pyzbar import decode
from pathlib import Path
import json
import logging

logger = logging.getLogger(__name__)

class BarcodeProcessor:  # <--- FIXED: Class name must match main import
    """
    Handles all Barcode and QR code operations.
    Replaces the standard processor with 'Ultimate Scanner' logic.
    """
    
    def __init__(self, config): # <--- FIXED: Must accept 'config'
        self.config = config
        self.strategies_tried = []
        self.success_strategy = None
    
    def detect_and_extract(self, image_path, image_name):
        """
        Main pipeline: Tries strategies in order of speed/success rate.
        Returns the first set of barcodes found to save time.
        """
        self.strategies_tried = []
        self.success_strategy = None
        
        try:
            # 1. Load the image using the path provided by main system
            original = cv2.imread(image_path)
            if original is None:
                logger.error(f"❌ Could not read image: {image_path}")
                return {"barcodes": [], "count": 0}

            # 2. Setup for processing
            gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape

            # ========================================
            # PHASE 1: FAST CHECKS (Standard)
            # ========================================
            
            # Original
            barcodes = self._scan_with_dual_engine(original, "Original")
            if barcodes: return self._format_result(barcodes)
            
            # Grayscale
            barcodes = self._scan_with_dual_engine(gray, "Grayscale")
            if barcodes: return self._format_result(barcodes)
            
            # Upscaled (2x)
            upscaled = cv2.resize(original, None, fx=2.0, fy=2.0)
            barcodes = self._scan_with_dual_engine(upscaled, "Upscaled_2x")
            if barcodes: return self._format_result(barcodes) 
            
            # Inverted
            inverted = cv2.bitwise_not(gray)
            barcodes = self._scan_with_dual_engine(inverted, "Inverted")
            if barcodes: return self._format_result(barcodes)

            # ========================================
            # PHASE 2: ROTATION SWEEP
            # ========================================
            
            rotations = [
                (cv2.rotate(gray, cv2.ROTATE_90_CLOCKWISE), "Rotate_90", 90),
                (cv2.rotate(gray, cv2.ROTATE_180), "Rotate_180", 180),
                (cv2.rotate(gray, cv2.ROTATE_90_COUNTERCLOCKWISE), "Rotate_270", -90)
            ]
            
            for img_rot, name, angle in rotations:
                barcodes = self._scan_with_dual_engine(img_rot, name, angle, h, w)
                if barcodes: return self._format_result(barcodes)

            # ========================================
            # PHASE 3: CONTRAST & ENHANCEMENT
            # ========================================
            
            # CLAHE
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            enhanced = clahe.apply(gray)
            barcodes = self._scan_with_dual_engine(enhanced, "CLAHE_Standard")
            if barcodes: return self._format_result(barcodes)
            
            # Adaptive Threshold
            adaptive = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                cv2.THRESH_BINARY, 11, 2
            )
            barcodes = self._scan_with_dual_engine(adaptive, "Adaptive_Thresh")
            if barcodes: return self._format_result(barcodes)

            # ========================================
            # PHASE 4: TILING (Busy Backgrounds) - DISABLED
            # ========================================
            # DISABLED: Uncomment to enable tiling-based detection
            # # 2x2 Grid
            # for tile, name in self._get_tiles(gray, 2, 2):
            #     barcodes = self._scan_with_dual_engine(tile, name)
            #     if barcodes: return self._format_result(barcodes)
            
            # ========================================
            # PHASE 5: ROI (Strips) - DISABLED
            # ========================================
            # DISABLED: Uncomment to enable ROI-based detection
            # # Center Horizontal
            # h_start, h_end = int(h * 0.35), int(h * 0.65)
            # center_h = gray[h_start:h_end, :]
            # barcodes = self._scan_with_dual_engine(center_h, "Center_Strip_H")
            # if barcodes: return self._format_result(barcodes)

            # ========================================
            # PHASE 6: ADVANCED RECOVERY - DISABLED
            # ========================================
            # DISABLED: Uncomment to enable advanced recovery techniques

            # # Sharpening
            # kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            # sharpened = cv2.filter2D(gray, -1, kernel)
            # barcodes = self._scan_with_dual_engine(sharpened, "Sharpened")
            # if barcodes: return self._format_result(barcodes)
            
            # # Erosion
            # kernel_erosion = np.ones((2,2), np.uint8)
            # erosion = cv2.erode(gray, kernel_erosion, iterations=1)
            # barcodes = self._scan_with_dual_engine(erosion, "Erosion")
            # if barcodes: return self._format_result(barcodes)

            # ========================================
            # PHASE 7: NUCLEAR OPTIONS - DISABLED
            # ========================================
            # DISABLED: Uncomment to enable nuclear/experimental options

            # # Glare Inpainting
            # _, mask = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)
            # inpainted = cv2.inpaint(gray, mask, 3, cv2.INPAINT_TELEA)
            # barcodes = self._scan_with_dual_engine(inpainted, "Glare_Inpainting")
            # if barcodes: return self._format_result(barcodes)

            # # Laser Slice (Check only center/top/bottom slices for speed)
            # slice_height = max(1, h // 50)
            # for i in range(0, h, slice_height * 5): 
            #     img_slice = gray[i : i + slice_height, :]
            #     if img_slice.shape[0] > 0:
            #         stretched = cv2.resize(img_slice, (w, 100)) 
            #         barcodes = self._scan_with_dual_engine(stretched, f"Laser_Slice_{i}")
            #         if barcodes: return self._format_result(barcodes)

            # If we reach here, nothing was found
            logger.info("   ℹ️ No barcodes detected after phases 1-3 (phases 4-7 are disabled)")
            return {"barcodes": [], "count": 0}

        except Exception as e:
            logger.error(f"❌ Barcode detection pipeline error: {e}")
            return {"barcodes": [], "count": 0}

    def _scan_with_dual_engine(self, image, strategy_name, angle=0, orig_h=0, orig_w=0):
        """Tries both ZXing and Pyzbar on the image."""
        if image is None or image.size == 0: return []
        
        found_barcodes = []
        seen_data = set()

        # 1. ZXing-CPP (Modern)
        try:
            results = zxingcpp.read_barcodes(image)
            for res in results:
                if res.text not in seen_data:
                    # Basic coordinates handling
                    if angle != 0:
                        x, y, w, h = 10, 10, 100, 50 # Dummy box for rotated finds
                    else:
                        x, y, w, h = 10, 10, 100, 50 
                    
                    bc = {
                        "index": len(found_barcodes) + 1,
                        "type": str(res.format),
                        "data": res.text,
                        "rect": (x, y, w, h),
                        "polygon": [], 
                        "strategy": f"{strategy_name} (ZXing)"
                    }
                    found_barcodes.append(bc)
                    seen_data.add(res.text)
                    logger.info(f"   📱 Found {res.format}: {res.text} via {strategy_name}")
        except Exception: pass
        
        if found_barcodes: return found_barcodes

        # 2. Pyzbar (Legacy)
        try:
            decoded = decode(image)
            for obj in decoded:
                data = obj.data.decode('utf-8')
                if data not in seen_data:
                    
                    x, y, w, h = obj.rect
                    
                    # If rotated, map back (Simple estimation)
                    if angle != 0 and orig_h > 0 and orig_w > 0:
                        cx = x + w//2
                        cy = y + h//2
                        ncx, ncy = self._unrotate_point((cx, cy), angle, orig_h, orig_w)
                        if abs(angle) == 90: w, h = h, w
                        x, y = ncx - w//2, ncy - h//2
                    
                    bc = {
                        "index": len(found_barcodes) + 1,
                        "type": obj.type,
                        "data": data,
                        "rect": (int(x), int(y), int(w), int(h)),
                        "polygon": [],
                        "strategy": f"{strategy_name} (Pyzbar)"
                    }
                    found_barcodes.append(bc)
                    seen_data.add(data)
                    logger.info(f"   📱 Found {obj.type}: {data} via {strategy_name}")
        except Exception: pass
            
        return found_barcodes

    def _get_tiles(self, image, rows, cols):
        """Divides image into grid tiles"""
        tiles = []
        h, w = image.shape[:2]
        h_step = h // rows
        w_step = w // cols
        for r in range(rows):
            for c in range(cols):
                y1 = r * h_step; y2 = min(h, (r + 1) * h_step)
                x1 = c * w_step; x2 = min(w, (c + 1) * w_step)
                tile = image[y1:y2, x1:x2]
                if tile.size > 0:
                    tiles.append((tile, f"Tile_{rows}x{cols}_R{r}C{c}"))
        return tiles

    def _unrotate_point(self, point, angle, orig_h, orig_w):
        """Map points back to original image space"""
        x, y = point
        if angle == 90:
            return y, orig_h - 1 - x
        elif angle == -90:
            return orig_w - 1 - y, x
        elif angle == 180:
            return orig_w - 1 - x, orig_h - 1 - y
        return x, y

    def _format_result(self, barcodes):
        """Helper to format return for main system"""
        return {"barcodes": barcodes, "count": len(barcodes)}

    # --- MISSING FUNCTIONS YOU MUST KEEP ---
    def save_barcode_metadata(self, barcodes, image_name, timestamp):
        """Save barcode details to JSON (Required by Main System)"""
        try:
            output_dir = Path(self.config.get('barcode', 'output_dir'))
            output_dir.mkdir(parents=True, exist_ok=True)
            json_path = output_dir / f"{image_name}_{timestamp}_barcodes.json"
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(barcodes, f, indent=2)
            return str(json_path)
        except Exception as e:
            return None

    def draw_barcodes_on_image(self, img, barcodes, color=(0, 255, 0), thickness=2):
        """Draw green boxes around detected barcodes (Required by Main System)"""
        for bc in barcodes:
            x, y, w, h = bc['rect']
            if x < 0: x = 0
            if y < 0: y = 0
            cv2.rectangle(img, (x, y), (x + w, y + h), color, thickness)
            
            label = f"{bc.get('type', 'CODE')}: {bc.get('data', '')[:10]}..."
            cv2.putText(img, label, (x, max(15, y - 10)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        return img
