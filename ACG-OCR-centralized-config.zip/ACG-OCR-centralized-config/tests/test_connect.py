import cv2
import time

# 1. The exact URL you verified with curl
url = "http://192.168.0.101:8080/video"

print(f"🔌 Connecting to: {url}")
print("⏳ Please wait a moment...")

# 2. IMPORTANT FIX: We add 'cv2.CAP_FFMPEG' to force network mode
cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)

if not cap.isOpened():
    print("❌ Failed to open stream!")
else:
    print("✅ SUCCESS! Camera Connected.")
    
    # Try to read 10 frames to make sure it's stable
    print("🎥 Reading frames...")
    for i in range(10):
        ret, frame = cap.read()
        if not ret:
            print(f"   ⚠️ Frame {i} failed.")
            break
        print(f"   ✅ Frame {i} received: {frame.shape}")
        time.sleep(0.1)

    print("\nTest complete. You can now use this URL in your main app.")

cap.release()
