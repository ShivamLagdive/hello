from picamera2 import Picamera2
import cv2
import time
from datetime import datetime

print("Starting Picamera2...")
picam2 = Picamera2()

# Preview configuration (fast, good for live)
config = picam2.create_preview_configuration(main={"size": (1280, 720), "format": "RGB888"})
picam2.configure(config)

picam2.start()
time.sleep(1)

print("✅ CSI camera streaming. Press Q to quit, S to save frame.")

while True:
    frame = picam2.capture_array()  # RGB array

    # OpenCV expects BGR for display
    bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

    cv2.putText(bgr, "Q=Quit | S=Save", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    cv2.imshow("CSI Camera (Picamera2)", bgr)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    if key == ord("s"):
        fname = f"csi_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        cv2.imwrite(fname, bgr)
        print("Saved:", fname)

picam2.stop()
cv2.destroyAllWindows()
print("Done.")
