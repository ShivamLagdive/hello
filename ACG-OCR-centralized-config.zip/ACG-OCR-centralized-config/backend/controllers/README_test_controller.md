# Test Controller Documentation

## Overview

The `TestController` is a Flask controller that provides a manual testing interface for the OCR system. It allows developers and testers to upload individual images and test each of the three OCR phases (tag, weight, and box_label) independently. This is particularly useful for debugging, performance testing, and validating OCR accuracy.

**Location:** `backend/controllers/test_controller.py`  
**Template:** `backend/views/templates/test_upload.html`  
**Base URL:** `/test`

---

## Features

- ✅ **Individual Phase Testing**: Test each OCR phase (tag, weight, box_label) separately
- ✅ **Performance Metrics**: Measures and displays inference time for each phase
- ✅ **Image Validation**: Validates file type, size, and format before processing
- ✅ **Automatic Image Resizing**: Resizes images to optimal size before OCR processing

---

## API Endpoints

### 1. Get Test Page
**Endpoint:** `GET /test/`  
**Description:** Renders the test upload page with three phase cards.

**Response:**
- HTML page (`test_upload.html`)

---

### 2. Test Tag Phase
**Endpoint:** `POST /test/api/test_tag`  
**Description:** Process an uploaded image with the tag scan type.

**Request:**
- **Method:** POST
- **Content-Type:** `multipart/form-data`
- **Body:**
  ```
  image: <file> (required)
  ```

**Response:**
```json
{
  "success": true,
  "data": {
    "success": true,
    "scan_type": "tag",
    "extracted_value": "extracted tag value",
    "full_text": "full OCR text",
    "frame": "base64_encoded_image",
    "statistics": {
      "text_regions_detected": 5,
      "barcodes_detected": 1
    },
    "text_detections": [...],
    "output_files": {
      "visualization": "path/to/visualization.jpg",
      "text": "path/to/text.txt"
    },
    "inference_time_seconds": 2.345,
    "inference_time_ms": 2345.67
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Error message",
  "status_code": 400
}
```

---

### 3. Test Weight Phase
**Endpoint:** `POST /test/api/test_weight`  
**Description:** Process an uploaded image with the weight scan type.

**Request/Response:** Same format as `/test/api/test_tag`

---

### 4. Test Box Label Phase
**Endpoint:** `POST /test/api/test_box_label`  
**Description:** Process an uploaded image with the box_label scan type.

**Request/Response:** Same format as `/test/api/test_tag`

---

### 5. Test All Phases
**Endpoint:** `POST /test/api/test_all`  
**Description:** Process an uploaded image with all three scan types sequentially.

**Request:**
- **Method:** POST
- **Content-Type:** `multipart/form-data`
- **Body:**
  ```
  image: <file> (required)
  ```

**Response:**
```json
{
  "success": true,
  "data": {
    "success": true,
    "results": {
      "tag": {
        "success": true,
        "scan_type": "tag",
        "extracted_value": "...",
        "full_text": "...",
        "inference_time_seconds": 2.345,
        "inference_time_ms": 2345.67,
        ...
      },
      "weight": {
        "success": true,
        "scan_type": "weight",
        ...
      },
      "box_label": {
        "success": true,
        "scan_type": "box_label",
        ...
      }
    },
    "image_path": "path/to/uploaded/image.jpg"
  }
}
```

---

## Request Validation

The controller validates uploaded files based on the following criteria:

### File Type
- **Allowed Extensions:** Defined in `backend/config.py` (`ALLOWED_IMAGE_EXTENSIONS`)
- Typically: `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tiff`

### File Size
- **Maximum Size:** Defined in `backend/config.py` (`MAX_UPLOAD_SIZE`)
- Default: Typically 10MB

### Image Processing
- Images are automatically resized to `MAX_IMAGE_SIZE` (default: 960px) before processing
- Images are saved to `data/test_uploads/` with timestamped filenames
- Temporary files are automatically cleaned up after processing

---

## Response Fields

### Success Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `success` | boolean | Whether the operation succeeded |
| `scan_type` | string | The scan type used (`tag`, `weight`, or `box_label`) |
| `extracted_value` | string | The extracted value based on scan type |
| `full_text` | string | Complete OCR text from the image |
| `frame` | string | Base64-encoded image for display |
| `statistics` | object | OCR statistics (text regions, barcodes, etc.) |
| `text_detections` | array | Detailed text detection results |
| `output_files` | object | Paths to saved output files (visualization, text) |
| `inference_time_seconds` | float | Inference time in seconds (3 decimal places) |
| `inference_time_ms` | float | Inference time in milliseconds (2 decimal places) |

### Statistics Object

```json
{
  "text_regions_detected": 5,
  "barcodes_detected": 1,
  "confidence_avg": 0.95,
  "confidence_min": 0.87,
  "confidence_max": 0.99
}
```

---

## Usage Examples

### Using cURL

#### Test Tag Phase
```bash
curl -X POST http://localhost:5000/test/api/test_tag \
  -F "image=@/path/to/image.jpg"
```

#### Test Weight Phase
```bash
curl -X POST http://localhost:5000/test/api/test_weight \
  -F "image=@/path/to/image.jpg"
```

#### Test Box Label Phase
```bash
curl -X POST http://localhost:5000/test/api/test_box_label \
  -F "image=@/path/to/image.jpg"
```

#### Test All Phases
```bash
curl -X POST http://localhost:5000/test/api/test_all \
  -F "image=@/path/to/image.jpg"
```

### Using Python Requests

```python
import requests

# Test tag phase
with open('test_image.jpg', 'rb') as f:
    response = requests.post(
        'http://localhost:5000/test/api/test_tag',
        files={'image': f}
    )
    result = response.json()
    print(f"Extracted value: {result['data']['extracted_value']}")
    print(f"Inference time: {result['data']['inference_time_ms']}ms")
```

### Using JavaScript/Fetch

```javascript
const formData = new FormData();
formData.append('image', fileInput.files[0]);

const response = await fetch('/test/api/test_tag', {
    method: 'POST',
    body: formData
});

const result = await response.json();
console.log('Inference time:', result.data.inference_time_ms, 'ms');
console.log('Extracted value:', result.data.extracted_value);
```

---

## Web Interface

### Access
Navigate to: `http://localhost:5000/test`

---


## Architecture

### Class Structure

```python
TestController(BaseController, SingletonMeta)
├── __init__(project_root)
├── _register_routes()
├── index()                          # GET /test/
├── test_tag()                       # POST /test/api/test_tag
├── test_weight()                    # POST /test/api/test_weight
├── test_box_label()                 # POST /test/api/test_box_label
├── test_all_phases()                # POST /test/api/test_all
├── _test_single_phase(scan_type)    # Internal helper
├── _process_with_scan_type()        # Core processing logic
├── _allowed_file(filename)          # File validation
└── _save_uploaded_file(file)        # File saving
```

### Dependencies

- **Flask**: Web framework
- **OpenCV (cv2)**: Image processing
- **OCRModel**: OCR system integration
- **ValueExtractor**: Value extraction from OCR text
- **Image Utils**: Image resizing and encoding
- **Response Helpers**: Standardized API responses

### File Flow

1. **Upload**: Image uploaded via HTTP POST
2. **Validation**: File type and size validated
3. **Save**: Image saved to `data/test_uploads/` with timestamp
4. **Resize**: Image resized to optimal size (MAX_IMAGE_SIZE)
5. **Process**: OCR processing with specified scan type
6. **Extract**: Value extraction from OCR text
7. **Encode**: Image encoded to base64 for display
8. **Return**: Results returned as JSON
9. **Cleanup**: Temporary file deleted

---


## Performance Considerations

### Inference Time Measurement

The controller measures inference time using `time.perf_counter()` for high precision:
- **Start**: Before calling `ocr_model.process_image()`
- **End**: After OCR processing completes
- **Excludes**: Image loading, resizing, value extraction, encoding



### Resource Management

- Temporary files are automatically cleaned up after processing
- Uses singleton pattern to share OCR model instance
- Thread-safe operations via Flask's request handling

---

### Error Response Format

```json
{
  "success": false,
  "error": "Error message",
  "status_code": 400
}
```


### Access from Main App

The test interface is accessible at:
- **Web UI**: `http://localhost:5000/test`
- **API Base**: `http://localhost:5000/test/api/`

---

