"""
Test Controller - Manual photo upload testing for all 3 phases
Allows testing a single image with tag, weight, and box_label scan types
"""
from flask import render_template, request
from pathlib import Path
import cv2
import numpy as np
from typing import Dict, Tuple
import logging
import os
import time
from datetime import datetime

from backend.controllers.base_controller import BaseController
from backend.core.singleton import SingletonMeta
from backend.models.ocr_model import OCRModel
from backend.utils.image_utils import resize_image, encode_frame_to_base64
from backend.utils.validators import ValueExtractor
from backend.utils.response_helpers import success_response, error_response, handle_exception
from backend.config import (
    MAX_IMAGE_SIZE, ALLOWED_IMAGE_EXTENSIONS, MAX_UPLOAD_SIZE, ERROR_MESSAGES
)

logger = logging.getLogger(__name__)


class TestController(BaseController, metaclass=SingletonMeta):
    """Controller for manual photo testing - Singleton"""
    
    _initialized = False
    
    def __init__(self, project_root: Path = None):
        """Initialize Test Controller"""
        if self._initialized:
            return
        
        if project_root is None:
            raise ValueError("project_root is required for first initialization")
        
        super().__init__(project_root, 'test', '/test')
        
        # Get singleton instances
        self.ocr_model = OCRModel()
        
        self._register_routes()
        self._initialized = True
    
    def _register_routes(self):
        """Register all routes"""
        routes = [
            ('/', 'GET', self.index),
            ('/api/test_all', 'POST', self.test_all_phases),
            ('/api/test_tag', 'POST', self.test_tag),
            ('/api/test_weight', 'POST', self.test_weight),
            ('/api/test_box_label', 'POST', self.test_box_label),
        ]
        
        for path, methods, handler in routes:
            self.blueprint.route(path, methods=[methods])(handler)
    
    def index(self):
        """Render test upload page"""
        try:
            return render_template('test_upload.html')
        except Exception as e:
            logger.error(f"Error rendering test page: {e}", exc_info=True)
            return render_template('test_upload.html')
    
    def test_all_phases(self) -> Tuple:
        """Test uploaded image with all 3 scan types (tag, weight, box_label)"""
        try:
            # Validate file upload
            if 'image' not in request.files:
                return error_response('No image provided', status_code=400)
            
            file = request.files['image']
            if file.filename == '':
                return error_response('No file selected', status_code=400)
            
            # Validate file extension
            if not self._allowed_file(file.filename):
                return error_response(
                    f"{ERROR_MESSAGES['invalid_file_type']}. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}",
                    status_code=400
                )
            
            # Validate file size
            file.seek(0, os.SEEK_END)
            file_size = file.tell()
            file.seek(0)
            
            if file_size > MAX_UPLOAD_SIZE:
                return error_response(ERROR_MESSAGES['file_too_large'], status_code=400)
            
            # Save uploaded file
            filepath = self._save_uploaded_file(file)
            
            try:
                # Test with all 3 scan types
                results = {}
                scan_types = ['tag', 'weight', 'box_label']
                
                for scan_type in scan_types:
                    logger.info(f"🧪 Testing {scan_type} phase...")
                    result = self._process_with_scan_type(filepath, scan_type)
                    results[scan_type] = result
                
                return success_response({
                    'success': True,
                    'results': results,
                    'image_path': str(filepath)
                })
            finally:
                # Cleanup temp file
                try:
                    os.remove(filepath)
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp file: {e}")
            
        except ValueError as e:
            return error_response(str(e), status_code=400)
        except Exception as e:
            return handle_exception(e, ERROR_MESSAGES['processing_failed'])
    
    def test_tag(self) -> Tuple:
        """Test uploaded image with tag scan type"""
        return self._test_single_phase('tag')
    
    def test_weight(self) -> Tuple:
        """Test uploaded image with weight scan type"""
        return self._test_single_phase('weight')
    
    def test_box_label(self) -> Tuple:
        """Test uploaded image with box_label scan type"""
        return self._test_single_phase('box_label')
    
    def _test_single_phase(self, scan_type: str) -> Tuple:
        """Test uploaded image with a single scan type"""
        try:
            # Validate file upload
            if 'image' not in request.files:
                return error_response('No image provided', status_code=400)
            
            file = request.files['image']
            if file.filename == '':
                return error_response('No file selected', status_code=400)
            
            # Validate file extension
            if not self._allowed_file(file.filename):
                return error_response(
                    f"{ERROR_MESSAGES['invalid_file_type']}. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}",
                    status_code=400
                )
            
            # Validate file size
            file.seek(0, os.SEEK_END)
            file_size = file.tell()
            file.seek(0)
            
            if file_size > MAX_UPLOAD_SIZE:
                return error_response(ERROR_MESSAGES['file_too_large'], status_code=400)
            
            # Save uploaded file
            filepath = self._save_uploaded_file(file)
            
            try:
                # Process with the specified scan type
                logger.info(f"🧪 Testing {scan_type} phase...")
                result = self._process_with_scan_type(filepath, scan_type)
                
                if result.get('success'):
                    return success_response(result)
                else:
                    return error_response(
                        result.get('error', ERROR_MESSAGES['processing_failed']),
                        status_code=500
                    )
            finally:
                # Cleanup temp file
                try:
                    os.remove(filepath)
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp file: {e}")
            
        except ValueError as e:
            return error_response(str(e), status_code=400)
        except Exception as e:
            return handle_exception(e, ERROR_MESSAGES['processing_failed'])
    
    def _allowed_file(self, filename: str) -> bool:
        """Check if file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS
    
    def _save_uploaded_file(self, file) -> Path:
        """Save uploaded file to temporary directory"""
        temp_dir = self.project_root / 'data' / 'test_uploads'
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Use timestamped filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'jpg'
        filename = f"test_{timestamp}.{ext}"
        filepath = temp_dir / filename
        
        file.save(str(filepath))
        logger.info(f"💾 Saved test file: {filepath}")
        return filepath
    
    def _process_with_scan_type(self, filepath: Path, scan_type: str) -> Dict:
        """Process image with specific scan type"""
        try:
            # Load and resize image
            img = cv2.imread(str(filepath))
            if img is None:
                raise ValueError(f"Could not read image: {filepath}")
            
            img = resize_image(img, max_size=MAX_IMAGE_SIZE)
            
            # Save resized image back to filepath before processing
            cv2.imwrite(str(filepath), img)
            
            # Measure inference time
            start_time = time.perf_counter()
            
            # Process with OCR using the specified scan type
            result = self.ocr_model.process_image(str(filepath), save_outputs=True, scan_type=scan_type)
            
            # Calculate inference time
            inference_time = time.perf_counter() - start_time
            logger.info(f"⏱️ {scan_type.upper()} inference completed in {inference_time:.3f}s ({inference_time*1000:.2f}ms)")
            
            if not result.get('success'):
                return {
                    'success': False,
                    'error': result.get('error', ERROR_MESSAGES['processing_failed']),
                    'scan_type': scan_type
                }
            
            # Extract value using the appropriate extractor
            full_text = result.get('full_text', '')
            extracted_value = ValueExtractor.extract(scan_type, full_text)
            
            # Encode image for display
            frame_data = encode_frame_to_base64(img, quality=85)
            
            return {
                'success': True,
                'scan_type': scan_type,
                'extracted_value': extracted_value,
                'full_text': full_text,
                'frame': frame_data,
                'statistics': result.get('statistics', {}),
                'text_detections': result.get('text_detections', []),
                'output_files': result.get('output_files', {}),
                'inference_time_seconds': round(inference_time, 3),
                'inference_time_ms': round(inference_time * 1000, 2)
            }
        except Exception as e:
            logger.error(f"Error processing {scan_type}: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'scan_type': scan_type
            }
