"""
OCR Dashboard Controller - Handles OCR dashboard routes
Refactored with singleton pattern, base controller, and best practices
"""
from flask import render_template, request
from pathlib import Path
from PIL import Image
import cv2
import io
import base64
from typing import Dict, Tuple
import logging
import os

from backend.controllers.base_controller import BaseController
from backend.core.singleton import SingletonMeta
from backend.models.ocr_model import OCRModel
from backend.utils.image_utils import resize_image
from backend.utils.response_helpers import success_response, error_response, handle_exception
from backend.config import (
    MAX_IMAGE_SIZE, ALLOWED_IMAGE_EXTENSIONS, MAX_UPLOAD_SIZE, ERROR_MESSAGES
)

logger = logging.getLogger(__name__)


class OCRController(BaseController, metaclass=SingletonMeta):
    """Controller for OCR Dashboard - Singleton"""
    
    _initialized = False
    
    def __init__(self, project_root: Path = None):
        """
        Initialize OCR Controller (singleton - only initialized once)
        
        Args:
            project_root: Project root directory (required on first call)
        """
        if self._initialized:
            return
        
        if project_root is None:
            raise ValueError("project_root is required for first initialization")
        
        super().__init__(project_root, 'ocr', '/ocr')
        
        # Get singleton instance
        self.ocr_model = OCRModel()
        
        self._register_routes()
        self._initialized = True
    
    def _register_routes(self):
        """Register all routes"""
        routes = [
            ('/', 'GET', self.index),
            ('/api/process', 'POST', self.process_image),
            ('/api/status', 'GET', self.get_status),
        ]
        
        for path, methods, handler in routes:
            self.blueprint.route(path, methods=[methods])(handler)
    
    def index(self):
        """Render OCR dashboard page"""
        try:
            return render_template('ocr_dashboard.html')
        except Exception as e:
            logger.error(f"Error rendering index: {e}", exc_info=True)
            return render_template('ocr_dashboard.html')
    
    def get_status(self) -> Tuple:
        """Get system status"""
        try:
            return success_response({
                'status': 'ready',
                'ocr_initialized': self.ocr_model.is_initialized()
            })
        except Exception as e:
            return handle_exception(e, "Failed to get status")
    
    def process_image(self) -> Tuple:
        """Process uploaded image with OCR"""
        try:
            # Validate file upload
            if 'image' not in request.files:
                return error_response('No image provided', status_code=400)
            
            file = request.files['image']
            if file.filename == '':
                return error_response('No file selected', status_code=400)
            
            # Validate file extension
            if not self._allowed_file(file.filename):
                return error_response(
                    f"{ERROR_MESSAGES['invalid_file_type']}. Allowed: {', '.join(ALLOWED_IMAGE_EXTENSIONS)}",
                    status_code=400
                )
            
            # Validate file size
            file.seek(0, os.SEEK_END)
            file_size = file.tell()
            file.seek(0)
            
            if file_size > MAX_UPLOAD_SIZE:
                return error_response(ERROR_MESSAGES['file_too_large'], status_code=400)
            
            # Save uploaded file
            filepath = self._save_uploaded_file(file)
            
            try:
                # Process image
                result = self._process_image_file(filepath)
                return success_response(result)
            finally:
                # Cleanup temp file
                try:
                    os.remove(filepath)
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp file: {e}")
            
        except ValueError as e:
            return error_response(str(e), status_code=400)
        except Exception as e:
            return handle_exception(e, ERROR_MESSAGES['processing_failed'])
    
    def _allowed_file(self, filename: str) -> bool:
        """Check if file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS
    
    def _save_uploaded_file(self, file) -> Path:
        """Save uploaded file to temporary directory"""
        temp_dir = self.project_root / 'data' / 'temp_uploads'
        temp_dir.mkdir(parents=True, exist_ok=True)
        
        # Use secure filename
        filename = os.path.basename(file.filename)
        filepath = temp_dir / filename
        
        file.save(str(filepath))
        logger.info(f"💾 Saved uploaded file: {filepath}")
        return filepath
    
    def _process_image_file(self, filepath: Path) -> Dict:
        """Process image file with OCR"""
        # Load and resize image
        img = cv2.imread(str(filepath))
        if img is None:
            raise ValueError(f"Could not read image: {filepath}")
        
        img = resize_image(img, max_size=MAX_IMAGE_SIZE)
        cv2.imwrite(str(filepath), img)  # Save resized version
        
        # Process with OCR
        result = self.ocr_model.process_image(str(filepath), save_outputs=True)
        
        if not result.get('success'):
            return {
                'success': False,
                'error': result.get('error', ERROR_MESSAGES['processing_failed'])
            }
        
        # Encode images
        original_img = Image.open(filepath)
        original_base64 = self._image_to_base64(original_img)
        
        annotated_base64 = None
        viz_path = result.get('output_files', {}).get('visualization')
        if viz_path:
            # Resolve path relative to scripts directory (where OCR system runs)
            script_dir = self.project_root / "scripts"
            if not Path(viz_path).is_absolute():
                # Path is relative, resolve it from scripts directory
                viz_path = script_dir / viz_path
            else:
                viz_path = Path(viz_path)
            
            if viz_path.exists():
                annotated_img = Image.open(viz_path)
                annotated_base64 = self._image_to_base64(annotated_img)
            else:
                logger.warning(f"⚠️ Annotated image not found at: {viz_path}")
        
        # Format barcode data
        barcode_data = self._format_barcode_data(result.get('barcodes', []))
        
        return {
            'success': True,
            'original_image': original_base64,
            'annotated_image': annotated_base64,
            'full_text': result.get('full_text', 'No text detected.'),
            'barcode_data': barcode_data,
            'statistics': result.get('statistics', {}),
            'output_files': result.get('output_files', {}),
            'image_type': result.get('image_type', 'N/A'),
            'features': result.get('features', {}),
            'text_detections': result.get('text_detections', [])
        }
    
    def _format_barcode_data(self, barcodes: list) -> str:
        """Format barcode data as string"""
        if not barcodes:
            return "No Barcodes or QR Codes detected."
        
        lines = []
        for bc in barcodes:
            lines.append(f"[{bc.get('type', 'Unknown')}]")
            lines.append(f"Data: {bc.get('data', 'N/A')}")
            lines.append(f"Strategy: {bc.get('strategy', 'N/A')}")
            lines.append("-" * 30)
        
        return "\n".join(lines)
    
    def _image_to_base64(self, img: Image.Image) -> str:
        """Convert PIL Image to base64 string"""
        buffer = io.BytesIO()
        img.save(buffer, format='JPEG', quality=85)
        img_bytes = buffer.getvalue()
        return base64.b64encode(img_bytes).decode('utf-8')
