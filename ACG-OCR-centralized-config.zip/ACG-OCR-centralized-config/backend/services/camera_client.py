"""
Camera Client Service - HTTP client for camera service
Singleton pattern for managing camera service connections

This module ONLY handles HTTP communication with the camera service.
It does NOT process images - it only returns image file paths.
Image reading/processing should be done by the caller using cv2 or PIL.

IMPORTANT: This module has NO heavy imports (no cv2, no numpy).
All initialization is NON-BLOCKING - no network requests in __init__.

Configuration is loaded from config.yaml via backend.core.config.
"""
import requests
import logging
from typing import Optional
from pathlib import Path

from backend.core.singleton import SingletonMeta
from backend.core.config import get_config

logger = logging.getLogger(__name__)


class CameraClient(metaclass=SingletonMeta):
    """
    HTTP client for camera service - Singleton
    
    This class only handles HTTP communication. It does NOT:
    - Import cv2 or numpy
    - Read or process images
    - Make network requests during __init__
    
    Configuration is loaded from config.yaml:
    - services.camera.base_url
    - services.camera.endpoints.*
    - timeouts.camera_health
    - timeouts.camera_capture
    """
    
    _initialized = False
    
    def __init__(self, base_url: str = None, timeout: int = None):
        """
        Initialize Camera Client (singleton - only initialized once)
        
        NON-BLOCKING: This method does NOT make any network requests.
        All network operations happen on-demand when methods are called.
        
        Args:
            base_url: Base URL of camera service (optional, loaded from config)
            timeout: Default request timeout in seconds (optional, loaded from config)
        """
        if self._initialized:
            return
        
        # Load configuration
        config = get_config()
        
        # Store configuration only - NO NETWORK REQUESTS HERE
        self.base_url = (base_url or config.services.camera.base_url).rstrip('/')
        
        # Timeouts from config
        self.timeout = timeout or config.timeouts.default
        self.health_timeout = config.timeouts.camera_health  # Short timeout for health checks
        self.capture_timeout = config.timeouts.camera_capture  # Timeout for capture operations
        
        # Endpoints from config
        self.endpoints = {
            'stream': config.services.camera.endpoints.stream,
            'capture': config.services.camera.endpoints.capture,
            'frame': config.services.camera.endpoints.frame,
            'health': config.services.camera.endpoints.health,
            'autofocus': config.services.camera.endpoints.autofocus,
            'focus': config.services.camera.endpoints.focus,
        }
        
        self._initialized = True
        logger.info(f"📷 CameraClient initialized (non-blocking): base_url={self.base_url}")
    
    def _check_service_health(self) -> bool:
        """
        Check if camera service is available (non-blocking with short timeout)
        
        Uses a very short timeout to avoid blocking the application.
        Returns False immediately if service is not available.
        """
        try:
            health_url = f"{self.base_url}{self.endpoints['health']}"
            logger.debug(f"Checking camera service health at {health_url} (timeout={self.health_timeout}s)...")
            
            response = requests.get(
                health_url,
                timeout=self.health_timeout  # Short timeout from config
            )
            is_available = response.status_code == 200
            if is_available:
                logger.debug(f"Camera service health check passed: {response.status_code}")
            else:
                logger.debug(f"Camera service health check failed: status={response.status_code}")
            return is_available
        except requests.exceptions.Timeout:
            logger.debug(f"Camera service health check timed out after {self.health_timeout}s")
            return False
        except requests.exceptions.ConnectionError as e:
            logger.debug(f"Camera service not reachable: {e}")
            return False
        except Exception as e:
            logger.debug(f"Camera service health check failed: {e}")
            return False
    
    def is_available(self) -> bool:
        """
        Check if camera service is available (non-blocking)
        
        Returns:
            True if camera service is reachable and healthy, False otherwise
        """
        logger.debug("Checking camera service availability...")
        result = self._check_service_health()
        logger.debug(f"Camera service availability: {result}")
        return result
    
    def capture_image(self) -> Optional[str]:
        """
        Capture image from camera service
        
        Returns:
            Path to captured image or None on error
        """
        logger.debug(f"Capturing image from camera service (timeout={self.capture_timeout}s)...")
        try:
            capture_url = f"{self.base_url}{self.endpoints['capture']}"
            response = requests.post(
                capture_url,
                timeout=self.capture_timeout  # Use capture-specific timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    image_path = data.get('path')
                    # Verify file exists
                    if image_path and Path(image_path).exists():
                        logger.debug(f"Image captured successfully: {image_path}")
                        return image_path
                    else:
                        logger.warning(f"Captured image path does not exist: {image_path}")
                        return None
                else:
                    error_msg = data.get('error', 'Unknown error')
                    logger.error(f"Capture failed: {error_msg}")
                    return None
            elif response.status_code == 503:
                logger.error("Camera service not initialized (503)")
                return None
            else:
                logger.error(f"Capture request failed with status {response.status_code}")
                return None
                
        except requests.exceptions.Timeout:
            logger.error(f"Camera service capture timeout after {self.capture_timeout}s")
            return None
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Cannot connect to camera service at {self.base_url} - is it running? Error: {e}")
            return None
        except Exception as e:
            logger.error(f"Error capturing image: {e}", exc_info=True)
            return None
    
    def get_stream_url(self) -> str:
        """
        Get MJPEG stream URL
        
        Returns:
            URL string for MJPEG stream endpoint
        """
        return f"{self.base_url}{self.endpoints['stream']}"
    
    def capture_frame(self) -> Optional[str]:
        """
        Capture frame and return image file path
        
        This is an alias for capture_image() for compatibility.
        The caller should read the image using cv2.imread() or PIL.
        
        Returns:
            Path to captured image file or None on error
        """
        return self.capture_image()
    
    def get_frame_bytes(self) -> Optional[bytes]:
        """
        Get frame as JPEG bytes directly (no file I/O).
        
        OPTIMIZED: Returns JPEG bytes directly from camera service.
        Much faster than capture_frame() for high-frequency requests.
        
        Returns:
            JPEG bytes or None on error
        """
        try:
            frame_url = f"{self.base_url}{self.endpoints['frame']}"
            response = requests.get(
                frame_url,
                timeout=self.capture_timeout
            )
            
            if response.status_code == 200:
                # Response is raw JPEG bytes
                return response.content
            else:
                logger.debug(f"Get frame failed with status {response.status_code}")
                return None
                
        except requests.exceptions.Timeout:
            logger.debug(f"Get frame timeout after {self.capture_timeout}s")
            return None
        except requests.exceptions.ConnectionError:
            logger.debug(f"Cannot connect to camera service for frame")
            return None
        except Exception as e:
            logger.debug(f"Error getting frame: {e}")
            return None
    
    def trigger_autofocus(self) -> bool:
        """
        Trigger single autofocus operation.
        
        Returns:
            True if autofocus succeeded, False otherwise
        """
        try:
            autofocus_url = f"{self.base_url}{self.endpoints['autofocus']}"
            response = requests.post(
                autofocus_url,
                timeout=self.capture_timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('success', False)
            else:
                logger.debug(f"Autofocus failed with status {response.status_code}")
                return False
                
        except Exception as e:
            logger.debug(f"Error triggering autofocus: {e}")
            return False
    
    def set_manual_focus(self, lens_position: float) -> bool:
        """
        Set manual focus position.
        
        Args:
            lens_position: Focus distance (0.0 = infinity, higher = closer)
        
        Returns:
            True if focus was set, False otherwise
        """
        try:
            focus_url = f"{self.base_url}{self.endpoints['focus']}"
            response = requests.post(
                focus_url,
                json={'lens_position': lens_position},
                timeout=self.capture_timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('success', False)
            else:
                logger.debug(f"Set focus failed with status {response.status_code}")
                return False
                
        except Exception as e:
            logger.debug(f"Error setting focus: {e}")
            return False
