"""
Video Stream Service - Handles efficient video frame streaming
Uses threading and buffering for better performance
Refactored with proper types and removed unused imports

Configuration is loaded from config.yaml via backend.core.config.
"""
import cv2
import base64
import time
import threading
import logging
import numpy as np
from typing import Optional, Tuple, Dict
from queue import Queue

from backend.core.config import get_config

logger = logging.getLogger(__name__)

# Load configuration
_config = get_config()


class VideoStreamService:
    """Service for managing video stream with efficient frame buffering"""
    
    def __init__(self, camera, max_fps: int = None, cache_duration: float = None, stream_width: int = None):
        """
        Initialize video stream service
        
        Args:
            camera: Camera model instance
            max_fps: Maximum frames per second (default: from config.yaml)
            cache_duration: Duration to cache frames (default: from config.yaml)
            stream_width: Target width for streaming frames (default: from config.yaml)
        """
        self.camera = camera
        
        # Load defaults from config if not provided
        self.max_fps = max_fps if max_fps is not None else _config.streaming.max_fps
        self.cache_duration = cache_duration if cache_duration is not None else _config.streaming.cache_duration
        self.stream_width = stream_width if stream_width is not None else _config.streaming.width
        
        self.frame_interval = 1.0 / self.max_fps
        
        # Thread-safe frame storage
        self._current_frame: Optional[str] = None  # Base64 encoded string
        self._current_raw_frame: Optional[np.ndarray] = None  # Raw numpy array
        self._frame_lock = threading.Lock()
        self._last_capture_time = 0.0
        self._start_time = time.time()
        
        # Frame buffer for smooth streaming
        self._frame_buffer: Queue = Queue(maxsize=2)
        self._streaming = False
        self._stream_thread: Optional[threading.Thread] = None
        
        # Statistics
        self._frames_captured = 0
        self._frames_served = 0
        self._errors = 0
    
    def start_streaming(self) -> None:
        """Start background frame capture thread"""
        if self._streaming:
            return
        
        self._streaming = True
        self._start_time = time.time()
        self._stream_thread = threading.Thread(
            target=self._frame_capture_loop,
            daemon=True,
            name="VideoStreamThread"
        )
        self._stream_thread.start()
        logger.info("🎥 Video streaming started")
    
    def stop_streaming(self) -> None:
        """Stop background frame capture thread"""
        self._streaming = False
        if self._stream_thread:
            self._stream_thread.join(timeout=2.0)
        logger.info("🎥 Video streaming stopped")
    
    def is_streaming(self) -> bool:
        """Check if streaming is active"""
        return self._streaming
    
    def _frame_capture_loop(self) -> None:
        """
        Background thread for continuous frame capture - OPTIMIZED
        
        Uses get_frame_bytes() to get JPEG bytes directly from camera service.
        This eliminates file I/O overhead (~20-50ms per frame saved).
        """
        consecutive_errors = 0
        max_consecutive_errors = 5
        
        while self._streaming:
            try:
                current_time = time.time()
                
                # Rate limiting - use more efficient sleep
                time_since_last = current_time - self._last_capture_time
                if time_since_last < self.frame_interval:
                    sleep_time = self.frame_interval - time_since_last
                    time.sleep(min(sleep_time, 0.05))  # Cap sleep at 50ms
                    continue
                
                # OPTIMIZED: Get JPEG bytes directly (no file I/O)
                # This is much faster than capture_frame() + cv2.imread()
                jpeg_bytes = self.camera.get_frame_bytes()
                if jpeg_bytes is None:
                    consecutive_errors += 1
                    if consecutive_errors >= max_consecutive_errors:
                        logger.warning("Multiple consecutive capture failures - backing off")
                        time.sleep(1.0)  # Longer backoff on repeated failures
                        consecutive_errors = 0  # Reset after backoff to allow recovery
                    else:
                        # Small delay on single failures to avoid overwhelming camera service
                        time.sleep(0.1)
                    continue
                
                # Decode JPEG bytes to numpy array (for raw frame storage)
                try:
                    jpeg_array = np.frombuffer(jpeg_bytes, dtype=np.uint8)
                    frame = cv2.imdecode(jpeg_array, cv2.IMREAD_COLOR)
                    if frame is None:
                        logger.warning("Could not decode JPEG frame")
                        consecutive_errors += 1
                        continue
                except Exception as e:
                    logger.error(f"Error decoding JPEG frame: {e}")
                    consecutive_errors += 1
                    continue
                
                # Reset error counter on successful capture
                consecutive_errors = 0
                
                # Convert JPEG bytes to base64 (much faster than re-encoding)
                frame_base64 = base64.b64encode(jpeg_bytes).decode('utf-8')
                encoded_frame = f'data:image/jpeg;base64,{frame_base64}'
                
                with self._frame_lock:
                    # Always update to latest frame (drop old ones)
                    self._current_frame = encoded_frame
                    self._current_raw_frame = frame  # Store decoded frame (no copy needed)
                    self._last_capture_time = current_time
                    self._frames_captured += 1
                
            except Exception as e:
                self._errors += 1
                logger.error(f"Frame capture error: {e}", exc_info=True)
                time.sleep(0.1)
    
    def _encode_frame(self, frame) -> Optional[str]:
        """Encode frame to base64 JPEG with optimization for streaming"""
        try:
            # Resize frame for faster encoding and transmission
            if self.stream_width > 0:
                h, w = frame.shape[:2]
                if w > self.stream_width:
                    scale = self.stream_width / w
                    new_width = self.stream_width
                    new_height = int(h * scale)
                    frame = cv2.resize(frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
            
            # Optimize encoding - slightly lower quality for faster encoding
            encode_params = [
                cv2.IMWRITE_JPEG_QUALITY, 75,  # Lower quality (75 vs 85) for faster encoding
                cv2.IMWRITE_JPEG_OPTIMIZE, 1
            ]
            
            success, buffer = cv2.imencode('.jpg', frame, encode_params)
            if not success:
                return None
            
            frame_base64 = base64.b64encode(buffer).decode('utf-8')
            return f'data:image/jpeg;base64,{frame_base64}'
        except Exception as e:
            logger.error(f"Frame encoding error: {e}")
            return None
    
    def get_frame(self) -> Tuple[Optional[str], Dict]:
        """
        Get current frame with metadata
        
        Returns:
            Tuple of (frame_data, metadata)
        """
        try:
            with self._frame_lock:
                frame = self._current_frame
                self._frames_served += 1
            
            metadata = {
                'frames_captured': self._frames_captured,
                'frames_served': self._frames_served,
                'errors': self._errors,
                'fps': self._calculate_fps()
            }
            
            return frame, metadata
                
        except Exception as e:
            logger.error(f"Error getting frame: {e}")
            return None, {'error': str(e)}
    
    def get_raw_frame(self) -> Optional[np.ndarray]:
        """
        Get current raw frame (numpy array) for capture/processing
        This avoids concurrent camera access issues
        
        Returns:
            Raw frame as numpy array or None if not available
        """
        try:
            with self._frame_lock:
                if self._current_raw_frame is not None:
                    return self._current_raw_frame.copy()
                return None
        except Exception as e:
            logger.error(f"Error getting raw frame: {e}")
            return None
    
    def _calculate_fps(self) -> float:
        """Calculate actual FPS based on elapsed time"""
        if self._frames_captured == 0:
            return 0.0
        
        elapsed_time = time.time() - self._start_time
        if elapsed_time <= 0:
            return 0.0
        
        return min(self.max_fps, self._frames_captured / elapsed_time)
    
    def get_statistics(self) -> Dict:
        """Get streaming statistics"""
        with self._frame_lock:
            return {
                'frames_captured': self._frames_captured,
                'frames_served': self._frames_served,
                'errors': self._errors,
                'fps': self._calculate_fps(),
                'streaming': self._streaming
            }
