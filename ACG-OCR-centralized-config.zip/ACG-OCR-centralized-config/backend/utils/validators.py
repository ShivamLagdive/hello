"""
Validation utilities
"""
import re
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class ValueExtractor:
    """Extract values from OCR text based on scan type"""
    
    @staticmethod
    def extract_tag(full_text: str) -> Optional[str]:
        """
        Extract alphanumeric tag from text
        
        Args:
            full_text: OCR extracted text
        
        Returns:
            Tag code or None
        """
        if not full_text:
            return None
        
        full_text = full_text.strip().upper()
        
        # Pattern: 2-10 letters followed by 1-10 digits (or reverse)
        match = re.search(r'([A-Z]{2,10}[-]?\d{1,10})', full_text)
        
        if match:
            tag_code = match.group(1)
            # Verify it has both letters and numbers
            has_letter = any(c.isalpha() for c in tag_code)
            has_number = any(c.isdigit() for c in tag_code)
            
            if has_letter and has_number:
                return tag_code
        
        return None
    
    @staticmethod
    def extract_weight(full_text: str) -> Optional[str]:
        """
        Extract weight value from text
        
        Args:
            full_text: OCR extracted text
        
        Returns:
            Weight string (e.g., "45.5 kg") or None
        """
        if not full_text:
            return None
        
        # Pattern: 1-4 digits, decimal point, 1-2 decimal places, optional KG
        match = re.search(r'(\d{1,4}\.\d{1,2})\s*K?G?', full_text)
        
        if match:
            val_str = match.group(1)
            try:
                val_float = float(val_str)
                if val_float > 0:
                    return f"{val_float} kg"
            except ValueError:
                pass
        
        return None
    
    @staticmethod
    def extract_machine_number(full_text: str) -> Optional[str]:
        """
        Extract machine number from text
        
        Args:
            full_text: OCR extracted text
        
        Returns:
            Machine number string (e.g., "Machine-12") or None
        """
        if not full_text:
            return None
        
        full_text = full_text.upper()
        
        # Pattern: M, MACHINE, or MACH followed by digits
        match = re.search(r'(M|MACHINE|MACH)\s*-?\s*(\d+)', full_text)
        
        if match:
            return f"Machine-{match.group(2)}"
        
        return None
    
    @staticmethod
    def extract(scan_type: str, full_text: str) -> Optional[str]:
        """
        Extract value based on scan type
        
        Args:
            scan_type: Type of scan ('tag', 'weight', 'box_label')
            full_text: OCR extracted text
        
        Returns:
            Extracted value or None
        """
        extractors = {
            'tag': ValueExtractor.extract_tag,
            'weight': ValueExtractor.extract_weight,
            'box_label': ValueExtractor.extract_machine_number
        }
        
        extractor = extractors.get(scan_type)
        if extractor:
            return extractor(full_text)
        
        logger.warning(f"Unknown scan type: {scan_type}")
        return None
