"""
Main Flask Application - MVC Architecture with Singleton Pattern
Serves HTML/CSS/JS frontend applications
Refactored with singleton pattern for better resource management

Configuration is loaded from config.yaml via backend.core.config.
"""
from flask import Flask, redirect, Response
from pathlib import Path
from typing import Dict, Optional
import secrets
import requests
import logging

from backend.core.config import get_config
from backend.models.ocr_model import OCRModel
from backend.models.camera_model import CameraModel
from backend.models.session_model import SessionModel
from backend.controllers.pharma_controller import PharmaController
from backend.controllers.ocr_controller import OCRController
from backend.controllers.test_controller import TestController

logger = logging.getLogger(__name__)


def create_app(project_root: Path, camera_config: Optional[Dict] = None) -> Flask:
    """
    Create and configure Flask application
    
    Args:
        project_root: Project root directory
        camera_config: Camera configuration dictionary (optional, kept for compatibility)
    
    Returns:
        Configured Flask application
    """
    # Load centralized configuration
    config = get_config()
    
    app = Flask(
        __name__,
        template_folder=str(project_root / 'backend' / 'views' / 'templates'),
        static_folder=str(project_root / 'backend' / 'views' / 'static'),
        static_url_path='/static'
    )
    
    # Configure session
    print("  → Configuring Flask session...")
    app.secret_key = secrets.token_hex(32)
    app.config['SESSION_TYPE'] = 'filesystem'
    
    # Initialize models (singletons - only first call initializes)
    print("  → Initializing OCRModel (this may take 10-30 seconds, loading PaddleOCR)...")
    try:
        OCRModel(project_root)
        print("  ✓ OCRModel initialized")
    except Exception as e:
        print(f"  ✗ OCRModel initialization failed: {e}")
        print("  ⚠️  App will continue but OCR features will not work")
        print("  💡 Try: Check memory, GPU settings, or PaddleOCR installation")
        # Don't raise - allow app to start without OCR
        # OCR features will fail gracefully when used
    
    print("  → Initializing CameraModel...")
    try:
        # CameraModel now uses CameraClient (HTTP client) - no direct camera access
        # CameraClient initialization is NON-BLOCKING (no network requests)
        # Configuration is loaded from config.yaml
        CameraModel(project_root, camera_config or {})
        print("  ✓ CameraModel initialized (camera service will be checked on-demand)")
    except Exception as e:
        print(f"  ✗ CameraModel initialization failed: {e}")
        print("  ⚠️  App will continue but camera features will not work")
        logger.error(f"CameraModel initialization failed: {e}", exc_info=True)
        # Don't raise - allow app to start without camera
        # Camera features will fail gracefully when used
    
    print("  → Initializing SessionModel...")
    try:
        SessionModel()
        print("  ✓ SessionModel initialized")
    except Exception as e:
        print(f"  ✗ SessionModel initialization failed: {e}")
        raise
    
    # Initialize controllers (singletons - only first call initializes)
    # This also registers their blueprints
    print("  → Initializing PharmaController...")
    try:
        pharma_controller = PharmaController(project_root)
        print("  ✓ PharmaController initialized")
    except Exception as e:
        print(f"  ✗ PharmaController initialization failed: {e}")
        raise
    
    print("  → Initializing OCRController...")
    try:
        ocr_controller = OCRController(project_root)
        print("  ✓ OCRController initialized")
    except Exception as e:
        print(f"  ✗ OCRController initialization failed: {e}")
        raise
    
    print("  → Initializing TestController...")
    try:
        test_controller = TestController(project_root)
        print("  ✓ TestController initialized")
    except Exception as e:
        print(f"  ✗ TestController initialization failed: {e}")
        raise
    
    # Register blueprints
    app.register_blueprint(pharma_controller.blueprint)
    app.register_blueprint(ocr_controller.blueprint)
    app.register_blueprint(test_controller.blueprint)
    
    # Get timeout from config
    stream_connect_timeout = config.timeouts.stream_connect
    streaming_chunk_size = config.streaming.chunk_size
    
    # Video feed proxy route - proxies MJPEG stream from camera service
    @app.route('/video_feed')
    def video_feed():
        """Proxy MJPEG stream from camera service"""
        try:
            camera_model = CameraModel()
            stream_url = camera_model.get_stream_url()
            logger.debug(f"Proxying video feed from {stream_url}")
            
            # Stream from camera service with safe timeout from config
            # timeout=(connect_timeout, None) means: connection timeout, no read timeout (for streaming)
            response = requests.get(
                stream_url, 
                stream=True, 
                timeout=(stream_connect_timeout, None)
            )
            
            def generate():
                try:
                    for chunk in response.iter_content(chunk_size=streaming_chunk_size):
                        if chunk:
                            yield chunk
                except requests.exceptions.Timeout:
                    logger.error("Video feed stream timeout")
                except requests.exceptions.ConnectionError as e:
                    logger.error(f"Video feed connection error: {e}")
                except Exception as e:
                    logger.error(f"Error streaming video feed: {e}")
            
            return Response(
                generate(),
                mimetype='multipart/x-mixed-replace; boundary=frame'
            )
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Cannot connect to camera service for video feed: {e}")
            return Response(
                b'--frame\r\nContent-Type: image/jpeg\r\n\r\n\r\n',
                mimetype='multipart/x-mixed-replace; boundary=frame'
            ), 503
        except requests.exceptions.Timeout:
            logger.error("Video feed connection timeout")
            return Response(
                b'--frame\r\nContent-Type: image/jpeg\r\n\r\n\r\n',
                mimetype='multipart/x-mixed-replace; boundary=frame'
            ), 503
        except Exception as e:
            logger.error(f"Error proxying video feed: {e}", exc_info=True)
            return Response(
                b'--frame\r\nContent-Type: image/jpeg\r\n\r\n\r\n',
                mimetype='multipart/x-mixed-replace; boundary=frame'
            ), 503
    
    # Root route
    @app.route('/')
    def index():
        """Root route - redirect to pharma HMI"""
        return redirect('/pharma')
    
    return app
