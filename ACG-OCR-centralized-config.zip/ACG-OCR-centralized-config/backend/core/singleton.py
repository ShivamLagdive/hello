"""
Singleton Pattern Implementation - Thread-safe singleton metaclass

Uses RLock (reentrant lock) to allow nested singleton creation.
Example: CameraModel.__init__() creates CameraClient (both are singletons).
"""
import threading
from typing import Dict, Any, Type, TypeVar

T = TypeVar('T')


class SingletonMeta(type):
    """
    Thread-safe singleton metaclass with reentrant locking.
    
    Uses RLock to allow nested singleton creation (e.g., one singleton
    creating another singleton during initialization).
    
    Usage:
        class MyClass(metaclass=SingletonMeta):
            def __init__(self, *args, **kwargs):
                # Your initialization code
                pass
    """
    _instances: Dict[Type, Any] = {}
    _lock: threading.RLock = threading.RLock()  # RLock allows reentrant locking
    
    def __call__(cls, *args, **kwargs):
        """Create or return existing instance"""
        if cls not in cls._instances:
            # Acquire lock with timeout to prevent deadlocks
            acquired = cls._lock.acquire(timeout=30.0)
            if not acquired:
                raise RuntimeError(f"Singleton lock timeout for {cls.__name__} - possible deadlock")
            
            try:
                # Double-check locking pattern
                if cls not in cls._instances:
                    cls._instances[cls] = super().__call__(*args, **kwargs)
            finally:
                cls._lock.release()
        
        return cls._instances[cls]
    
    @classmethod
    def reset(cls, class_type: Type):
        """
        Reset singleton instance (useful for testing)
        
        Args:
            class_type: Class type to reset
        """
        with cls._lock:
            if class_type in cls._instances:
                del cls._instances[class_type]
    
    @classmethod
    def reset_all(cls):
        """Reset all singleton instances"""
        with cls._lock:
            cls._instances.clear()

