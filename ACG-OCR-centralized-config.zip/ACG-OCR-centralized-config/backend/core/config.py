"""
Centralized Configuration Management
=====================================

This module provides a single source of truth for all configuration values.
Configuration is loaded from config.yaml at the project root.

Usage:
    from backend.core.config import get_config, Config
    
    config = get_config()
    
    # Access nested values with dot notation:
    config.camera.preview.width          # 960
    config.camera.capture.jpeg_quality   # 95
    config.services.camera.base_url      # "http://127.0.0.1:8000"
    config.timeouts.camera_capture       # 3.0
    
    # Access as dictionary:
    config.get('camera', 'preview', 'width')
    config.get('camera', 'preview', 'nonexistent', default=640)
    
    # Get raw dictionary:
    config.to_dict()

Environment Variable Overrides:
    CAMERA_SERVICE_URL - Override services.camera.base_url
    CAMERA_CAPTURE_PATH - Override camera.output_path
    FLASK_HOST - Override flask.host
    FLASK_PORT - Override flask.port
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Any, Dict, Optional
from threading import Lock

logger = logging.getLogger(__name__)


class ConfigSection:
    """
    Wrapper for config sections that allows dot-notation access.
    
    Example:
        section = ConfigSection({'width': 960, 'height': 540})
        section.width  # 960
        section.height # 540
    """
    
    def __init__(self, data: Dict[str, Any]):
        for key, value in data.items():
            if isinstance(value, dict):
                setattr(self, key, ConfigSection(value))
            else:
                setattr(self, key, value)
    
    def __repr__(self):
        return f"ConfigSection({self.__dict__})"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert back to dictionary"""
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, ConfigSection):
                result[key] = value.to_dict()
            else:
                result[key] = value
        return result


class Config:
    """
    Centralized configuration manager.
    
    Loads configuration from YAML file and provides typed access.
    Supports environment variable overrides.
    """
    
    # Default configuration (used if YAML file is missing or invalid)
    DEFAULTS = {
        'camera': {
            'preview': {
                'width': 960,
                'height': 540,
                'fps': 10,
                'format': 'RGB888',
                'jpeg_quality': 85
            },
            'capture': {
                'width': 960,
                'height': 540,
                'jpeg_quality': 95
            },
            'output_path': '/tmp/capture.jpg',
            'autofocus': {
                'enabled': True,
                'mode': 'continuous',
                'speed': 'fast',
                'range': 'normal'
            }
        },
        'services': {
            'camera': {
                'host': '127.0.0.1',
                'port': 8000,
                'base_url': 'http://127.0.0.1:8000',
                'endpoints': {
                    'stream': '/stream.mjpg',
                    'capture': '/capture',
                    'frame': '/frame',
                    'health': '/health',
                    'autofocus': '/autofocus',
                    'focus': '/focus'
                }
            }
        },
        'flask': {
            'host': 'localhost',
            'port': 5000,
            'debug': False,
            'threaded': True
        },
        'timeouts': {
            'camera_health': 0.5,
            'camera_capture': 3.0,
            'stream_connect': 2.0,
            'default': 5.0
        },
        'streaming': {
            'max_fps': 10,
            'cache_duration': 0.05,
            'buffer_size': 1,
            'width': 960,
            'chunk_size': 8192
        },
        'image': {
            'max_size': 960,
            'jpeg_quality': 85,
            'jpeg_optimize': True,
            'allowed_extensions': ['jpg', 'jpeg', 'png', 'bmp', 'tiff', 'webp'],
            'max_upload_size': 10485760
        },
        'ocr_engine': {
            'use_angle_cls': False,
            'lang': 'en',
            'show_log': False,
            'det_limit_side_len': 960,
            'det_db_box_thresh': 0.3,
            'det_db_thresh': 0.3,
            'det_db_unclip_ratio': 1.6,
            'use_gpu': False,
            'enable_mkldnn': False,
            'cpu_threads': 2
        },
        'text_processing': {
            'min_text_length': 2,
            'confidence_threshold': 0.5,
            'high_confidence_no_correct': 0.95,
            'similarity_threshold': 0.7,
            'duplicate_threshold': 0.90
        },
        'pharma': {
            'default_scan_type': 'weight',
            'valid_scan_types': ['tag', 'weight', 'box_label'],
            'workflow_steps': ['tag', 'weight', 'box_label'],
            'valid_rotation_angles': [0, 90, 180, 270]
        }
    }
    
    def __init__(self, config_path: Optional[Path] = None, project_root: Optional[Path] = None):
        """
        Initialize configuration.
        
        Args:
            config_path: Path to config.yaml (optional, auto-detected if not provided)
            project_root: Project root directory (optional, auto-detected if not provided)
        """
        self._raw_config: Dict[str, Any] = {}
        self._project_root = project_root or self._find_project_root()
        self._config_path = config_path or self._project_root / 'config.yaml'
        
        # Load configuration
        self._load_config()
        
        # Apply environment variable overrides
        self._apply_env_overrides()
        
        # Create typed accessors
        self._create_accessors()
    
    def _find_project_root(self) -> Path:
        """Find project root by looking for config.yaml or backend/ directory"""
        # Start from this file's location
        current = Path(__file__).resolve().parent.parent.parent
        
        # Check if config.yaml exists
        if (current / 'config.yaml').exists():
            return current
        
        # Check parent directories
        for parent in current.parents:
            if (parent / 'config.yaml').exists():
                return parent
            if (parent / 'backend').is_dir():
                return parent
        
        # Fallback to current directory
        return current
    
    def _load_config(self) -> None:
        """Load configuration from YAML file with fallback to defaults"""
        # Start with defaults
        self._raw_config = self._deep_copy(self.DEFAULTS)
        
        if self._config_path.exists():
            try:
                with open(self._config_path, 'r') as f:
                    user_config = yaml.safe_load(f) or {}
                
                # Merge user config with defaults
                self._deep_merge(self._raw_config, user_config)
                logger.info(f"✅ Loaded config from {self._config_path}")
                
            except yaml.YAMLError as e:
                logger.error(f"❌ Invalid YAML in {self._config_path}: {e}")
                logger.warning("⚠️  Using default configuration")
            except Exception as e:
                logger.error(f"❌ Error loading config: {e}")
                logger.warning("⚠️  Using default configuration")
        else:
            logger.warning(f"⚠️  Config file not found: {self._config_path}")
            logger.warning("⚠️  Using default configuration")
    
    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides"""
        env_mappings = {
            'CAMERA_SERVICE_URL': ('services', 'camera', 'base_url'),
            'CAMERA_CAPTURE_PATH': ('camera', 'output_path'),
            'FLASK_HOST': ('flask', 'host'),
            'FLASK_PORT': ('flask', 'port'),
        }
        
        for env_var, path in env_mappings.items():
            value = os.environ.get(env_var)
            if value:
                self._set_nested(self._raw_config, path, self._convert_type(value))
                logger.info(f"📝 Environment override: {env_var}={value}")
    
    def _convert_type(self, value: str) -> Any:
        """Convert string value to appropriate type"""
        # Try integer
        try:
            return int(value)
        except ValueError:
            pass
        
        # Try float
        try:
            return float(value)
        except ValueError:
            pass
        
        # Try boolean
        if value.lower() in ('true', 'yes', '1'):
            return True
        if value.lower() in ('false', 'no', '0'):
            return False
        
        # Return as string
        return value
    
    def _create_accessors(self) -> None:
        """Create typed accessor attributes"""
        for key, value in self._raw_config.items():
            if isinstance(value, dict):
                setattr(self, key, ConfigSection(value))
            else:
                setattr(self, key, value)
    
    def _deep_copy(self, obj: Any) -> Any:
        """Deep copy a nested structure"""
        if isinstance(obj, dict):
            return {k: self._deep_copy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._deep_copy(item) for item in obj]
        return obj
    
    def _deep_merge(self, base: Dict, update: Dict) -> None:
        """Recursively merge update into base"""
        for key, value in update.items():
            if isinstance(value, dict) and key in base and isinstance(base[key], dict):
                self._deep_merge(base[key], value)
            else:
                base[key] = value
    
    def _set_nested(self, d: Dict, path: tuple, value: Any) -> None:
        """Set a nested dictionary value"""
        for key in path[:-1]:
            d = d.setdefault(key, {})
        d[path[-1]] = value
    
    def get(self, *keys, default: Any = None) -> Any:
        """
        Get a nested configuration value safely.
        
        Args:
            *keys: Path to the configuration value
            default: Default value if not found
        
        Returns:
            Configuration value or default
        
        Example:
            config.get('camera', 'preview', 'width')  # 960
            config.get('nonexistent', 'key', default=42)  # 42
        """
        value = self._raw_config
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return default
    
    def to_dict(self) -> Dict[str, Any]:
        """Get raw configuration dictionary"""
        return self._deep_copy(self._raw_config)
    
    @property
    def project_root(self) -> Path:
        """Get project root directory"""
        return self._project_root
    
    def get_path(self, *keys) -> Path:
        """
        Get a path configuration value, resolved relative to project root.
        
        Args:
            *keys: Path to the configuration value
        
        Returns:
            Resolved Path object
        """
        path_str = self.get(*keys, default='')
        if not path_str:
            return self._project_root
        
        path = Path(path_str)
        if path.is_absolute():
            return path
        return self._project_root / path


# =============================================================================
# Singleton Instance Management
# =============================================================================

_config_instance: Optional[Config] = None
_config_lock = Lock()


def get_config(config_path: Optional[Path] = None, project_root: Optional[Path] = None) -> Config:
    """
    Get the singleton configuration instance.
    
    The configuration is loaded once and cached. Subsequent calls return
    the cached instance.
    
    Args:
        config_path: Path to config.yaml (only used on first call)
        project_root: Project root directory (only used on first call)
    
    Returns:
        Config instance
    
    Example:
        from backend.core.config import get_config
        
        config = get_config()
        print(config.camera.preview.width)  # 960
    """
    global _config_instance
    
    if _config_instance is None:
        with _config_lock:
            if _config_instance is None:
                _config_instance = Config(config_path, project_root)
    
    return _config_instance


def reload_config() -> Config:
    """
    Reload configuration from disk.
    
    This clears the cached instance and reloads from the YAML file.
    Use sparingly - configuration should typically be loaded once at startup.
    
    Returns:
        New Config instance
    """
    global _config_instance
    
    with _config_lock:
        _config_instance = None
        return get_config()


# =============================================================================
# Convenience Functions (for backward compatibility)
# =============================================================================

def get_camera_preview_size() -> tuple:
    """Get camera preview size as (width, height) tuple"""
    config = get_config()
    return (config.camera.preview.width, config.camera.preview.height)


def get_camera_capture_size() -> tuple:
    """Get camera capture size as (width, height) tuple"""
    config = get_config()
    return (config.camera.capture.width, config.camera.capture.height)


def get_camera_service_url() -> str:
    """Get camera service base URL"""
    config = get_config()
    return config.services.camera.base_url


def get_stream_url() -> str:
    """Get full camera stream URL"""
    config = get_config()
    return f"{config.services.camera.base_url}{config.services.camera.endpoints.stream}"


def get_capture_url() -> str:
    """Get full camera capture URL"""
    config = get_config()
    return f"{config.services.camera.base_url}{config.services.camera.endpoints.capture}"


def get_health_url() -> str:
    """Get full camera health check URL"""
    config = get_config()
    return f"{config.services.camera.base_url}{config.services.camera.endpoints.health}"


# =============================================================================
# Camera Service Configuration (for camera_service.py on Python 3.13)
# =============================================================================

def load_camera_service_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load configuration for camera_service.py.
    
    This function is designed to work standalone without the backend module.
    It can be imported directly in camera_service.py (Python 3.13).
    
    Args:
        config_path: Path to config.yaml (optional, auto-detected if not provided)
    
    Returns:
        Dictionary with camera service configuration
    """
    # Find config file
    if config_path:
        yaml_path = Path(config_path)
    else:
        # Try to find config.yaml in common locations
        possible_paths = [
            Path(__file__).parent.parent.parent / 'config.yaml',
            Path.cwd() / 'config.yaml',
            Path.home() / 'config.yaml',
        ]
        
        yaml_path = None
        for p in possible_paths:
            if p.exists():
                yaml_path = p
                break
    
    # Default camera service config
    defaults = {
        'preview_width': 960,
        'preview_height': 540,
        'preview_fps': 10,
        'preview_format': 'RGB888',
        'stream_jpeg_quality': 85,
        'capture_jpeg_quality': 95,
        'output_path': '/tmp/capture.jpg',
        'host': '127.0.0.1',
        'port': 8000,
        'autofocus_enabled': True,
        'autofocus_mode': 'continuous',
        'autofocus_speed': 'fast',
        'autofocus_range': 'normal',
    }
    
    if yaml_path and yaml_path.exists():
        try:
            with open(yaml_path, 'r') as f:
                config = yaml.safe_load(f) or {}
            
            # Extract camera settings
            camera = config.get('camera', {})
            preview = camera.get('preview', {})
            capture = camera.get('capture', {})
            autofocus = camera.get('autofocus', {})
            services = config.get('services', {}).get('camera', {})
            
            return {
                'preview_width': preview.get('width', defaults['preview_width']),
                'preview_height': preview.get('height', defaults['preview_height']),
                'preview_fps': preview.get('fps', defaults['preview_fps']),
                'preview_format': preview.get('format', defaults['preview_format']),
                'stream_jpeg_quality': preview.get('jpeg_quality', defaults['stream_jpeg_quality']),
                'capture_jpeg_quality': capture.get('jpeg_quality', defaults['capture_jpeg_quality']),
                'output_path': camera.get('output_path', defaults['output_path']),
                'host': services.get('host', defaults['host']),
                'port': services.get('port', defaults['port']),
                'autofocus_enabled': autofocus.get('enabled', defaults['autofocus_enabled']),
                'autofocus_mode': autofocus.get('mode', defaults['autofocus_mode']),
                'autofocus_speed': autofocus.get('speed', defaults['autofocus_speed']),
                'autofocus_range': autofocus.get('range', defaults['autofocus_range']),
            }
        except Exception as e:
            print(f"⚠️  Error loading config: {e}, using defaults")
    
    return defaults


# =============================================================================
# Test / Debug
# =============================================================================

if __name__ == '__main__':
    # Test configuration loading
    print("🧪 Testing Centralized Configuration\n")
    
    config = get_config()
    
    print("📷 Camera Settings:")
    print(f"   Preview: {config.camera.preview.width}x{config.camera.preview.height} @ {config.camera.preview.fps}fps")
    print(f"   Capture: {config.camera.capture.width}x{config.camera.capture.height}")
    print(f"   Stream JPEG Quality: {config.camera.preview.jpeg_quality}")
    print(f"   Capture JPEG Quality: {config.camera.capture.jpeg_quality}")
    print(f"   Output Path: {config.camera.output_path}")
    
    print("\n🌐 Service URLs:")
    print(f"   Camera Base URL: {config.services.camera.base_url}")
    print(f"   Stream Endpoint: {config.services.camera.endpoints.stream}")
    print(f"   Full Stream URL: {get_stream_url()}")
    
    print("\n⏱️  Timeouts:")
    print(f"   Health Check: {config.timeouts.camera_health}s")
    print(f"   Capture: {config.timeouts.camera_capture}s")
    print(f"   Stream Connect: {config.timeouts.stream_connect}s")
    
    print("\n📄 OCR Settings:")
    print(f"   Language: {config.ocr_engine.lang}")
    print(f"   Use GPU: {config.ocr_engine.use_gpu}")
    print(f"   Det Limit: {config.ocr_engine.det_limit_side_len}")
    
    print("\n✅ Configuration test complete!")
