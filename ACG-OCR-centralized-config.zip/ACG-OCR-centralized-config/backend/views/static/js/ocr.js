// OCR Dashboard JavaScript

let currentResult = null;

document.addEventListener('DOMContentLoaded', function() {
    const imageInput = document.getElementById('image-input');
    imageInput.addEventListener('change', function() {
        const processBtn = document.getElementById('process-btn');
        if (processBtn) {
            processBtn.disabled = !this.files.length;
        }
        
        if (this.files.length) {
            const fileInfo = document.getElementById('file-info');
            if (fileInfo) {
                fileInfo.style.display = 'block';
                fileInfo.textContent = `📁 Selected: ${this.files[0].name}`;
            }
        }
    });
    
    checkSystemStatus();
});

function checkSystemStatus() {
    fetch('/ocr/api/status')
        .then(response => response.json())
        .then(data => {
            const statusEl = document.getElementById('system-status');
            if (statusEl) {
                if (data.status === 'ready' && data.ocr_initialized) {
                    statusEl.textContent = '✅ Ready';
                    statusEl.style.color = '#4CAF50';
                } else {
                    statusEl.textContent = '⚠️ Not Ready';
                    statusEl.style.color = '#FF9800';
                }
            }
        })
        .catch(error => {
            console.error('Status check error:', error);
        });
}

function processImage() {
    const fileInput = document.getElementById('image-input');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select an image first');
        return;
    }
    
    const formData = new FormData();
    formData.append('image', file);
    
    const processBtn = document.getElementById('process-btn');
    if (processBtn) {
        processBtn.disabled = true;
        processBtn.textContent = '⏳ Processing...';
    }
    
    // Hide welcome, show processing area
    const welcomeMsg = document.getElementById('welcome-message');
    const processingArea = document.getElementById('processing-area');
    if (welcomeMsg) welcomeMsg.style.display = 'none';
    if (processingArea) {
        processingArea.style.display = 'block';
        processingArea.innerHTML = '<div class="st-spinner"></div><p style="text-align: center;">Running Analysis... Please wait...</p>';
    }
    
    fetch('/ocr/api/process', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentResult = data;
            displayResults(data);
            const successMsg = document.getElementById('success-message');
            if (successMsg) successMsg.style.display = 'block';
        } else {
            showError(data.error || 'Processing failed');
        }
    })
    .catch(error => {
        console.error('Process error:', error);
        showError('Error processing image: ' + error.message);
    })
    .finally(() => {
        if (processBtn) {
            processBtn.disabled = false;
            processBtn.textContent = '✨ Process Image';
        }
    });
}

function displayResults(data) {
    const processingArea = document.getElementById('processing-area');
    if (!processingArea) return;
    
    // Build HTML for results
    let html = `
        <div class="success-box">✅ Processing Complete!</div>
        
        <div class="sub-header">🖼️ Image Analysis</div>
        <div class="st-row">
                <div class="st-column" style="flex: 1;">
                        <h3 style="font-size: 1.3rem; font-weight: 400; margin: 0 0 10px 0; color: var(--st-text-primary);">Original Image</h3>
                        <img id="original-image" class="img-responsive" src="data:image/jpeg;base64,${data.original_image}" alt="Original" style="width: 100%;">
                    </div>
                    <div class="st-column" style="flex: 1;">
                        <h3 style="font-size: 1.3rem; font-weight: 400; margin: 0 0 10px 0; color: var(--st-text-primary);">Annotated Result</h3>
                ${data.annotated_image ? 
                    `<img id="annotated-image" class="img-responsive" src="data:image/jpeg;base64,${data.annotated_image}" alt="Annotated" style="width: 100%;">` :
                    `<div class="st-warning">⚠️ Annotated image not found</div>`
                }
            </div>
        </div>
        
        <hr class="st-divider">
        
        <div class="st-row">
            <div class="st-column" style="flex: 1;">
                <div class="sub-header">📝 Extracted Text Data</div>
                <div class="notification-info" style="margin: 10px 0;">Found ${data.statistics?.text_regions_detected || 0} text regions</div>
                <div class="data-box">${escapeHtml(data.full_text || 'No text detected.')}</div>
                <button class="btn-primary stButton" onclick="downloadText()" style="margin-top: 10px; width: 100%;">
                    📥 Download Text
                </button>
            </div>
            <div class="st-column" style="flex: 1;">
                <div class="sub-header">📱 Barcode / QR Code Data</div>
                <div class="data-box">${escapeHtml(data.barcode_data || 'No Barcodes or QR Codes detected.')}</div>
                ${data.barcode_data && !data.barcode_data.includes('No Barcodes') ? 
                    `<button class="btn-primary stButton" onclick="downloadBarcode()" style="margin-top: 10px; width: 100%;">
                        📥 Download Barcode Data
                    </button>` : ''
                }
            </div>
        </div>
        
        <details class="st-expander">
            <summary class="st-expander-summary">📊 View Detailed Statistics</summary>
            <div class="st-expander-content">
                <p style="color: var(--st-text-primary);"><strong>Image Type:</strong> ${(data.image_type || 'N/A').toUpperCase()}</p>
                <p style="color: var(--st-text-primary);"><strong>Text Regions:</strong> ${data.statistics?.text_regions_detected || 0}</p>
                <p style="color: var(--st-text-primary);"><strong>Barcodes:</strong> ${data.statistics?.barcodes_detected || 0}</p>
                <p style="color: var(--st-text-primary);"><strong>Corrections Made:</strong> ${data.statistics?.corrections_made || 0}</p>
                <p style="color: var(--st-text-primary);"><strong>Image Features:</strong></p>
                <pre style="background: var(--st-bg-primary); color: var(--st-text-primary); padding: 10px; border-radius: 5px; overflow-x: auto; border: 1px solid var(--st-border);">${JSON.stringify(data.features || {}, null, 2)}</pre>
            </div>
        </details>
        
        <details class="st-expander">
            <summary class="st-expander-summary">🔍 Debug Info</summary>
            <div class="st-expander-content">
                <p style="color: var(--st-text-primary);"><strong>Output Files:</strong></p>
                <pre style="background: var(--st-bg-primary); color: var(--st-text-primary); padding: 10px; border-radius: 5px; overflow-x: auto; border: 1px solid var(--st-border);">${JSON.stringify(data.output_files || {}, null, 2)}</pre>
                <p style="color: var(--st-text-primary);"><strong>Raw Detections:</strong></p>
                <p style="color: var(--st-text-primary);">Total detections: ${data.text_detections?.length || 0}</p>
            </div>
        </details>
    `;
    
    processingArea.innerHTML = html;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showError(message) {
    const processingArea = document.getElementById('processing-area');
    if (processingArea) {
        processingArea.innerHTML = `
            <div class="error-box">❌ Processing Failed: ${escapeHtml(message)}</div>
        `;
    }
}

function downloadText() {
    if (!currentResult || !currentResult.full_text) {
        alert('No text data to download');
        return;
    }
    
    const blob = new Blob([currentResult.full_text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'extracted_text.txt';
    a.click();
    URL.revokeObjectURL(url);
}

function downloadBarcode() {
    if (!currentResult || !currentResult.barcode_data) {
        alert('No barcode data to download');
        return;
    }
    
    const blob = new Blob([currentResult.barcode_data], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'barcode_data.txt';
    a.click();
    URL.revokeObjectURL(url);
}
