"""
Application Configuration - Backward Compatibility Module
=========================================================

This module provides backward compatibility for code that imports from backend.config.
All values are now loaded from the centralized config.yaml via backend.core.config.

For new code, prefer importing from backend.core.config directly:
    from backend.core.config import get_config
    config = get_config()
    config.camera.preview.width

This module re-exports commonly used constants for backward compatibility.
"""
from pathlib import Path
from typing import Dict, Set

from backend.core.config import get_config

# Load centralized configuration
_config = get_config()


# =============================================================================
# Image Processing Constants (from config.yaml -> image.*)
# =============================================================================

MAX_IMAGE_SIZE = _config.image.max_size
JPEG_QUALITY = _config.image.jpeg_quality
JPEG_OPTIMIZE = _config.image.jpeg_optimize


# =============================================================================
# Video Streaming Constants (from config.yaml -> streaming.*)
# =============================================================================

DEFAULT_MAX_FPS = _config.streaming.max_fps
FRAME_CACHE_DURATION = _config.streaming.cache_duration
FRAME_BUFFER_SIZE = _config.streaming.buffer_size
STREAM_WIDTH = _config.streaming.width


# =============================================================================
# Pharma HMI Constants (from config.yaml -> pharma.*)
# =============================================================================

DEFAULT_SCAN_TYPE = _config.pharma.default_scan_type
VALID_SCAN_TYPES: Set[str] = set(_config.pharma.valid_scan_types)
VALID_ROTATION_ANGLES: Set[int] = set(_config.pharma.valid_rotation_angles)
WORKFLOW_STEPS = _config.pharma.workflow_steps


# =============================================================================
# File Upload Constants (from config.yaml -> image.*)
# =============================================================================

ALLOWED_IMAGE_EXTENSIONS: Set[str] = set(_config.image.allowed_extensions)
MAX_UPLOAD_SIZE = _config.image.max_upload_size


# =============================================================================
# Session Constants (from config.yaml -> session.*)
# =============================================================================

DEFAULT_SESSION_STATE = _config.get('session', 'default_state', default={
    'current_step': 'tag',
    'cycle_count': 0,
    'weight_value': '',
    'tag_value': '',
    'box_label_value': '',
    'notification': None,
    'captured_image': None,
    'camera_rotation': 0
})


# =============================================================================
# Error Messages (static - not configurable)
# =============================================================================

ERROR_MESSAGES = {
    'camera_not_initialized': 'Camera not initialized',
    'ocr_not_initialized': 'OCR system not initialized',
    'invalid_scan_type': 'Invalid scan type',
    'invalid_rotation': 'Invalid rotation angle',
    'no_frame_available': 'No frame available',
    'capture_failed': 'Failed to capture frame',
    'processing_failed': 'Processing failed',
    'no_value_extracted': 'No value extracted',
    'invalid_file_type': 'Invalid file type',
    'file_too_large': 'File too large'
}


# =============================================================================
# Camera Configuration (for backward compatibility)
# =============================================================================

def get_camera_config(project_root: Path) -> Dict:
    """
    Get camera configuration
    
    This function is provided for backward compatibility.
    New code should use:
        from backend.core.config import get_config
        config = get_config()
        config.camera.preview.width, etc.
    
    Args:
        project_root: Project root directory
    
    Returns:
        Camera configuration dictionary
    """
    config = get_config()
    
    return {
        'camera_id': 0,  # Default to local camera (override in calling code if needed)
        'resolution': (config.camera.preview.width, config.camera.preview.height),
        'framerate': config.camera.preview.fps,
        'capture_dir': str(project_root / 'data' / 'captures'),
        'max_capture_size': config.image.max_size,
        'camera_service_url': config.services.camera.base_url,
    }


# =============================================================================
# Timeout Constants (from config.yaml -> timeouts.*)
# =============================================================================

CAMERA_HEALTH_TIMEOUT = _config.timeouts.camera_health
CAMERA_CAPTURE_TIMEOUT = _config.timeouts.camera_capture
STREAM_CONNECT_TIMEOUT = _config.timeouts.stream_connect
DEFAULT_TIMEOUT = _config.timeouts.default


# =============================================================================
# Camera Service Constants (from config.yaml -> services.camera.*)
# =============================================================================

CAMERA_SERVICE_BASE_URL = _config.services.camera.base_url
CAMERA_SERVICE_HOST = _config.services.camera.host
CAMERA_SERVICE_PORT = _config.services.camera.port
CAMERA_STREAM_ENDPOINT = _config.services.camera.endpoints.stream
CAMERA_CAPTURE_ENDPOINT = _config.services.camera.endpoints.capture
CAMERA_HEALTH_ENDPOINT = _config.services.camera.endpoints.health
