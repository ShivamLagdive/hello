#!/usr/bin/env python3
"""
Camera Service - Standalone service for CSI camera using Picamera2
Runs on Python 3.13 (system Python) to support Picamera2

OPTIMIZED VERSION:
- No camera reconfiguration on capture (saves ~300-500ms)
- Uses cv2.cvtColor() for fast BGR→RGB conversion
- Uses cv2.imencode() for fast JPEG encoding
- Autofocus enabled (for Camera Module 3 or compatible)
- Configuration loaded from config.yaml

Endpoints:
    GET /stream.mjpg - MJPEG live stream
    POST /capture - Capture still image and return path
    GET /frame - Get single frame as JPEG bytes
    POST /autofocus - Trigger single autofocus
    POST /focus - Set manual focus
    GET /health - Health check with autofocus status
"""
from flask import Flask, Response, jsonify, request
from picamera2 import Picamera2
import cv2
import numpy as np
import yaml
import time
import logging
import signal
import sys
from pathlib import Path
from threading import Lock

# Try to import libcamera controls for autofocus
try:
    from libcamera import controls
    LIBCAMERA_AVAILABLE = True
except ImportError:
    LIBCAMERA_AVAILABLE = False
    controls = None

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Camera instance
camera: Picamera2 = None
camera_lock = Lock()
_streaming = False


# =============================================================================
# Configuration Loading
# =============================================================================

def load_config() -> dict:
    """
    Load configuration from config.yaml.
    
    Searches for config.yaml in:
    1. Same directory as this script
    2. Current working directory
    3. Parent directory
    
    Returns default values if config file not found.
    """
    # Default configuration
    defaults = {
        'preview_width': 960,
        'preview_height': 540,
        'preview_fps': 10,
        'preview_format': 'RGB888',
        'stream_jpeg_quality': 85,
        'capture_jpeg_quality': 95,
        'output_path': '/tmp/capture.jpg',
        'host': '127.0.0.1',
        'port': 8000,
        'autofocus_enabled': True,
        'autofocus_mode': 'continuous',
        'autofocus_speed': 'fast',
        'autofocus_range': 'normal',
    }
    
    # Search for config.yaml
    script_dir = Path(__file__).parent
    possible_paths = [
        script_dir / 'config.yaml',
        Path.cwd() / 'config.yaml',
        script_dir.parent / 'config.yaml',
    ]
    
    config_path = None
    for p in possible_paths:
        if p.exists():
            config_path = p
            break
    
    if config_path is None:
        logger.warning("⚠️  config.yaml not found, using defaults")
        return defaults
    
    try:
        with open(config_path, 'r') as f:
            yaml_config = yaml.safe_load(f) or {}
        
        logger.info(f"✅ Loaded config from {config_path}")
        
        # Extract camera settings
        camera_cfg = yaml_config.get('camera', {})
        preview = camera_cfg.get('preview', {})
        capture = camera_cfg.get('capture', {})
        autofocus = camera_cfg.get('autofocus', {})
        services = yaml_config.get('services', {}).get('camera', {})
        
        return {
            'preview_width': preview.get('width', defaults['preview_width']),
            'preview_height': preview.get('height', defaults['preview_height']),
            'preview_fps': preview.get('fps', defaults['preview_fps']),
            'preview_format': preview.get('format', defaults['preview_format']),
            'stream_jpeg_quality': preview.get('jpeg_quality', defaults['stream_jpeg_quality']),
            'capture_jpeg_quality': capture.get('jpeg_quality', defaults['capture_jpeg_quality']),
            'output_path': camera_cfg.get('output_path', defaults['output_path']),
            'host': services.get('host', defaults['host']),
            'port': services.get('port', defaults['port']),
            'autofocus_enabled': autofocus.get('enabled', defaults['autofocus_enabled']),
            'autofocus_mode': autofocus.get('mode', defaults['autofocus_mode']),
            'autofocus_speed': autofocus.get('speed', defaults['autofocus_speed']),
            'autofocus_range': autofocus.get('range', defaults['autofocus_range']),
        }
        
    except Exception as e:
        logger.error(f"❌ Error loading config: {e}, using defaults")
        return defaults


# Load configuration at module level
CONFIG = load_config()

# Configuration values (from config.yaml)
CAPTURE_PATH = Path(CONFIG['output_path'])
STREAM_JPEG_QUALITY = CONFIG['stream_jpeg_quality']
CAPTURE_JPEG_QUALITY = CONFIG['capture_jpeg_quality']
SERVICE_HOST = CONFIG['host']
SERVICE_PORT = CONFIG['port']


# =============================================================================
# Camera Initialization
# =============================================================================

def init_camera():
    """Initialize Picamera2 with preview configuration and autofocus"""
    global camera
    try:
        camera = Picamera2()
        
        # Get resolution and FPS from config
        width = CONFIG['preview_width']
        height = CONFIG['preview_height']
        fps = CONFIG['preview_fps']
        fmt = CONFIG['preview_format']
        
        logger.info(f"📷 Configuring camera: {width}x{height} @ {fps}fps ({fmt})")
        
        # Configure camera for preview/streaming
        # Captures also use this config (no reconfiguration needed)
        preview_config = camera.create_preview_configuration(
            main={"size": (width, height), "format": fmt},
            controls={"FrameRate": fps}
        )
        
        camera.configure(preview_config)
        camera.start()
        
        # Enable autofocus if configured and camera supports it
        autofocus_enabled = False
        if CONFIG['autofocus_enabled']:
            autofocus_enabled = enable_autofocus()
        
        if autofocus_enabled:
            logger.info("✅ Camera initialized with CONTINUOUS AUTOFOCUS")
        else:
            logger.info("✅ Camera initialized (autofocus not available or disabled)")
        
        return True
    except Exception as e:
        logger.error(f"❌ Camera initialization failed: {e}", exc_info=True)
        return False


def enable_autofocus() -> bool:
    """
    Enable continuous autofocus if camera supports it.
    
    Autofocus modes (Camera Module 3):
    - AfModeManual (0): Manual focus
    - AfModeAuto (1): Single autofocus (trigger once)
    - AfModeContinuous (2): Continuous autofocus
    
    Returns:
        True if autofocus was enabled, False otherwise
    """
    global camera
    
    if camera is None:
        return False
    
    try:
        # Check if libcamera controls are available
        if not LIBCAMERA_AVAILABLE:
            logger.warning("libcamera controls not available - autofocus disabled")
            return False
        
        # Check if camera supports autofocus
        camera_controls = camera.camera_controls
        
        if 'AfMode' not in camera_controls:
            logger.info("Camera does not support autofocus (AfMode not available)")
            return False
        
        # Get autofocus settings from config
        af_mode = CONFIG['autofocus_mode']
        af_speed = CONFIG['autofocus_speed']
        af_range = CONFIG['autofocus_range']
        
        # Map mode string to enum
        mode_map = {
            'manual': controls.AfModeEnum.Manual,
            'auto': controls.AfModeEnum.Auto,
            'continuous': controls.AfModeEnum.Continuous,
        }
        
        speed_map = {
            'normal': controls.AfSpeedEnum.Normal,
            'fast': controls.AfSpeedEnum.Fast,
        }
        
        range_map = {
            'normal': controls.AfRangeEnum.Normal,
            'macro': controls.AfRangeEnum.Macro,
            'full': controls.AfRangeEnum.Full,
        }
        
        # Set autofocus mode and speed
        af_controls = {
            "AfMode": mode_map.get(af_mode, controls.AfModeEnum.Continuous),
            "AfSpeed": speed_map.get(af_speed, controls.AfSpeedEnum.Fast),
        }
        camera.set_controls(af_controls)
        
        # Set autofocus range if supported
        if 'AfRange' in camera_controls:
            camera.set_controls({
                "AfRange": range_map.get(af_range, controls.AfRangeEnum.Normal)
            })
        
        logger.info(f"✅ Autofocus enabled (mode={af_mode}, speed={af_speed}, range={af_range})")
        return True
        
    except AttributeError as e:
        # libcamera controls enum not available (older version)
        logger.warning(f"Autofocus controls not available: {e}")
        try:
            # Try numeric values as fallback
            mode_num = {'manual': 0, 'auto': 1, 'continuous': 2}
            camera.set_controls({"AfMode": mode_num.get(CONFIG['autofocus_mode'], 2)})
            logger.info("✅ Autofocus enabled (numeric mode)")
            return True
        except Exception as e2:
            logger.warning(f"Failed to enable autofocus with numeric mode: {e2}")
            return False
    except Exception as e:
        logger.warning(f"Could not enable autofocus: {e}")
        return False


def trigger_autofocus() -> bool:
    """
    Trigger a single autofocus operation.
    Useful when using manual or auto mode, or to refocus in continuous mode.
    
    Returns:
        True if autofocus was triggered, False otherwise
    """
    global camera
    
    if camera is None:
        return False
    
    try:
        if not LIBCAMERA_AVAILABLE:
            return False
        
        camera_controls = camera.camera_controls
        
        if 'AfMode' not in camera_controls:
            return False
        
        # Set to auto mode and trigger
        camera.set_controls({"AfMode": controls.AfModeEnum.Auto})
        
        # Trigger autofocus
        if 'AfTrigger' in camera_controls:
            camera.set_controls({"AfTrigger": controls.AfTriggerEnum.Start})
        
        # Wait for autofocus to complete (max 2 seconds)
        start_time = time.time()
        while time.time() - start_time < 2.0:
            metadata = camera.capture_metadata()
            af_state = metadata.get('AfState', None)
            
            # AfState: 0=Idle, 1=Scanning, 2=Focused, 3=Failed
            if af_state == 2:  # Focused
                logger.info("✅ Autofocus completed successfully")
                return True
            elif af_state == 3:  # Failed
                logger.warning("⚠️ Autofocus failed")
                return False
            
            time.sleep(0.1)
        
        logger.warning("⚠️ Autofocus timeout")
        return False
        
    except Exception as e:
        logger.warning(f"Error triggering autofocus: {e}")
        return False


def cleanup_camera():
    """Cleanup camera resources"""
    global camera, _streaming
    try:
        _streaming = False
        if camera:
            camera.stop()
            camera.close()
            camera = None
        logger.info("Camera resources released")
    except Exception as e:
        logger.error(f"Error during camera cleanup: {e}")


def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info(f"Received signal {signum}, shutting down...")
    cleanup_camera()
    sys.exit(0)


# Register signal handlers
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


# =============================================================================
# Frame Encoding
# =============================================================================

def encode_frame_jpeg(frame: np.ndarray, quality: int = 85) -> bytes:
    """
    Encode frame to JPEG bytes using cv2 (faster than PIL).
    
    Picamera2 returns BGR format (despite RGB888 config).
    cv2.imencode expects BGR input and produces correct RGB JPEG.
    No color conversion needed - direct encoding is fastest.
    """
    if frame is None:
        return None
    
    # Handle BGRA (4 channels) - drop alpha
    if len(frame.shape) == 3 and frame.shape[2] == 4:
        frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    
    encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    success, buffer = cv2.imencode('.jpg', frame, encode_params)
    if success:
        return buffer.tobytes()
    return None


def generate_frames():
    """Generator function for MJPEG streaming - OPTIMIZED"""
    global _streaming
    _streaming = True
    
    # Calculate sleep time from FPS config
    fps = CONFIG['preview_fps']
    sleep_time = 1.0 / fps if fps > 0 else 0.1
    
    try:
        while _streaming:
            with camera_lock:
                if camera is None:
                    break
                
                # Capture frame from preview stream (no reconfiguration needed)
                # Picamera2 returns BGR format, which cv2.imencode expects
                frame = camera.capture_array()
                
                # Encode as JPEG using cv2 (much faster than PIL)
                # cv2 handles BGR→RGB conversion internally for JPEG
                frame_bytes = encode_frame_jpeg(frame, STREAM_JPEG_QUALITY)
                
                if frame_bytes:
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            
            # Rate limiting based on configured FPS
            time.sleep(sleep_time)
            
    except Exception as e:
        logger.error(f"Error in frame generation: {e}", exc_info=True)
    finally:
        _streaming = False


# =============================================================================
# HTTP Endpoints
# =============================================================================

@app.route('/stream.mjpg')
def stream():
    """MJPEG stream endpoint"""
    if camera is None:
        return jsonify({'error': 'Camera not initialized'}), 503
    
    return Response(
        generate_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


@app.route('/capture', methods=['POST'])
def capture():
    """
    Capture still image endpoint - OPTIMIZED
    
    No camera reconfiguration - captures directly from preview stream.
    This saves ~300-500ms per capture by avoiding stop/configure/start cycle.
    """
    global camera
    
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            # Capture directly from preview stream - NO reconfiguration needed!
            # This is much faster than stopping/reconfiguring/starting the camera
            frame = camera.capture_array()
            
            # Handle BGRA (4 channels) - drop alpha
            if len(frame.shape) == 3 and frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # Save as JPEG using cv2 (faster than PIL)
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, CAPTURE_JPEG_QUALITY]
            success = cv2.imwrite(str(CAPTURE_PATH), frame, encode_params)
            
            if not success:
                raise Exception("Failed to save captured image")
            
            logger.info(f"✅ Image captured: {CAPTURE_PATH}")
            
            return jsonify({
                'success': True,
                'path': str(CAPTURE_PATH)
            })
            
    except Exception as e:
        logger.error(f"Error capturing image: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/frame', methods=['GET'])
def get_frame():
    """
    Get single frame as JPEG bytes - OPTIMIZED for streaming
    
    Returns JPEG bytes directly (no file I/O).
    Much faster than /capture for high-frequency frame requests.
    """
    global camera
    
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            # Capture directly from preview stream
            frame = camera.capture_array()
            
            # Handle BGRA (4 channels) - drop alpha
            if len(frame.shape) == 3 and frame.shape[2] == 4:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            
            # Encode as JPEG bytes (no file write)
            frame_bytes = encode_frame_jpeg(frame, STREAM_JPEG_QUALITY)
            
            if frame_bytes is None:
                return jsonify({
                    'success': False,
                    'error': 'Failed to encode frame'
                }), 500
            
            # Return raw JPEG bytes
            return Response(frame_bytes, mimetype='image/jpeg')
            
    except Exception as e:
        logger.error(f"Error getting frame: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/autofocus', methods=['POST'])
def autofocus():
    """
    Trigger single autofocus operation.
    
    Useful for:
    - Refocusing when scene changes
    - Manual focus adjustment
    
    Returns JSON with success status.
    """
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        with camera_lock:
            success = trigger_autofocus()
            
            if success:
                return jsonify({
                    'success': True,
                    'message': 'Autofocus completed'
                })
            else:
                return jsonify({
                    'success': False,
                    'error': 'Autofocus failed or not supported'
                }), 400
                
    except Exception as e:
        logger.error(f"Error in autofocus endpoint: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/focus', methods=['POST'])
def set_focus():
    """
    Set manual focus distance (for cameras that support it).
    
    Request body (JSON):
        - lens_position: float (0.0 to ~10.0, where 0 = infinity, higher = closer)
    
    Returns JSON with success status.
    """
    if camera is None:
        return jsonify({
            'success': False,
            'error': 'Camera not initialized'
        }), 503
    
    try:
        data = request.get_json() or {}
        lens_position = data.get('lens_position')
        
        if lens_position is None:
            return jsonify({
                'success': False,
                'error': 'lens_position is required'
            }), 400
        
        lens_position = float(lens_position)
        
        with camera_lock:
            # Set to manual focus mode
            if LIBCAMERA_AVAILABLE:
                camera.set_controls({
                    "AfMode": controls.AfModeEnum.Manual,
                    "LensPosition": lens_position
                })
            else:
                camera.set_controls({
                    "AfMode": 0,  # Manual
                    "LensPosition": lens_position
                })
            
            logger.info(f"✅ Manual focus set to position: {lens_position}")
            
            return jsonify({
                'success': True,
                'lens_position': lens_position
            })
                
    except Exception as e:
        logger.error(f"Error setting focus: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/config', methods=['GET'])
def get_config():
    """Get current camera configuration"""
    return jsonify({
        'preview': {
            'width': CONFIG['preview_width'],
            'height': CONFIG['preview_height'],
            'fps': CONFIG['preview_fps'],
            'format': CONFIG['preview_format'],
            'jpeg_quality': CONFIG['stream_jpeg_quality'],
        },
        'capture': {
            'jpeg_quality': CONFIG['capture_jpeg_quality'],
            'output_path': str(CAPTURE_PATH),
        },
        'autofocus': {
            'enabled': CONFIG['autofocus_enabled'],
            'mode': CONFIG['autofocus_mode'],
            'speed': CONFIG['autofocus_speed'],
            'range': CONFIG['autofocus_range'],
        },
        'service': {
            'host': CONFIG['host'],
            'port': CONFIG['port'],
        }
    })


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint with autofocus status"""
    af_available = False
    af_mode = None
    
    if camera is not None:
        try:
            camera_controls = camera.camera_controls
            af_available = 'AfMode' in camera_controls
            
            if af_available:
                metadata = camera.capture_metadata()
                af_mode = metadata.get('AfMode', 'unknown')
        except Exception:
            pass
    
    return jsonify({
        'status': 'ok',
        'camera_initialized': camera is not None,
        'streaming': _streaming,
        'autofocus_available': af_available,
        'autofocus_mode': af_mode,
        'config_loaded': True
    })


@app.route('/', methods=['GET'])
def index():
    """Root endpoint"""
    return jsonify({
        'service': 'Camera Service',
        'version': '2.0',
        'config_file': 'config.yaml',
        'endpoints': {
            'GET /stream.mjpg': 'MJPEG live stream',
            'POST /capture': 'Capture still image',
            'GET /frame': 'Get single frame as JPEG',
            'POST /autofocus': 'Trigger single autofocus',
            'POST /focus': 'Set manual focus (lens_position)',
            'GET /config': 'Get current configuration',
            'GET /health': 'Health check with autofocus status'
        }
    })


# =============================================================================
# Main Entry Point
# =============================================================================

if __name__ == '__main__':
    print("\n" + "="*70)
    print("📷 Camera Service - Picamera2 (v2.0 - Centralized Config)")
    print("="*70)
    
    # Show loaded configuration
    print("\n📋 Configuration:")
    print(f"   Resolution:    {CONFIG['preview_width']}x{CONFIG['preview_height']} @ {CONFIG['preview_fps']}fps")
    print(f"   Format:        {CONFIG['preview_format']}")
    print(f"   Stream JPEG:   {CONFIG['stream_jpeg_quality']}%")
    print(f"   Capture JPEG:  {CONFIG['capture_jpeg_quality']}%")
    print(f"   Output Path:   {CONFIG['output_path']}")
    print(f"   Autofocus:     {CONFIG['autofocus_mode']} (enabled={CONFIG['autofocus_enabled']})")
    
    print()
    
    # Initialize camera
    if not init_camera():
        print("⚠️  Camera initialization failed - service will start but camera features won't work")
        print("   Check logs above for details\n")
    
    print("\n🚀 Camera Service Starting...")
    print("📍 Endpoints:")
    print(f"   • MJPEG Stream:   http://{SERVICE_HOST}:{SERVICE_PORT}/stream.mjpg")
    print(f"   • Capture:        http://{SERVICE_HOST}:{SERVICE_PORT}/capture")
    print(f"   • Single Frame:   http://{SERVICE_HOST}:{SERVICE_PORT}/frame")
    print(f"   • Autofocus:      http://{SERVICE_HOST}:{SERVICE_PORT}/autofocus (POST)")
    print(f"   • Manual Focus:   http://{SERVICE_HOST}:{SERVICE_PORT}/focus (POST)")
    print(f"   • Config:         http://{SERVICE_HOST}:{SERVICE_PORT}/config")
    print(f"   • Health Check:   http://{SERVICE_HOST}:{SERVICE_PORT}/health")
    print("\n" + "="*70 + "\n")
    
    try:
        app.run(host=SERVICE_HOST, port=SERVICE_PORT, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n⚠️ Shutting down...")
    finally:
        cleanup_camera()
        print("✅ Shutdown complete")
